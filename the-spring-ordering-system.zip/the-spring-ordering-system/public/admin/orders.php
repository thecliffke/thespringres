<?php
require __DIR__ . '/_guard.php';
if (is_post()) {
    csrf_check();
    $id = (int)post('id');
    try {
        if (post('action') === 'advance') { $o = Orders::find($id); $n = $o ? Orders::next($o) : null; if (!$n) throw new RuntimeException('Nothing to advance.'); Orders::setStatus($id, $n, (int)$ME['id']); flash('success', 'Order updated.'); }
        elseif (post('action') === 'remind_deposit') { $o = Orders::find($id); if (!$o) throw new RuntimeException('Order not found.'); $r = Orders::remindDeposit($o); flash($r['ok'] ? 'success' : 'warning', $o['order_no'] . ': ' . $r['message']); }
        elseif (post('action') === 'cancel') { Orders::setStatus($id, 'cancelled', (int)$ME['id']); flash('success', 'Order cancelled. Refund any deposit manually via M-Pesa.'); }
    } catch (RuntimeException $e) { flash('danger', $e->getMessage()); }
    redirect('/admin/orders.php?' . http_build_query(array_filter(['s' => post('s'), 'q' => post('qq')])));
}
$s = get('s', 'active'); $qv = get('q'); $type = get('type'); $date = get('date');
$where = ['1=1']; $p = [];
$groups = ['active' => "o.status IN ('placed','preparing','ready','dispatched')", 'awaiting' => "o.status='awaiting_deposit'", 'done' => "o.status='completed'", 'cancelled' => "o.status='cancelled'"];
if (isset($groups[$s])) $where[] = $groups[$s]; else $s = 'all';
if ($type === 'dine_in' || $type === 'delivery') { $where[] = 'o.type=?'; $p[] = $type; }
if ($date !== '') { $where[] = 'DATE(o.scheduled_at)=?'; $p[] = $date; }
if ($qv !== '') { $where[] = '(o.order_no LIKE ? OR o.customer_name LIKE ? OR o.phone LIKE ?)'; array_push($p, "%$qv%", "%$qv%", phone_term($qv)); }
$W = implode(' AND ', $where); $per = 20; $pg = page_num();
$total = (int)val("SELECT COUNT(*) FROM orders o WHERE $W", $p);
$list = rows("SELECT o.* FROM orders o WHERE $W ORDER BY " . ($s === 'active' ? 'o.scheduled_at ASC' : 'o.id DESC') . " LIMIT $per OFFSET " . (($pg - 1) * $per), $p);
$itemsBy = [];
if ($list) foreach (rows('SELECT order_id, qty, name FROM order_items WHERE order_id IN (' . implode(',', array_map(fn($o) => (int)$o['id'], $list)) . ')') as $i) $itemsBy[$i['order_id']][] = $i['qty'] . ' x ' . $i['name'];
$tabs = ['active' => 'Active', 'awaiting' => 'Awaiting deposit', 'done' => 'Finished', 'cancelled' => 'Cancelled', 'all' => 'All'];
page_header('Orders', ['admin' => true, 'active' => 'orders']);
?>
<form class="row g-2 mb-3" method="get"><input type="hidden" name="s" value="<?= e($s) ?>">
  <div class="col-12 col-md"><input class="form-control" type="search" name="q" value="<?= e($qv) ?>" placeholder="Search order no, name or phone"></div>
  <div class="col-6 col-md-2"><select class="form-select" name="type"><option value="">Any type</option><option value="dine_in" <?= $type === 'dine_in' ? 'selected' : '' ?>>Dine in</option><option value="delivery" <?= $type === 'delivery' ? 'selected' : '' ?>>Delivery</option></select></div>
  <div class="col-6 col-md-2"><input class="form-control" type="date" name="date" value="<?= e($date) ?>" title="Scheduled date"></div>
  <div class="col-12 col-md-auto"><button class="btn btn-primary w-100">Search</button></div></form>
<ul class="nav nav-pills mb-3 flex-nowrap overflow-auto"><?php foreach ($tabs as $k => $l) echo '<li class="nav-item"><a class="nav-link text-nowrap ' . ($s === $k ? 'active' : '') . '" href="?' . e(http_build_query(['s' => $k, 'q' => $qv, 'type' => $type, 'date' => $date])) . '">' . $l . '</a></li>'; ?></ul>
<div class="card"><div class="table-responsive"><table class="table align-middle mb-0">
<thead><tr><th>Order</th><th>When</th><th>Customer</th><th>Items</th><th class="text-end">Total</th><th class="text-end">Balance</th><th>Status</th><th></th></tr></thead><tbody>
<?php if (!$list) echo '<tr><td colspan="8" class="text-center text-body-secondary py-4">No orders here.</td></tr>'; ?>
<?php foreach ($list as $o): $n = Orders::next($o); $bal = Orders::balance($o); ?>
<tr><td><a class="fw-bold" href="order.php?id=<?= (int)$o['id'] ?>"><?= e($o['order_no']) ?></a><div class="small text-body-secondary"><?= e(type_label($o['type'])) ?></div></td>
 <td class="text-nowrap"><?= $o['asap'] ? 'ASAP' : e(fmt_dt($o['scheduled_at'])) ?></td>
 <td><?= e($o['customer_name']) ?><div class="small"><a href="tel:+<?= e($o['phone']) ?>">+<?= e($o['phone']) ?></a></div></td>
 <td class="small" style="min-width:12rem"><?= e(implode(', ', $itemsBy[$o['id']] ?? [])) ?></td>
 <td class="text-end"><?= money($o['total']) ?></td>
 <td class="text-end <?= $bal > 0 && !in_array($o['status'], ['cancelled', 'awaiting_deposit'], true) ? 'text-danger fw-semibold' : 'text-body-secondary' ?>"><?= in_array($o['status'], ['cancelled'], true) ? '-' : money($bal) ?></td>
 <td><?= status_badge($o) ?></td>
 <td class="text-end text-nowrap"><?php if ($n && $o['status'] !== 'awaiting_deposit'): ?><form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="advance"><input type="hidden" name="id" value="<?= (int)$o['id'] ?>"><input type="hidden" name="s" value="<?= e($s) ?>"><input type="hidden" name="qq" value="<?= e($qv) ?>"><button class="btn btn-primary btn-sm"><?= e(Orders::nextLabel($o, $n)) ?></button></form><?php endif; ?>
  <?php if ($o['status'] === 'awaiting_deposit'): ?><form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="remind_deposit"><input type="hidden" name="id" value="<?= (int)$o['id'] ?>"><input type="hidden" name="s" value="<?= e($s) ?>"><input type="hidden" name="qq" value="<?= e($qv) ?>"><button class="btn btn-outline-primary btn-sm" title="Send SMS reminder to pay the deposit"><i class="bi bi-chat-dots me-1"></i>Remind</button></form><?php endif; ?>
  <a class="btn btn-outline-secondary btn-sm" href="order.php?id=<?= (int)$o['id'] ?>">Open</a></td></tr>
<?php endforeach; ?></tbody></table></div></div>
<div class="d-flex justify-content-between align-items-center mt-3"><small class="text-body-secondary"><?= $total ?> order<?= $total === 1 ? '' : 's' ?></small><?= pager($total, $pg, $per) ?></div>
<?php page_footer(['admin' => true]); ?>
