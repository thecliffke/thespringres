<?php
declare(strict_types=1);

/** SMS via Africa's Talking or SMS Leopard (chosen in Admin > Settings > SMS). */
class Sms {
    public static function provider(): string { return Settings::get('sms_provider') === 'smsleopard' ? 'smsleopard' : 'africastalking'; }
    public static function providerName(): string { return self::provider() === 'smsleopard' ? 'SMS Leopard' : "Africa's Talking"; }
    public static function configured(): bool {
        return self::provider() === 'smsleopard' ? (Settings::has('sl_api_key') && Settings::has('sl_api_secret')) : (Settings::has('at_username') && Settings::has('at_api_key'));
    }
    public static function enabled(): bool { return Settings::get('sms_enabled') === '1'; }

    public static function render(string $tplKey, array $vars): string {
        $map = [];
        foreach ($vars as $k => $v) $map['{' . $k . '}'] = (string)$v;
        return strtr(Settings::get($tplKey), $map);
    }

    /** Send an SMS and log it. Returns ['ok'=>bool,'message'=>string]. $force bypasses the master on/off switch (used by the test button). */
    public static function send(string $phone, string $message, string $event = '', ?int $userId = null, bool $force = false): array {
        $to = norm_phone($phone);
        if (!$to) return ['ok' => false, 'message' => 'Invalid phone number.'];
        $to = '+' . $to;
        if (!$force && !self::enabled()) return ['ok' => false, 'message' => 'SMS is switched off in Settings.'];
        if (!self::configured()) {
            self::log($userId, $to, $event, $message, 'skipped', 'Credentials missing', null, null, '');
            return ['ok' => false, 'message' => self::providerName() . ' credentials are not set.'];
        }
        if (self::provider() === 'smsleopard') return self::sendLeopard($to, $message, $event, $userId);
        $live = Settings::get('at_env') === 'live';
        $endpoint = cfg('at_base_url') ? rtrim((string)cfg('at_base_url'), '/') . '/version1/messaging' : ($live ? 'https://api.africastalking.com/version1/messaging' : 'https://api.sandbox.africastalking.com/version1/messaging');
        $post = ['username' => Settings::get('at_username'), 'to' => $to, 'message' => $message];
        if (Settings::get('at_sender_id') !== '') $post['from'] = Settings::get('at_sender_id');
        $res = http_request('POST', $endpoint, ['apiKey: ' . Settings::get('at_api_key'), 'Accept: application/json', 'Content-Type: application/x-www-form-urlencoded'], http_build_query($post));
        $j = json_decode($res['body'], true);
        $rec = $j['SMSMessageData']['Recipients'][0] ?? null;
        // Africa's Talking: 100 = Processed, 101 = Sent, 102 = Queued (all accepted). 4xx codes are rejections (e.g. 406 UserInBlacklist).
        if ($rec && in_array((int)($rec['statusCode'] ?? 0), [100, 101, 102], true)) {
            self::log($userId, $to, $event, $message, 'sent', (string)$rec['status'], $rec['messageId'] ?? null, $rec['cost'] ?? null, $res['body']);
            return ['ok' => true, 'message' => 'SMS sent.'];
        }
        $why = $rec['status'] ?? ($res['error'] ?: (trim($res['body']) ?: 'HTTP ' . $res['code']));
        self::log($userId, $to, $event, $message, 'failed', mb_substr((string)$why, 0, 120), null, null, $res['body']);
        return ['ok' => false, 'message' => 'SMS failed: ' . mb_substr((string)$why, 0, 160)];
    }

    /** SMS Leopard: GET https://api.smsleopard.com/v1/sms/send with HTTP Basic auth (API key : API secret). */
    private static function sendLeopard(string $to, string $message, string $event, ?int $userId): array {
        $base = cfg('sl_base_url') ? rtrim((string)cfg('sl_base_url'), '/') : 'https://api.smsleopard.com';
        $q = http_build_query(['message' => $message, 'destination' => ltrim($to, '+'), 'source' => Settings::get('sl_sender_id') ?: 'SMS_Leopard'], '', '&', PHP_QUERY_RFC3986);
        $auth = base64_encode(Settings::get('sl_api_key') . ':' . Settings::get('sl_api_secret'));
        $res = http_request('GET', $base . '/v1/sms/send?' . $q, ['Authorization: Basic ' . $auth, 'Accept: application/json']);
        $j = json_decode($res['body'], true);
        $rec = $j['recipients'][0] ?? null;
        if (is_array($j) && !empty($j['success']) && $res['code'] >= 200 && $res['code'] < 300) {
            self::log($userId, $to, $event, $message, 'sent', (string)($rec['status'] ?? 'queued'), $rec['id'] ?? null, isset($rec['cost']) ? 'KES ' . $rec['cost'] : null, $res['body']);
            return ['ok' => true, 'message' => 'SMS sent.'];
        }
        $why = is_array($j) && !empty($j['message']) ? (string)$j['message'] : ($res['error'] ?: (trim($res['body']) ?: 'HTTP ' . $res['code']));
        self::log($userId, $to, $event, $message, 'failed', mb_substr($why, 0, 120), null, null, $res['body']);
        return ['ok' => false, 'message' => 'SMS failed: ' . mb_substr($why, 0, 160)];
    }

    private static function log(?int $uid, string $phone, string $event, string $msg, string $status, ?string $ps, ?string $mid, ?string $cost, string $resp): void {
        q('INSERT INTO sms_log (user_id,phone,event,message,status,provider_status,message_id,cost,response) VALUES (?,?,?,?,?,?,?,?,?)',
            [$uid, $phone, $event, mb_substr($msg, 0, 700), $status, $ps, $mid, $cost, mb_substr($resp, 0, 4000)]);
    }

    /** Order-related SMS to the customer (placed, ready, dispatched, balance). Respects per-event switches. */
    public static function orderEvent(string $event, array $o): array {
        if (!self::enabled() || Settings::get('sms_on_' . $event) !== '1') return ['ok' => false, 'message' => 'Not enabled.'];
        $bal = max(0, (float)$o['total'] - (float)$o['amount_paid']);
        $msg = self::render('sms_tpl_' . $event, [
            'name' => explode(' ', trim($o['customer_name']))[0], 'order' => $o['order_no'], 'restaurant' => Settings::get('restaurant_name'),
            'paid' => money($o['amount_paid']), 'balance' => money($bal), 'paybill' => Settings::payNumber() ?: '(not set)', 'till' => Settings::payNumber() ?: '(not set)', 'pay_details' => Settings::payDetails($o['order_no']),
        ]);
        return self::send($o['phone'], $msg, $event, (int)$o['customer_id']);
    }
}
