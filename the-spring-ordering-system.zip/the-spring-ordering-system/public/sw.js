/* The Spring service worker: receives Web Push messages and shows them as system notifications,
   even when the app is closed or in the background. */
self.addEventListener('install', function () { self.skipWaiting(); });
self.addEventListener('activate', function (e) { e.waitUntil(self.clients.claim()); });
self.addEventListener('fetch', function () { /* network only; present so the app is installable */ });

self.addEventListener('push', function (event) {
  var d = {};
  try { d = event.data ? event.data.json() : {}; } catch (x) { d = { body: event.data ? event.data.text() : '' }; }
  var title = d.title || 'The Spring';
  event.waitUntil(self.registration.showNotification(title, {
    body: d.body || 'You have a new update.',
    icon: 'assets/icons/icon-192.png',
    badge: 'assets/icons/badge-96.png',
    tag: d.tag || 'sp',
    renotify: true,
    data: { url: d.url || './' }
  }));
});

self.addEventListener('notificationclick', function (event) {
  event.notification.close();
  var target = new URL((event.notification.data && event.notification.data.url) || './', self.registration.scope).href;
  event.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (list) {
    for (var i = 0; i < list.length; i++) {
      var c = list[i];
      if (c.url.indexOf(self.registration.scope) === 0 && 'focus' in c) { if ('navigate' in c) c.navigate(target); return c.focus(); }
    }
    return self.clients.openWindow(target);
  }));
});
