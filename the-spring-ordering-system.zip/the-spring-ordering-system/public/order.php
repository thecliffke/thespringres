<?php
require __DIR__ . '/../app/bootstrap.php';
$u = Auth::require('customer');
$o = Orders::find((int)get('id'));
if (!$o || (int)$o['customer_id'] !== (int)$u['id']) { flash('danger', 'Order not found.'); redirect('/orders.php'); }
if (is_post() && post('action') === 'cancel') {
    csrf_check();
    try { Orders::cancelByCustomer((int)$o['id'], (int)$u['id']); flash('success', $o['order_no'] . ' was cancelled. Nothing was charged.'); redirect('/orders.php'); }
    catch (RuntimeException $e) { flash('danger', $e->getMessage()); redirect('/order.php?id=' . $o['id']); }
}
$items = Orders::items((int)$o['id']); $events = Orders::events((int)$o['id']);
$pays = rows('SELECT * FROM payments WHERE order_id=? ORDER BY id', [$o['id']]);
$bal = Orders::balance($o);
page_header($o['order_no'], ['active' => 'orders']);
?>
<div data-order-watch="<?= (int)$o['id'] ?>" data-status="<?= e($o['status']) ?>" data-paid="<?= e($o['amount_paid']) ?>">
<a href="<?= e(url('orders.php')) ?>" class="small">&larr; My orders</a>
<div class="d-flex justify-content-between align-items-center mt-1 mb-3"><h1 class="h3 sp-display mb-0"><?= e($o['order_no']) ?></h1><div class="d-flex align-items-center gap-2"><?= status_badge($o) ?><form method="post" action="<?= e(url('reorder.php')) ?>"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$o['id'] ?>"><button class="btn btn-outline-primary btn-sm"><i class="bi bi-arrow-repeat me-1"></i>Order this again</button></form></div></div>
<?php if ($o['status'] === 'awaiting_deposit'): ?><div class="alert alert-warning d-flex flex-wrap justify-content-between align-items-center gap-2"><span>Your deposit of <b><?= money($o['deposit_due']) ?></b> has not been paid yet. Your order is not sent to the kitchen until it is.</span><div class="d-flex gap-2"><a class="btn btn-primary btn-sm" href="<?= e(url('pay.php?order=' . $o['id'])) ?>">Pay deposit</a><form method="post" data-confirm="Cancel this order? Nothing has been charged."><?= csrf_field() ?><input type="hidden" name="action" value="cancel"><button class="btn btn-outline-danger btn-sm">Cancel order</button></form></div></div><?php endif; ?>
<div class="row g-4">
 <div class="col-lg-7 vstack gap-3">
  <div class="card"><div class="card-body"><h2 class="h5 sp-display mb-3">Order status</h2><?= tracker($o, $events) ?></div></div>
  <div class="card"><div class="card-body"><h2 class="h5 sp-display">Your items</h2>
    <?php foreach ($items as $i) echo '<div class="d-flex justify-content-between py-1"><span>' . (int)$i['qty'] . ' x ' . e($i['name']) . '</span><b>' . money($i['qty'] * $i['unit_price']) . '</b></div>'; ?>
    <?php if ($o['delivery_fee'] > 0) echo '<div class="d-flex justify-content-between py-1"><span>Delivery fee</span><b>' . money($o['delivery_fee']) . '</b></div>'; ?>
    <?php if ($o['loyalty_discount'] > 0) echo '<div class="d-flex justify-content-between py-1 text-success"><span>Loyalty discount (' . number_format((int)$o['loyalty_points']) . ' points)</span><b>- ' . money($o['loyalty_discount']) . '</b></div>'; ?>
    <?php if ($o['notes']) echo '<div class="alert alert-warning mt-2 mb-0 py-2 small">Note: ' . e($o['notes']) . '</div>'; ?></div></div>
 </div>
 <div class="col-lg-5 vstack gap-3">
  <div class="card"><div class="card-body"><h2 class="h5 sp-display"><?= e(type_label($o['type'])) ?></h2>
    <div><i class="bi bi-clock me-1"></i><?= $o['asap'] ? 'As soon as possible' : e(fmt_dt($o['scheduled_at'])) ?></div>
    <?php if ($o['type'] === 'delivery'): ?><div><i class="bi bi-geo-alt me-1"></i><?= e($o['address']) ?><?= $o['landmark'] ? ', ' . e($o['landmark']) : '' ?><?= $o['lat'] !== null ? ' <a class="small ms-1" target="_blank" rel="noopener" href="' . e(Addresses::mapLink($o['lat'], $o['lng'])) . '">Map pin</a>' : '' ?></div>
    <?php else: ?><div><i class="bi bi-people me-1"></i>Table for <?= (int)$o['party_size'] ?></div><?php endif; ?>
    <a class="btn btn-outline-primary btn-sm mt-3" href="<?= e(url('messages.php?new=1&order=' . $o['id'])) ?>"><i class="bi bi-chat-dots me-1"></i>Message us about this order</a></div></div>
  <div class="card" id="pay"><div class="card-body"><h2 class="h5 sp-display">Payment</h2>
    <div class="d-flex justify-content-between"><span>Order total</span><span><?= money($o['total']) ?></span></div>
    <div class="d-flex justify-content-between"><span>Paid so far</span><span><?= money($o['amount_paid']) ?></span></div>
    <div class="d-flex justify-content-between fw-bold fs-5 border-top mt-2 pt-2"><span>Balance</span><span class="<?= $bal > 0 && $o['status'] !== 'cancelled' ? 'text-danger' : 'text-success' ?>"><?= money($o['status'] === 'cancelled' ? 0 : $bal) ?></span></div>
    <?php if ($bal >= 1 && in_array($o['status'], ['ready', 'dispatched'], true)): ?><hr><?= stk_widget($o, 'balance', $u['phone'] ?: $o['phone'], url('order.php?id=' . $o['id']), 'Pay balance ' . money($bal) . ' with M-Pesa', false, url('messages.php?new=1&order=' . $o['id'])) ?><p class="form-text mb-0">Prefer cash? You can also pay the balance to our staff.</p>
    <?php elseif ($bal >= 1 && !in_array($o['status'], ['awaiting_deposit', 'cancelled'], true)): ?><p class="form-text mb-0 mt-2"><?= $o['type'] === 'delivery' ? 'You can pay the balance by M-Pesa when your order arrives.' : 'You can pay the balance by M-Pesa once your food is ready.' ?></p><?php endif; ?>
    <?php if (Loyalty::enabled() && !in_array($o['status'], ['cancelled'], true)):
        $earned = (int)val("SELECT COALESCE(SUM(points),0) FROM loyalty_ledger WHERE order_id=? AND type='earn'", [$o['id']]);
        $est = Loyalty::pointsFor((float)$o['total'] - (float)$o['delivery_fee']); ?>
      <?php if ($earned > 0): ?><div class="alert alert-success py-2 small mt-2 mb-0"><i class="bi bi-star-fill me-1"></i>You earned <b><?= number_format($earned) ?> points</b> on this order.</div>
      <?php elseif ($est > 0 && $o['status'] !== 'completed'): ?><div class="small text-body-secondary mt-2"><i class="bi bi-star me-1 text-warning"></i>You will earn about <b><?= number_format($est) ?> points</b> when this order is completed.</div><?php endif; ?><?php endif; ?>
    <?php foreach (Refunds::forOrder((int)$o['id']) as $rf): if ($rf['status'] === 'failed') continue; ?><div class="alert alert-<?= $rf['status'] === 'success' ? 'success' : 'info' ?> py-2 small mt-2 mb-0"><?= $rf['status'] === 'success' ? 'Deposit refund of ' . money($rf['amount']) . ' sent to your M-Pesa.' : 'Your deposit refund of ' . money($rf['amount']) . ' is being processed.' ?></div><?php endforeach; ?>
    <?php if ($pays): ?><hr><h3 class="h6">Receipts</h3><?php foreach ($pays as $p): ?>
      <div class="d-flex justify-content-between align-items-center py-1"><span><?= e($p['receipt_no']) ?> <small class="text-body-secondary">(<?= $p['kind'] === 'deposit' ? 'deposit' : 'balance' ?>, <?= money($p['amount']) ?><?= $p['pct_of_total'] !== null ? ', ' . rtrim(rtrim(number_format((float)$p['pct_of_total'], 1), '0'), '.') . '% of total' : '' ?>, <?= $p['method'] === 'cash' ? 'cash' : 'M-Pesa' ?>)</small></span><a class="btn btn-outline-primary btn-sm" href="<?= e(url('receipt.php?id=' . $p['id'])) ?>">View</a></div><?php endforeach; ?>
      <a class="btn btn-primary btn-sm w-100 mt-2" href="<?= e(url('order_receipt.php?order=' . $o['id'])) ?>"><i class="bi bi-files me-1"></i>Combined receipt<?= count($pays) > 1 ? ' (all ' . count($pays) . ' payments)' : '' ?></a><?php endif; ?>
  </div></div>
 </div>
</div></div>
<?php page_footer(['scripts' => ['stk.js']]); ?>
