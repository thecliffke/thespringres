<?php
declare(strict_types=1);

/**
 * Sign in / sign up with Google (OAuth 2.0 authorization-code flow with PKCE, OpenID Connect).
 * No library needed: the code is exchanged server-side over HTTPS and the ID token's claims are checked here.
 * Set it up under Admin, Settings, Google.
 */
class Google {
    const AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
    const TOKEN_URL = 'https://oauth2.googleapis.com/token';

    public static function enabled(): bool {
        return Settings::get('google_enabled') === '1' && Settings::has('google_client_id') && Settings::has('google_client_secret');
    }
    /** The address to register in Google Cloud Console as an "Authorized redirect URI". */
    public static function redirectUri(): string { return abs_url('google_callback.php'); }

    /** The "Continue with Google" button. $mode is 'signin' or 'signup' (only changes the wording). */
    public static function button(string $mode = 'signin'): string {
        $label = $mode === 'signup' ? 'Sign up with Google' : 'Sign in with Google';
        $g = '<svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 7.1-10.1 7.1-17.5z"/><path fill="#FBBC05" d="M10.5 28.7A14.5 14.5 0 0 1 9.5 24c0-1.6.3-3.2.8-4.7l-7.9-6.1A24 24 0 0 0 0 24c0 3.9.9 7.5 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.5-5.8c-2.1 1.4-4.9 2.3-8.4 2.3-6.3 0-11.6-4.1-13.5-9.9l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>';
        return '<a class="btn btn-google w-100 btn-lg" href="' . e(url('google_login.php?mode=' . ($mode === 'signup' ? 'signup' : 'signin'))) . '">' . $g . '<span>' . e($label) . '</span></a>';
    }

    private static function b64url(string $b): string { return rtrim(strtr(base64_encode($b), '+/', '-_'), '='); }

    /** Starts the flow: remembers state, nonce and PKCE verifier in the session and returns Google's sign-in URL. */
    public static function beginUrl(string $mode): string {
        $verifier = self::b64url(random_bytes(48));
        $_SESSION['google'] = ['state' => bin2hex(random_bytes(16)), 'nonce' => bin2hex(random_bytes(16)), 'verifier' => $verifier, 'mode' => $mode, 't' => time()];
        return self::AUTH_URL . '?' . http_build_query([
            'client_id' => Settings::get('google_client_id'), 'redirect_uri' => self::redirectUri(), 'response_type' => 'code',
            'scope' => 'openid email profile', 'state' => $_SESSION['google']['state'], 'nonce' => $_SESSION['google']['nonce'],
            'code_challenge' => self::b64url(hash('sha256', $verifier, true)), 'code_challenge_method' => 'S256',
            'prompt' => 'select_account', 'access_type' => 'online',
        ], '', '&', PHP_QUERY_RFC3986);
    }

    /**
     * Finishes the flow after Google redirects back.
     * @return array{ok:bool,message?:string,sub?:string,email?:string,name?:string}
     */
    public static function finish(string $code, string $state): array {
        $s = $_SESSION['google'] ?? null; unset($_SESSION['google']);
        if (!$s || !hash_equals((string)$s['state'], $state) || time() - (int)$s['t'] > 600) return ['ok' => false, 'message' => 'The Google sign-in expired or was not started here. Please try again.'];
        $res = http_request('POST', self::TOKEN_URL, ['Content-Type: application/x-www-form-urlencoded'], http_build_query([
            'code' => $code, 'client_id' => Settings::get('google_client_id'), 'client_secret' => Settings::get('google_client_secret'),
            'redirect_uri' => self::redirectUri(), 'grant_type' => 'authorization_code', 'code_verifier' => $s['verifier'],
        ]));
        $j = json_decode($res['body'], true);
        if ($res['code'] !== 200 || !is_array($j) || empty($j['id_token'])) {
            error_log('google token: HTTP ' . $res['code'] . ' ' . $res['error'] . ' ' . substr($res['body'], 0, 300));
            return ['ok' => false, 'message' => 'Google did not complete the sign-in. Please try again' . (($j['error'] ?? '') === 'invalid_client' ? ' (the restaurant needs to check its Google client ID and secret).' : '.')];
        }
        $parts = explode('.', (string)$j['id_token']);
        $c = count($parts) === 3 ? json_decode((string)base64_decode(strtr($parts[1], '-_', '+/')), true) : null;
        if (!is_array($c)) return ['ok' => false, 'message' => 'Google sent a response we could not read. Please try again.'];
        // The token came straight from Google over HTTPS in exchange for our secret; still check who it is for and that it is fresh.
        if (!in_array($c['iss'] ?? '', ['https://accounts.google.com', 'accounts.google.com'], true) || ($c['aud'] ?? '') !== Settings::get('google_client_id')
            || (int)($c['exp'] ?? 0) < time() || !hash_equals((string)$s['nonce'], (string)($c['nonce'] ?? ''))) return ['ok' => false, 'message' => 'The Google sign-in could not be verified. Please try again.'];
        $email = strtolower((string)($c['email'] ?? ''));
        if (empty($c['sub']) || !filter_var($email, FILTER_VALIDATE_EMAIL)) return ['ok' => false, 'message' => 'Google did not share an email address for this account.'];
        if (!filter_var($c['email_verified'] ?? false, FILTER_VALIDATE_BOOLEAN)) return ['ok' => false, 'message' => 'Your Google email address is not verified, so it cannot be used to sign in.'];
        return ['ok' => true, 'sub' => (string)$c['sub'], 'email' => $email, 'name' => mb_substr(trim((string)($c['name'] ?? '')) ?: explode('@', $email)[0], 0, 120)];
    }
}
