<?php
define('ADMIN_ONLY', true);
require __DIR__ . '/_guard.php';

if (is_post()) {
    csrf_check();
    if (post('action') === 'verify') {
        $v = Audit::verify();
        if ($v['ok']) flash('success', 'Integrity check passed: ' . number_format($v['checked']) . ' records, none edited or removed.');
        else flash('danger', 'Integrity check FAILED at record #' . $v['bad_id'] . '. ' . $v['reason'] . ' Someone may have changed the database directly.');
        Audit::log('system.audit_verified', 'Ran the audit trail integrity check: ' . ($v['ok'] ? 'passed' : 'FAILED at #' . $v['bad_id']), 'system', null, ['checked' => $v['checked'], 'ok' => $v['ok']]);
    }
    redirect('/admin/audit.php');
}

$qv = get('q'); $cat = get('cat'); $role = get('role'); $from = get('from'); $to = get('to');
$where = ['1=1']; $p = [];
if ($qv !== '') {
    $where[] = '(summary LIKE ? OR user_name LIKE ? OR ip LIKE ? OR entity_id LIKE ? OR details LIKE ? OR action LIKE ?)';
    array_push($p, "%$qv%", "%$qv%", "%$qv%", "%$qv%", "%$qv%", "%$qv%");
}
if (isset(Audit::CATEGORIES[$cat])) { $where[] = 'action LIKE ?'; $p[] = $cat . '.%'; }
if (in_array($role, ['admin', 'waiter', 'customer', 'system'], true)) { $where[] = 'user_role=?'; $p[] = $role; }
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) { $where[] = 'created_at >= ?'; $p[] = $from . ' 00:00:00'; }
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) { $where[] = 'created_at <= ?'; $p[] = $to . ' 23:59:59'; }
$W = implode(' AND ', $where);

if (get('export') === '1') {
    $r = rows("SELECT id, created_at, user_name, user_role, action, summary, entity_type, entity_id, ip, details FROM audit_log WHERE $W ORDER BY id DESC LIMIT 50000", $p);
    Audit::log('export.audit', 'Exported ' . count($r) . ' audit record(s) to CSV', 'export', null, ['rows' => count($r), 'search' => $qv, 'category' => $cat, 'from' => $from, 'to' => $to]);
    csv_out('audit-trail', ['ID', 'When', 'User', 'Role', 'Action', 'Summary', 'Entity', 'Entity ID', 'IP', 'Details'], array_map('array_values', $r));
}

$per = 30; $pg = page_num();
$total = (int)val("SELECT COUNT(*) FROM audit_log WHERE $W", $p);
$list = rows("SELECT * FROM audit_log WHERE $W ORDER BY id DESC LIMIT $per OFFSET " . (($pg - 1) * $per), $p);
$today = (int)val('SELECT COUNT(*) FROM audit_log WHERE created_at >= CURDATE()');
$failed = (int)val("SELECT COUNT(*) FROM audit_log WHERE action IN ('auth.login_failed','auth.locked') AND created_at > (NOW() - INTERVAL 24 HOUR)");
$all = (int)val('SELECT COUNT(*) FROM audit_log');

$badge = ['auth' => 'secondary', 'order' => 'primary', 'payment' => 'success', 'refund' => 'danger', 'menu' => 'warning', 'user' => 'info', 'settings' => 'dark', 'reminder' => 'light', 'push' => 'light', 'export' => 'warning', 'system' => 'light'];
$link = function (array $r): string {
    $id = $r['entity_id'];
    if ($r['entity_type'] === 'order' && $id) return '<a href="order.php?id=' . (int)$id . '">View order</a>';
    if ($r['entity_type'] === 'menu_item' && $id && val('SELECT 1 FROM menu_items WHERE id=?', [$id])) return '<a href="menu_edit.php?id=' . (int)$id . '">View dish</a>';
    if ($r['entity_type'] === 'user' && $id && str_starts_with($r['action'], 'user.')) return '<a href="users.php?q=' . urlencode((string)val('SELECT email FROM users WHERE id=?', [$id])) . '">Team</a>';
    if ($r['entity_type'] === 'setting') return '<a href="settings.php">Settings</a>';
    return '';
};
page_header('Audit trail', ['admin' => true, 'active' => 'audit']);
?>
<div class="row g-3 mb-3 kpis">
  <div class="col-6 col-md-3"><div class="kpi"><small>Records today</small><b><?= number_format($today) ?></b></div></div>
  <div class="col-6 col-md-3"><div class="kpi"><small>All records</small><b><?= number_format($all) ?></b></div></div>
  <div class="col-6 col-md-3"><div class="kpi"><small>Failed sign-ins (24 h)</small><b><?= number_format($failed) ?></b></div></div>
  <div class="col-6 col-md-3"><div class="kpi d-flex flex-column justify-content-between"><small>Tamper check</small>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="verify"><button class="btn btn-outline-primary btn-sm mt-1"><i class="bi bi-shield-check me-1"></i>Verify integrity</button></form></div></div>
</div>
<p class="text-body-secondary small">A permanent record of what people did in the system, and what the system did by itself. Records cannot be edited or deleted from the app, and each one is chained to the one before it, so any change made directly in the database is detected by the integrity check. Passwords, API keys and full phone numbers are never recorded.</p>
<form class="row g-2 mb-3" method="get">
  <div class="col-12 col-xl-4"><input class="form-control" type="search" name="q" value="<?= e($qv) ?>" placeholder="Search a person, order number, IP address, action or detail"></div>
  <div class="col-6 col-lg-2"><select class="form-select" name="cat" aria-label="Area"><option value="">All areas</option><?php foreach (Audit::CATEGORIES as $k => $l) echo '<option value="' . $k . '"' . ($cat === $k ? ' selected' : '') . '>' . e($l) . '</option>'; ?></select></div>
  <div class="col-6 col-lg-2"><select class="form-select" name="role" aria-label="Who"><option value="">Everyone</option><?php foreach (['admin' => 'Admins', 'waiter' => 'Waiters', 'customer' => 'Customers', 'system' => 'System'] as $k => $l) echo '<option value="' . $k . '"' . ($role === $k ? ' selected' : '') . '>' . $l . '</option>'; ?></select></div>
  <div class="col-6 col-lg-auto"><input class="form-control" type="date" name="from" value="<?= e($from) ?>" title="From"></div>
  <div class="col-6 col-lg-auto"><input class="form-control" type="date" name="to" value="<?= e($to) ?>" title="To"></div>
  <div class="col-12 col-lg-auto d-flex gap-2"><button class="btn btn-primary flex-grow-1">Search</button><a class="btn btn-outline-secondary" href="audit.php">Clear</a></div>
</form>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-2 gap-2"><div class="text-body-secondary"><?= number_format($total) ?> record<?= $total === 1 ? '' : 's' ?></div>
  <a class="btn btn-outline-primary btn-sm" href="?<?= e(http_build_query(array_merge($_GET, ['export' => 1]))) ?>"><i class="bi bi-download me-1"></i>Export CSV</a></div>
<div class="card"><div class="table-responsive"><table class="table align-middle mb-0">
<thead><tr><th>When</th><th>Who</th><th>What happened</th><th>From</th></tr></thead><tbody>
<?php if (!$list) echo '<tr><td colspan="4" class="text-center text-body-secondary py-4">No records match.</td></tr>'; ?>
<?php foreach ($list as $r): $c = explode('.', $r['action'])[0]; $d = $r['details'] ? json_decode($r['details'], true) : null; ?>
<tr><td class="text-nowrap small"><?= e(fmt_dt($r['created_at'], 'j M Y')) ?><br><b><?= e(fmt_dt($r['created_at'], 'H:i:s')) ?></b></td>
  <td><?= e($r['user_name']) ?><div><span class="badge text-bg-<?= ['admin' => 'warning', 'waiter' => 'info', 'customer' => 'secondary', 'system' => 'light border'][$r['user_role']] ?? 'secondary' ?>"><?= e($r['user_role']) ?></span></div></td>
  <td style="min-width:18rem"><span class="badge text-bg-<?= $badge[$c] ?? 'secondary' ?> mb-1"><?= e($r['action']) ?></span><div><?= e($r['summary']) ?> <?= $link($r) ?></div>
    <?php if ($d || $r['user_agent']): ?><details class="small mt-1"><summary class="text-body-secondary" style="cursor:pointer">Details</summary><pre class="small mb-0 mt-1 text-wrap"><?= e(($d ? json_encode($d, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n" : '') . ($r['user_agent'] ? 'Browser: ' . $r['user_agent'] : '')) ?></pre></details><?php endif; ?></td>
  <td class="small text-nowrap"><?= e($r['ip'] ?: '-') ?><div class="text-body-secondary">#<?= (int)$r['id'] ?></div></td></tr>
<?php endforeach; ?></tbody></table></div></div>
<div class="mt-3"><?= pager($total, $pg, $per) ?></div>
<?php page_footer(['admin' => true]); ?>
