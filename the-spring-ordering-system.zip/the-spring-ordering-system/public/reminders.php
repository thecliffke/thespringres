<?php
require __DIR__ . '/../app/bootstrap.php';
$u = Auth::require('customer');
if (is_post()) {
    csrf_check();
    $act = post('action');
    if ($act === 'add') {
        $t = strtotime(post('when')); $rep = in_array(post('repeat'), ['once', 'daily', 'weekdays'], true) ? post('repeat') : 'once';
        if (!$t || post('label') === '') flash('danger', 'Enter a label and a time.');
        elseif ($rep === 'once' && $t <= time()) flash('danger', 'Pick a time in the future.');
        else {
            if ($rep !== 'once' && $t <= time()) $t = strtotime(Reminders::advance(date('Y-m-d H:i:s', $t), $rep) ?? date('Y-m-d H:i:s', $t));
            Audit::log('reminder.created', 'Set reminder "' . mb_substr(post('label'), 0, 40) . '" (' . $rep . ')', 'reminder', null);
            q('INSERT INTO reminders (user_id,label,next_run,repeat_type,channel_sms) VALUES (?,?,?,?,?)', [$u['id'], mb_substr(post('label'), 0, 80), date('Y-m-d H:i:s', $t), $rep, isset($_POST['sms']) ? 1 : 0]);
            flash('success', 'Reminder saved.');
        }
    } elseif ($act === 'delete') { Audit::log('reminder.deleted', 'Deleted a reminder', 'reminder', (int)post('id')); q('DELETE FROM reminders WHERE id=? AND user_id=?', [(int)post('id'), $u['id']]); flash('success', 'Reminder deleted.'); }
    redirect('/reminders.php');
}
$list = rows('SELECT * FROM reminders WHERE user_id=? AND is_active=1 ORDER BY next_run', [$u['id']]);
$smsOn = Sms::enabled() && Sms::configured();
page_header('Reminders', ['active' => 'reminders']);
?>
<h1 class="h3 sp-display mb-3">Order reminders</h1>
<div class="row g-4">
 <div class="col-lg-6"><div class="card"><div class="card-body"><h2 class="h5 sp-display">Set a reminder</h2>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="add">
   <label class="form-label" for="l">What is it for?</label><input class="form-control mb-3" id="l" name="label" value="Lunch order" maxlength="80" required>
   <div class="row g-3"><div class="col-sm-7"><label class="form-label" for="w">Remind me at</label><input class="form-control" id="w" type="datetime-local" name="when" value="<?= e(date('Y-m-d\TH:00', strtotime('+1 hour'))) ?>" required></div>
   <div class="col-sm-5"><label class="form-label" for="r">Repeat</label><select class="form-select" id="r" name="repeat"><option value="once">Once</option><option value="daily">Every day</option><option value="weekdays">Weekdays</option></select></div></div>
   <?php if ($smsOn): ?><div class="form-check mt-3"><input class="form-check-input" type="checkbox" name="sms" id="sms"><label class="form-check-label" for="sms">Also send me an SMS</label></div><?php endif; ?>
   <button class="btn btn-primary mt-3">Save reminder</button></form>
  <p class="form-text mt-3 mb-0">Reminders show up in the app as a notification<?= $smsOn ? ' (and by SMS if you tick the box)' : '' ?>.</p></div></div></div>
 <div class="col-lg-6"><div class="card"><div class="card-body"><h2 class="h5 sp-display">Your reminders</h2>
  <?php if (!$list) echo '<p class="text-body-secondary mb-0">No reminders yet. Set one and we will nudge you when it is time to order.</p>'; ?>
  <?php foreach ($list as $r): ?><div class="d-flex justify-content-between align-items-center py-2 border-bottom"><div><b><?= e($r['label']) ?></b><div class="small text-body-secondary"><?= e(fmt_dt($r['next_run'])) ?>, <?= ['once' => 'once', 'daily' => 'every day', 'weekdays' => 'weekdays'][$r['repeat_type']] ?><?= $r['channel_sms'] ? ', with SMS' : '' ?></div></div>
   <form method="post" data-confirm="Delete this reminder?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn btn-outline-danger btn-sm">Delete</button></form></div><?php endforeach; ?>
 </div></div></div>
</div>
<?php page_footer(); ?>
