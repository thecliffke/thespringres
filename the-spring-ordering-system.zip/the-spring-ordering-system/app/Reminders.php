<?php
declare(strict_types=1);

class Reminders {
    public static function advance(string $nextRun, string $repeat): ?string {
        if ($repeat === 'once') return null;
        $t = strtotime($nextRun);
        do { $t = strtotime('+1 day', $t); } while ($t <= time() || ($repeat === 'weekdays' && in_array((int)date('N', $t), [6, 7], true)));
        return date('Y-m-d H:i:s', $t);
    }
    /** Fires due reminders: in-app notification, plus SMS when chosen. Throttled to once a minute unless $force. */
    public static function runDue(bool $force = false): int {
        $last = (int)Settings::get('reminders_last_run');
        if (!$force && time() - $last < 55) return 0;
        Settings::set('reminders_last_run', (string)time());
        $n = 0;
        foreach (rows('SELECT r.*, u.name, u.phone FROM reminders r JOIN users u ON u.id=r.user_id WHERE r.is_active=1 AND r.next_run <= NOW() LIMIT 200') as $r) {
            Notify::user((int)$r['user_id'], 'Time to order', $r['label'] . '. Tap to choose your meal.', '/');
            if ($r['channel_sms']) {
                $msg = Sms::render('sms_tpl_reminder', ['name' => explode(' ', $r['name'])[0], 'restaurant' => Settings::get('restaurant_name'), 'label' => $r['label'], 'link' => abs_url('')]);
                Sms::send($r['phone'], $msg, 'reminder', (int)$r['user_id']);
            }
            $next = self::advance($r['next_run'], $r['repeat_type']);
            q('UPDATE reminders SET last_run=NOW(), next_run=COALESCE(?, next_run), is_active=? WHERE id=?', [$next, $next ? 1 : 0, $r['id']]);
            $n++;
        }
        return $n;
    }
}
