<?php
require __DIR__ . '/../app/bootstrap.php';
header('Content-Type: application/manifest+json; charset=utf-8');
header('Cache-Control: public, max-age=3600');
$n = Settings::get('restaurant_name');
echo json_encode([
    'name' => $n . ' ordering', 'short_name' => mb_substr($n, 0, 12), 'description' => 'Order ahead, pay with M-Pesa and track your order.',
    'start_url' => url('/'), 'scope' => url('/'), 'display' => 'standalone', 'orientation' => 'portrait',
    'background_color' => '#FBF5E8', 'theme_color' => '#1F2A12',
    'icons' => [
        ['src' => url('assets/icons/icon-192.png'), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any'],
        ['src' => url('assets/icons/icon-512.png'), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any'],
        ['src' => url('assets/icons/maskable-512.png'), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable'],
    ],
], JSON_UNESCAPED_SLASHES);
