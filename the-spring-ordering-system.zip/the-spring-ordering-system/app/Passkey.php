<?php
declare(strict_types=1);

/**
 * Passkeys (WebAuthn): sign in with the fingerprint, face or screen lock of a phone or laptop.
 * The device keeps the private key and only releases a signature after the person unlocks it with their biometric or PIN;
 * this server stores the public key. No library needed: CBOR, COSE keys (ES256, RS256) and signatures are handled here.
 */
class Passkey {
    const CHALLENGE_TTL = 300;

    public static function enabled(): bool { return Settings::get('passkeys_enabled') === '1'; }

    /** The site's relying-party ID: its domain name (from app_url when set, else the address in use). */
    public static function rpId(): string {
        $h = cfg('app_url') ? (string)parse_url((string)cfg('app_url'), PHP_URL_HOST) : '';
        if ($h === '') $h = (string)explode(':', (string)($_SERVER['HTTP_HOST'] ?? 'localhost'))[0];
        return strtolower($h);
    }
    /** Opaque per-user ID handed to the device (not the database id). */
    public static function handle(int $uid): string { return hash_hmac('sha256', 'spring-user:' . $uid, (string)cfg('app_key', 'change-me'), true); }

    public static function b64e(string $b): string { return rtrim(strtr(base64_encode($b), '+/', '-_'), '='); }
    public static function b64d(string $s): string {
        $r = base64_decode(strtr($s, '-_', '+/') . str_repeat('=', (4 - strlen($s) % 4) % 4), true);
        if ($r === false) throw new RuntimeException('Bad encoding.');
        return $r;
    }

    public static function forUser(int $uid): array { return rows('SELECT id, label, created_at, last_used_at, transports FROM passkeys WHERE user_id=? ORDER BY id', [$uid]); }
    public static function count(int $uid): int { return (int)val('SELECT COUNT(*) FROM passkeys WHERE user_id=?', [$uid]); }

    /** "Chrome on Android" style name for the device list. */
    public static function deviceLabel(string $ua): string {
        $os = preg_match('/Android/i', $ua) ? 'Android' : (preg_match('/iPhone|iPad/i', $ua) ? 'iPhone/iPad' : (preg_match('/Windows/i', $ua) ? 'Windows' : (preg_match('/Mac OS X|Macintosh/i', $ua) ? 'Mac' : (preg_match('/Linux/i', $ua) ? 'Linux' : 'device'))));
        $br = preg_match('/Edg\//', $ua) ? 'Edge' : (preg_match('/SamsungBrowser/', $ua) ? 'Samsung Internet' : (preg_match('/Firefox\//', $ua) ? 'Firefox' : (preg_match('/Chrome\/|CriOS/', $ua) ? 'Chrome' : (preg_match('/Safari\//', $ua) ? 'Safari' : 'browser'))));
        return mb_substr($br . ' on ' . $os, 0, 80);
    }

    /** Dismissible banner inviting a signed-in person without a passkey to turn fingerprint sign-in on. Hidden until the browser proves it supports it. */
    public static function promptHtml(): string {
        $u = Auth::user();
        if (!$u || !self::enabled() || self::count((int)$u['id']) > 0) return '';
        return '<div class="alert alert-success d-none d-flex flex-wrap align-items-center gap-2 justify-content-between" data-passkey-prompt role="region" aria-label="Fingerprint sign-in">'
            . '<span><i class="bi bi-fingerprint fs-5 me-1"></i><b>Sign in faster.</b> Use your fingerprint, face or screen lock instead of typing your password.</span>'
            . '<span class="d-flex gap-2 align-items-center"><span class="small d-none" data-passkey-prompt-msg></span><button type="button" class="btn btn-success btn-sm" data-passkey-prompt-add>Turn on</button>'
            . '<button type="button" class="btn btn-sm btn-outline-secondary" data-passkey-dismiss>Not now</button></span></div>';
    }

    /* ---------- challenges ---------- */
    private static function newChallenge(string $type, ?int $uid = null): string {
        $c = random_bytes(32);
        $_SESSION['passkey'] = ['c' => self::b64e($c), 't' => time(), 'type' => $type, 'uid' => $uid];
        return self::b64e($c);
    }
    /** Returns the stored challenge once (it can never be used twice) or throws. */
    private static function takeChallenge(string $type): array {
        $s = $_SESSION['passkey'] ?? null; unset($_SESSION['passkey']);
        if (!$s || $s['type'] !== $type || time() - (int)$s['t'] > self::CHALLENGE_TTL) throw new RuntimeException('That took too long. Please try again.');
        return $s;
    }

    /* ---------- registration (turn on fingerprint for a signed-in person) ---------- */
    public static function creationOptions(array $u): array {
        $exclude = [];
        foreach (rows('SELECT credential_id, transports FROM passkeys WHERE user_id=?', [$u['id']]) as $k) {
            $e = ['type' => 'public-key', 'id' => $k['credential_id']];
            if ($k['transports'] !== '') $e['transports'] = explode(',', $k['transports']);
            $exclude[] = $e;
        }
        return ['challenge' => self::newChallenge('create', (int)$u['id']), 'rp' => ['name' => Settings::get('restaurant_name'), 'id' => self::rpId()],
            'user' => ['id' => self::b64e(self::handle((int)$u['id'])), 'name' => $u['email'], 'displayName' => $u['name']],
            'pubKeyCredParams' => [['type' => 'public-key', 'alg' => -7], ['type' => 'public-key', 'alg' => -257]],
            'timeout' => 60000, 'attestation' => 'none', 'excludeCredentials' => $exclude,
            'authenticatorSelection' => ['authenticatorAttachment' => 'platform', 'residentKey' => 'required', 'requireResidentKey' => true, 'userVerification' => 'required']];
    }

    /** Checks the new credential and stores it. @return int passkey id */
    public static function register(array $u, array $cred, string $userAgent): int {
        $ch = self::takeChallenge('create');
        if ((int)$ch['uid'] !== (int)$u['id']) throw new RuntimeException('Please try again.');
        $resp = $cred['response'] ?? [];
        self::checkClientData(self::b64d((string)($resp['clientDataJSON'] ?? '')), 'webauthn.create', $ch['c']);
        $o = 0; $att = self::cbor(self::b64d((string)($resp['attestationObject'] ?? '')), $o);
        $auth = is_array($att) ? ($att['authData'] ?? null) : null;
        if (!is_string($auth)) throw new RuntimeException('This device sent something we could not read.');
        $d = self::parseAuthData($auth, true);
        self::checkAuthFlags($d);
        $credId = self::b64e($d['credId']);
        if ($credId !== (string)($cred['id'] ?? '')) throw new RuntimeException('The credential did not match. Please try again.');
        [$pem, $alg] = self::coseToPem($d['cose']);
        if (val('SELECT id FROM passkeys WHERE credential_id=?', [$credId])) throw new RuntimeException('This device is already set up.');
        $tr = array_values(array_filter((array)($cred['transports'] ?? []), fn($t) => is_string($t) && preg_match('/^[a-z\-]{2,20}$/', $t)));
        return exec_id('INSERT INTO passkeys (user_id, credential_id, public_key, alg, sign_count, label, transports) VALUES (?,?,?,?,?,?,?)',
            [(int)$u['id'], $credId, $pem, $alg, $d['count'], self::deviceLabel($userAgent), mb_substr(implode(',', $tr), 0, 80)]);
    }

    /* ---------- sign in ---------- */
    public static function requestOptions(): array {
        return ['challenge' => self::newChallenge('get'), 'rpId' => self::rpId(), 'timeout' => 60000, 'userVerification' => 'required', 'allowCredentials' => []];
    }

    /** Verifies the signed login. @return array the user row, or throws RuntimeException with a message safe to show. */
    public static function authenticate(array $cred): array {
        $ch = self::takeChallenge('get');
        $resp = $cred['response'] ?? [];
        $row = row('SELECT * FROM passkeys WHERE credential_id=?', [(string)($cred['id'] ?? '')]);
        if (!$row) throw new RuntimeException('This fingerprint is not set up on this site yet. Sign in with your password, then turn it on in My profile.');
        $clientData = self::b64d((string)($resp['clientDataJSON'] ?? ''));
        self::checkClientData($clientData, 'webauthn.get', $ch['c']);
        $authData = self::b64d((string)($resp['authenticatorData'] ?? ''));
        $d = self::parseAuthData($authData, false);
        self::checkAuthFlags($d);
        $key = openssl_pkey_get_public((string)$row['public_key']);
        $ok = $key && openssl_verify($authData . hash('sha256', $clientData, true), self::b64d((string)($resp['signature'] ?? '')), $key, OPENSSL_ALGO_SHA256) === 1;
        if (!$ok) throw new RuntimeException('We could not verify that sign-in. Please try again.');
        $u = row('SELECT * FROM users WHERE id=?', [$row['user_id']]);
        if (!$u) throw new RuntimeException('This account no longer exists.');
        if (!empty($resp['userHandle']) && !hash_equals(self::handle((int)$u['id']), self::b64d((string)$resp['userHandle']))) throw new RuntimeException('That passkey belongs to a different account.');
        // A counter that goes backwards means the credential may have been cloned. Many phones always send 0, which is fine.
        if (($d['count'] > 0 || (int)$row['sign_count'] > 0) && $d['count'] <= (int)$row['sign_count']) {
            Audit::log('auth.passkey_failed', 'Fingerprint sign-in refused: the device counter went backwards (possible cloned passkey)', 'user', $u['id'], ['passkey_id' => (int)$row['id']], []);
            throw new RuntimeException('We could not verify that sign-in. Please use your password and set up the fingerprint again.');
        }
        q('UPDATE passkeys SET sign_count=?, last_used_at=NOW() WHERE id=?', [$d['count'], $row['id']]);
        $u['_passkey_id'] = (int)$row['id'];
        return $u;
    }

    /* ---------- checks shared by both ceremonies ---------- */
    private static function checkClientData(string $json, string $type, string $challenge): void {
        $c = json_decode($json, true);
        if (!is_array($c) || ($c['type'] ?? '') !== $type) throw new RuntimeException('This device sent something we did not expect.');
        if (!hash_equals($challenge, (string)($c['challenge'] ?? ''))) throw new RuntimeException('That sign-in has expired. Please try again.');
        if (!empty($c['crossOrigin'])) throw new RuntimeException('This request came from another site.');
        $p = parse_url((string)($c['origin'] ?? '')); $host = strtolower((string)($p['host'] ?? '')); $rp = self::rpId();
        $secure = ($p['scheme'] ?? '') === 'https' || (($p['scheme'] ?? '') === 'http' && in_array($host, ['localhost', '127.0.0.1'], true));
        if (!$secure || $host === '' || ($host !== $rp && !str_ends_with($host, '.' . $rp))) throw new RuntimeException('This request did not come from this website.');
    }
    private static function checkAuthFlags(array $d): void {
        if (!hash_equals(hash('sha256', self::rpId(), true), $d['rpIdHash'])) throw new RuntimeException('This passkey belongs to a different website.');
        if (!($d['flags'] & 0x01)) throw new RuntimeException('The device did not confirm you were present.');
        if (!($d['flags'] & 0x04)) throw new RuntimeException('Your fingerprint, face or screen lock was not checked. Please try again.');
    }
    private static function parseAuthData(string $a, bool $needKey): array {
        if (strlen($a) < 37) throw new RuntimeException('This device sent something we could not read.');
        $d = ['rpIdHash' => substr($a, 0, 32), 'flags' => ord($a[32]), 'count' => (int)unpack('N', substr($a, 33, 4))[1]];
        if ($needKey) {
            if (!($d['flags'] & 0x40) || strlen($a) < 55) throw new RuntimeException('This device did not create a passkey.');
            $len = (int)unpack('n', substr($a, 53, 2))[1];
            if ($len < 16 || $len > 1023 || strlen($a) < 55 + $len) throw new RuntimeException('This device sent something we could not read.');
            $d['credId'] = substr($a, 55, $len);
            $o = 0; $d['cose'] = self::cbor(substr($a, 55 + $len), $o);
        }
        return $d;
    }

    /* ---------- keys ---------- */
    /** COSE_Key (ES256 or RS256) to a PEM public key. @return array{0:string,1:int} */
    private static function coseToPem($k): array {
        if (!is_array($k)) throw new RuntimeException('This device sent a key we could not read.');
        $der = static function (int $tag, string $c): string { $n = strlen($c); $l = $n < 128 ? chr($n) : ($n < 256 ? "\x81" . chr($n) : "\x82" . chr($n >> 8) . chr($n & 255)); return chr($tag) . $l . $c; };
        $int = static function (string $b) use ($der): string { $b = ltrim($b, "\0"); if ($b === '' || ord($b[0]) > 127) $b = "\0" . $b; return $der(0x02, $b); };
        if (($k[1] ?? null) === 2 && ($k[3] ?? null) === -7 && ($k[-1] ?? null) === 1 && strlen((string)($k[-2] ?? '')) === 32 && strlen((string)($k[-3] ?? '')) === 32) {
            $spki = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200') . "\x04" . $k[-2] . $k[-3]; $alg = -7;
        } elseif (($k[1] ?? null) === 3 && ($k[3] ?? null) === -257 && is_string($k[-1] ?? null) && is_string($k[-2] ?? null)) {
            $rsa = $der(0x30, $int($k[-1]) . $int($k[-2]));
            $spki = $der(0x30, $der(0x30, hex2bin('06092a864886f70d0101010500')) . $der(0x03, "\0" . $rsa)); $alg = -257;
        } else throw new RuntimeException('This device uses a key type we do not support.');
        $pem = "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($spki), 64, "\n") . "-----END PUBLIC KEY-----\n";
        if (!openssl_pkey_get_public($pem)) throw new RuntimeException('This device sent a key we could not read.');
        return [$pem, $alg];
    }

    /* ---------- minimal CBOR reader (what WebAuthn needs) ---------- */
    private static function cbor(string $d, int &$o, int $depth = 0) {
        if ($depth > 8 || $o >= strlen($d)) throw new RuntimeException('Unreadable data.');
        $ib = ord($d[$o++]); $mt = $ib >> 5; $ai = $ib & 31;
        $need = static function (int $n) use ($d, &$o) { if ($o + $n > strlen($d)) throw new RuntimeException('Unreadable data.'); };
        if ($ai < 24) $v = $ai;
        elseif ($ai === 24) { $need(1); $v = ord($d[$o++]); }
        elseif ($ai === 25) { $need(2); $v = (int)unpack('n', substr($d, $o, 2))[1]; $o += 2; }
        elseif ($ai === 26) { $need(4); $v = (int)unpack('N', substr($d, $o, 4))[1]; $o += 4; }
        elseif ($ai === 27) { $need(8); $v = (int)unpack('J', substr($d, $o, 8))[1]; $o += 8; }
        else throw new RuntimeException('Unreadable data.');
        switch ($mt) {
            case 0: return $v;
            case 1: return -1 - $v;
            case 2: case 3: $need($v); $s = substr($d, $o, $v); $o += $v; return $s;
            case 4: if ($v > 64) throw new RuntimeException('Unreadable data.'); $a = []; for ($i = 0; $i < $v; $i++) $a[] = self::cbor($d, $o, $depth + 1); return $a;
            case 5: if ($v > 64) throw new RuntimeException('Unreadable data.'); $m = []; for ($i = 0; $i < $v; $i++) { $key = self::cbor($d, $o, $depth + 1); $m[$key] = self::cbor($d, $o, $depth + 1); } return $m;
            case 6: return self::cbor($d, $o, $depth + 1);
            case 7: if ($ai === 20) return false; if ($ai === 21) return true; if ($ai === 22 || $ai === 23) return null; throw new RuntimeException('Unreadable data.');
        }
        throw new RuntimeException('Unreadable data.');
    }
}
