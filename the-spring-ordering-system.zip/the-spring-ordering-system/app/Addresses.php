<?php
declare(strict_types=1);

/** A customer's saved delivery addresses (label, address, landmark and an optional map pin from the phone's location). */
class Addresses {
    const MAX = 10;

    public static function forUser(int $uid): array { return rows('SELECT * FROM saved_addresses WHERE user_id=? ORDER BY is_default DESC, id', [$uid]); }
    public static function find(int $id, int $uid): ?array { return row('SELECT * FROM saved_addresses WHERE id=? AND user_id=?', [$id, $uid]); }
    public static function defaultFor(int $uid): ?array { return row('SELECT * FROM saved_addresses WHERE user_id=? ORDER BY is_default DESC, id LIMIT 1', [$uid]); }

    /** Accepts coordinates only when both are valid numbers on Earth; otherwise no pin. @return array{0:?float,1:?float} */
    public static function pin($lat, $lng): array {
        if (!is_numeric($lat) || !is_numeric($lng) || $lat === '' || $lng === '') return [null, null];
        $la = round((float)$lat, 6); $ln = round((float)$lng, 6);
        return ($la >= -90 && $la <= 90 && $ln >= -180 && $ln <= 180 && !($la == 0 && $ln == 0)) ? [$la, $ln] : [null, null];
    }
    public static function mapLink($lat, $lng): string { return $lat === null || $lng === null ? '' : 'https://www.google.com/maps?q=' . rawurlencode(number_format((float)$lat, 6, '.', '') . ',' . number_format((float)$lng, 6, '.', '')); }

    /** Adds an address (or refreshes the same one). Returns an error message or null. */
    public static function save(int $uid, string $label, string $address, string $landmark, $lat, $lng, bool $makeDefault = false): ?string {
        $label = mb_substr(trim($label), 0, 40) ?: 'Home'; $address = mb_substr(trim($address), 0, 255); $landmark = mb_substr(trim($landmark), 0, 160);
        if (mb_strlen($address) < 3) return 'Enter the delivery location.';
        [$la, $ln] = self::pin($lat, $lng);
        $same = row('SELECT id FROM saved_addresses WHERE user_id=? AND LOWER(address)=LOWER(?)', [$uid, $address]);
        if ($same) { q('UPDATE saved_addresses SET label=?, landmark=?, lat=?, lng=? WHERE id=?', [$label, $landmark, $la, $ln, $same['id']]); $id = (int)$same['id']; }
        else {
            if ((int)val('SELECT COUNT(*) FROM saved_addresses WHERE user_id=?', [$uid]) >= self::MAX) return 'You can save up to ' . self::MAX . ' addresses. Remove one first.';
            $first = !self::forUser($uid);
            $id = exec_id('INSERT INTO saved_addresses (user_id,label,address,landmark,lat,lng,is_default) VALUES (?,?,?,?,?,?,?)', [$uid, $label, $address, $landmark, $la, $ln, $first ? 1 : 0]);
        }
        if ($makeDefault) self::setDefault($id, $uid);
        return null;
    }
    public static function update(int $id, int $uid, string $label, string $address, string $landmark, $lat, $lng): ?string {
        if (!self::find($id, $uid)) return 'Address not found.';
        $address = mb_substr(trim($address), 0, 255);
        if (mb_strlen($address) < 3) return 'Enter the delivery location.';
        [$la, $ln] = self::pin($lat, $lng);
        q('UPDATE saved_addresses SET label=?, address=?, landmark=?, lat=?, lng=? WHERE id=? AND user_id=?', [mb_substr(trim($label), 0, 40) ?: 'Home', $address, mb_substr(trim($landmark), 0, 160), $la, $ln, $id, $uid]);
        return null;
    }
    public static function setDefault(int $id, int $uid): void {
        if (!self::find($id, $uid)) return;
        q('UPDATE saved_addresses SET is_default = (id=?) WHERE user_id=?', [$id, $uid]);
    }
    public static function delete(int $id, int $uid): void {
        $a = self::find($id, $uid); if (!$a) return;
        q('DELETE FROM saved_addresses WHERE id=? AND user_id=?', [$id, $uid]);
        if ($a['is_default'] && ($n = self::forUser($uid))) self::setDefault((int)$n[0]['id'], $uid);
    }
}
