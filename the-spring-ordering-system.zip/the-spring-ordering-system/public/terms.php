<?php
require __DIR__ . '/../app/bootstrap.php';
$name = Settings::get('restaurant_name'); $addr = Settings::get('restaurant_address'); $tel = Settings::get('restaurant_phone');
$mail = Settings::get('legal_email') ?: Settings::get('mail_from');
$updated = '19 October 2026'; $pct = Settings::depositPct();
page_header('Terms of Service');
?>
<article class="legal">
<h1 class="sp-display">Terms of Service</h1>
<p class="meta">Last updated: <?= e($updated) ?></p>
<p>These terms apply when you create an account or place an order with <?= e($name) ?> ("we", "us") through this website. By creating an account or placing an order you agree to them. Please also read our <a href="<?= e(url('privacy.php')) ?>">Privacy Policy</a>.</p>

<h2>1. Your account</h2>
<ul>
 <li>You can sign up with your email and a password, or with your Google account. You must give a correct name and an M-Pesa number that you are allowed to use.</li>
 <li>Keep your sign-in details safe. You are responsible for what happens under your account, so tell us straight away if you think someone else has used it.</li>
 <li>We may suspend or close an account that is used for fraud, abuse or to place orders we cannot reasonably serve.</li>
</ul>

<h2>2. Menu, prices and availability</h2>
<p>Prices are in Kenyan shillings (KES). Offers and discounts apply only for the period shown. Dishes can sell out, and we may change the menu, prices or opening hours at any time. The price you see when you place the order is the price you pay for that order.</p>

<h2>3. Placing an order</h2>
<ul>
 <li>You choose dine-in or delivery and a time. Times are targets, and the lead time we need depends on how busy we are.</li>
 <li>An order is confirmed when your deposit (see below) has been received. Until then it is not sent to the kitchen.</li>
 <li>For delivery, please give an accurate address and a reachable phone number. If we cannot reach you or find the address, we may be unable to complete the delivery.</li>
 <li>Please tell us about any food allergy or dietary need in the order notes and with our staff. We take care, but we cannot guarantee that any dish is free from allergens.</li>
</ul>

<h2>4. Payment</h2>
<ul>
 <li>Payment is by M-Pesa. We send a payment prompt (STK Push) to the phone number you give, and you approve it with your M-Pesa PIN. We never see your PIN.</li>
 <li>You pay an upfront share of the order total when you order (currently <?= (int)$pct ?>%, and you may choose to pay more or the full amount). The remaining balance is paid by M-Pesa or in cash when your order is ready, delivered or after you have eaten.</li>
 <li>An order cannot be closed until it is paid in full.</li>
 <li>You will get a receipt for each payment (deposit and balance) and a combined receipt for the whole order showing everything paid. Payments may be flagged as confirmed by our staff where M-Pesa confirmation was delayed.</li>
 <li>You must only pay from an M-Pesa account you are authorised to use. Safaricom's M-Pesa terms and charges apply to the payment itself.</li>
</ul>

<h2>5. Cancellations and refunds</h2>
<ul>
 <li>You can cancel an order online only until the deposit has been paid. After that the kitchen has the order, so please contact us as soon as possible and we will look at your request.</li>
 <li>If we cannot supply your order, for example because items run out, or we cancel it, we will refund what you paid for it.</li>
 <li>Other refunds are at our discretion, depending on how far the order has been prepared and the reason for the request.</li>
 <li>Approved refunds are sent back to the M-Pesa number the payment came from, and you will be notified when this is done.</li>
 <li>If you believe a payment is wrong or was taken twice, message us with the M-Pesa code and we will check it.</li>
</ul>

<?php if (Loyalty::enabled()): ?>
<h2>Loyalty points</h2>
<ul>
 <li>You earn <?= (int)Loyalty::earnRate() ?> point<?= Loyalty::earnRate() === 1 ? '' : 's' ?> for every KES 100 you spend on food, added when an order is completed and fully paid. Delivery fees do not earn points.</li>
 <li>Once you have <?= number_format(Loyalty::minRedeem()) ?> points you can use them at checkout. Each point is worth <?= money(Loyalty::pointValue()) ?> off, and points can pay for at most <?= (int)Loyalty::maxPct() ?>% of the food bill. Points do not discount delivery fees.</li>
 <li>Points have no cash value, cannot be transferred or exchanged for money, and belong to your account only.</li>
 <li>If you cancel an order, the points you used on it are returned. If an order is refunded, the points it earned are taken back in the same proportion.</li>
 <li>We may correct points added by mistake or through misuse, and we may change or end the programme. If we do, we will tell you in the app first.</li>
</ul>
<?php endif; ?>
<h2>6. Acceptable use</h2>
<p>Do not misuse the website: no false orders, no attempt to get around payment, no interfering with how the site works, and no attempts to access other people's accounts or data.</p>

<h2>7. Our responsibility</h2>
<p>We aim to prepare and deliver every order on time and as described, but delays can happen, especially during busy periods or because of traffic and network problems. To the extent the law allows, we are not responsible for losses that were not reasonably foreseeable, or for delays caused by events outside our control such as M-Pesa or network outages. Nothing in these terms limits any right you have under Kenyan consumer protection law or any liability that cannot lawfully be limited.</p>

<h2>8. Content and ownership</h2>
<p>The name, logo, menu text and images on this website belong to <?= e($name) ?> or its suppliers. You may use the site for your own ordering but may not copy it for commercial use.</p>

<h2>9. Changes to these terms</h2>
<p>We may update these terms. The date above shows the latest version, and using the site after a change means you accept the new terms. Orders you have already placed are covered by the terms that applied when you placed them.</p>

<h2>10. Governing law</h2>
<p>These terms are governed by the laws of Kenya, and the Kenyan courts have jurisdiction over any dispute, unless the law gives you the right to go elsewhere.</p>

<h2>11. Contact us</h2>
<p><?= e($name) ?><?= $addr ? ', ' . e($addr) : '' ?><?= $tel ? '. Phone ' . e($tel) : '' ?><?= $mail ? '. Email <a href="mailto:' . e($mail) . '">' . e($mail) . '</a>' : '' ?>. You can also use the Messages page after signing in.</p>
</article>
<?php page_footer(); ?>
