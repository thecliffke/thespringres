<?php
require __DIR__ . '/../app/bootstrap.php';
if (is_post()) { csrf_check(); if (!empty($_SESSION['push_hash'])) q('DELETE FROM push_subscriptions WHERE endpoint_hash=?', [$_SESSION['push_hash']]); if (Auth::user()) Audit::log('auth.logout', 'Signed out'); Auth::logout(); }
redirect('/');
