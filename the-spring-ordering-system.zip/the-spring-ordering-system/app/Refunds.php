<?php
declare(strict_types=1);

/** Refunds of deposits: M-Pesa Reversal API (automatic) or recorded manually when reversed in the M-Pesa portal. */
class Refunds {
    public static function remaining(array $p): float {
        $pending = (float)val("SELECT COALESCE(SUM(amount),0) FROM refunds WHERE payment_id=? AND status='pending'", [$p['id']]);
        return max(0.0, (float)$p['amount'] - (float)$p['reversed_amount'] - $pending);
    }
    public static function forOrder(int $orderId): array {
        return rows('SELECT r.*, u.name by_name, p.receipt_no FROM refunds r JOIN payments p ON p.id=r.payment_id LEFT JOIN users u ON u.id=r.initiated_by WHERE r.order_id=? ORDER BY r.id DESC', [$orderId]);
    }

    /** @return array{ok:bool,message:string,id?:int} */
    public static function request(int $paymentId, float $amount, string $reason, bool $cancelOrder, int $userId, string $method, string $manualRef = ''): array {
        $p = row('SELECT * FROM payments WHERE id=?', [$paymentId]);
        if (!$p) return ['ok' => false, 'message' => 'Payment not found.'];
        $o = Orders::find((int)$p['order_id']);
        $amount = round($amount);
        if ($p['kind'] !== 'deposit') return ['ok' => false, 'message' => 'Only deposit payments can be refunded here.'];
        if ((int)val("SELECT COUNT(*) FROM refunds WHERE payment_id=? AND status='pending'", [$paymentId]) > 0) return ['ok' => false, 'message' => 'A refund for this payment is already in progress.'];
        $rem = self::remaining($p);
        if ($p['method'] === 'cash' && $method !== 'manual') return ['ok' => false, 'message' => 'This deposit was paid in cash, so it cannot be reversed through M-Pesa. Choose "I already refunded it" and record how you returned the cash.'];
        if ($amount < 1 || $amount > $rem) return ['ok' => false, 'message' => 'Enter an amount between KES 1 and ' . money($rem) . '.'];
        if (trim($reason) === '') return ['ok' => false, 'message' => 'Choose or enter a reason.'];
        $ins = fn(string $status, ?string $oc, ?string $cv, ?string $desc, string $m) => exec_id('INSERT INTO refunds (order_id,payment_id,amount,reason,method,status,original_receipt,originator_conversation_id,conversation_id,result_desc,cancel_order,initiated_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
            [$o['id'], $paymentId, $amount, mb_substr($reason, 0, 255), $m, $status, $p['mpesa_receipt'], $oc, $cv, $desc, $cancelOrder ? 1 : 0, $userId]);

        if ($method === 'manual') {
            if (trim($manualRef) === '') return ['ok' => false, 'message' => 'Enter the M-Pesa reference of the refund you made in the portal.'];
            $id = $ins('pending', null, null, 'Recorded manually', 'manual');
            Audit::log('refund.requested', 'Manual refund of ' . money($amount) . ' recorded for ' . $o['order_no'] . ' (' . $reason . ')', 'order', $o['id'], ['refund_id' => $id, 'method' => 'manual', 'reference' => trim($manualRef)]);
            self::finalize($id, 0, 'Refunded manually in the M-Pesa portal', mb_substr(trim($manualRef), 0, 40), '');
            return ['ok' => true, 'message' => 'Manual refund recorded.', 'id' => $id];
        }
        if (Mpesa::env() === 'simulate') {
            $id = $ins('pending', 'SIM-' . bin2hex(random_bytes(6)), 'SIM-AG_' . bin2hex(random_bytes(6)), 'Simulated reversal requested', 'api');
            Audit::log('refund.requested', 'Refund of ' . money($amount) . ' requested for ' . $o['order_no'] . ' (' . $reason . ') [simulation]', 'order', $o['id'], ['refund_id' => $id, 'method' => 'api', 'cancel_order' => $cancelOrder]);
            return ['ok' => true, 'message' => 'Simulated refund requested. It completes in a few seconds.', 'id' => $id];
        }
        if (!$p['mpesa_receipt']) return ['ok' => false, 'message' => 'This payment has no M-Pesa code yet, so it cannot be reversed. Wait for the confirmation or use a manual refund.'];
        if (!Mpesa::reversalReady()) return ['ok' => false, 'message' => 'Reversal is not set up. Add the initiator name, initiator password and Safaricom certificate under Settings, M-Pesa, Refunds.'];
        try { $res = Mpesa::reverse((string)$p['mpesa_receipt'], $amount, 'Refund ' . $o['order_no'] . ': ' . $reason); }
        catch (Throwable $e) { return ['ok' => false, 'message' => $e->getMessage()]; }
        if ((string)($res['ResponseCode'] ?? '') !== '0') {
            $why = (string)($res['errorMessage'] ?? $res['ResponseDescription'] ?? 'Safaricom rejected the reversal request.');
            if (Mpesa::isTokenError($res)) $why = 'Safaricom still refused our access token after getting a new one. The most common cause is that the Daraja app behind these credentials does not have the Transaction Reversal API switched on for this environment, so ask Safaricom (or check My Apps on the Daraja portal) to enable it. Also check that the consumer key and secret are from the same app and the environment is right. Meanwhile you can refund in the M-Pesa portal and use "record only".';
            $ins('failed', null, null, mb_substr($why, 0, 250), 'api');
            Audit::log('refund.rejected', 'Safaricom rejected the refund of ' . money($amount) . ' for ' . $o['order_no'] . ': ' . mb_substr($why, 0, 120), 'order', $o['id'], ['payment_id' => $paymentId]);
            return ['ok' => false, 'message' => 'Safaricom rejected the request: ' . $why];
        }
        $id = $ins('pending', $res['OriginatorConversationID'] ?? null, $res['ConversationID'] ?? null, 'Waiting for Safaricom', 'api');
        Audit::log('refund.requested', 'Refund of ' . money($amount) . ' requested for ' . $o['order_no'] . ' (' . $reason . ')', 'order', $o['id'], ['refund_id' => $id, 'method' => 'api', 'original_receipt' => $p['mpesa_receipt'], 'cancel_order' => $cancelOrder]);
        return ['ok' => true, 'message' => 'Reversal request accepted by Safaricom. The result usually arrives within a minute.', 'id' => $id];
    }

    /** Apply a final result. Safe to call twice. */
    public static function finalize(int $id, int $code, string $desc, ?string $ref, string $raw): void {
        db()->beginTransaction();
        try {
            $r = row('SELECT * FROM refunds WHERE id=? FOR UPDATE', [$id]);
            if (!$r || $r['status'] === 'success') { db()->rollBack(); return; }
            if ($code !== 0) {
                if ($r['status'] === 'pending') { q("UPDATE refunds SET status='failed', result_code=?, result_desc=?, raw_result=? WHERE id=?", [$code, mb_substr($desc, 0, 250), $raw ?: null, $id]); Audit::log('refund.failed', 'Refund of ' . money($r['amount']) . ' failed: ' . mb_substr($desc, 0, 120), 'order', $r['order_id'], ['refund_id' => $id, 'code' => $code]); }
                db()->commit(); return;
            }
            q("UPDATE refunds SET status='success', result_code=0, result_desc=?, reversal_ref=?, raw_result=? WHERE id=?", [mb_substr($desc, 0, 250), $ref, $raw ?: null, $id]);
            q('UPDATE payments SET reversed_amount = reversed_amount + ? WHERE id=?', [$r['amount'], $r['payment_id']]);
            q('UPDATE orders SET amount_paid = GREATEST(0, amount_paid - ?) WHERE id=?', [$r['amount'], $r['order_id']]);
            $o = Orders::find((int)$r['order_id']);
            if ($r['cancel_order'] && !in_array($o['status'], ['completed', 'cancelled'], true)) {
                q("UPDATE orders SET status='cancelled' WHERE id=?", [$o['id']]);
                q('INSERT INTO order_events (order_id,status,user_id) VALUES (?,?,?)', [$o['id'], 'cancelled', $r['initiated_by']]);
            }
            db()->commit();
        } catch (Throwable $e) { if (db()->inTransaction()) db()->rollBack(); throw $e; }
        $o = Orders::find((int)$r['order_id']);
        if ($o['status'] === 'cancelled') Loyalty::restore($o);
        Loyalty::onRefund($o, (float)$r['amount']);
        Audit::log('refund.completed', 'Refund of ' . money($r['amount']) . ' completed for ' . $o['order_no'] . ($ref ? ' (ref ' . $ref . ')' : ''), 'order', $o['id'], ['refund_id' => $id, 'method' => $r['method'], 'reference' => $ref, 'order_cancelled' => (bool)$r['cancel_order']]);
        Notify::user((int)$o['customer_id'], 'Deposit refunded', money($r['amount']) . ' for ' . $o['order_no'] . ' was returned to your M-Pesa.', '/order.php?id=' . $o['id']);
        if (Sms::enabled() && Settings::get('sms_on_refund') === '1') {
            $msg = Sms::render('sms_tpl_refund', ['name' => explode(' ', $o['customer_name'])[0], 'amount' => money($r['amount']), 'restaurant' => Settings::get('restaurant_name'), 'order' => $o['order_no'], 'ref' => $ref ?: $r['original_receipt']]);
            Sms::send($o['phone'], $msg, 'refund', (int)$o['customer_id']);
        }
    }

    /** Reversal result posted by Safaricom to the ResultURL. */
    public static function handleResult(array $json): void {
        $res = $json['Result'] ?? null;
        if (!$res) return;
        $r = null;
        if (!empty($res['OriginatorConversationID'])) $r = row('SELECT id FROM refunds WHERE originator_conversation_id=?', [(string)$res['OriginatorConversationID']]);
        if (!$r && !empty($res['ConversationID'])) $r = row('SELECT id FROM refunds WHERE conversation_id=?', [(string)$res['ConversationID']]);
        if (!$r) return;
        self::finalize((int)$r['id'], (int)($res['ResultCode'] ?? 1), (string)($res['ResultDesc'] ?? ''), isset($res['TransactionID']) ? (string)$res['TransactionID'] : null, json_encode($json));
    }
    public static function handleTimeout(array $json): void {
        $res = $json['Result'] ?? $json;
        $r = !empty($res['OriginatorConversationID']) ? row('SELECT id FROM refunds WHERE originator_conversation_id=?', [(string)$res['OriginatorConversationID']]) : null;
        if ($r) q("UPDATE refunds SET status='failed', result_desc='Timed out at Safaricom. Check the M-Pesa portal before trying again.' WHERE id=? AND status='pending'", [$r['id']]);
    }
    /** Simulation: complete pending simulated refunds after a few seconds. */
    public static function pollSimulated(int $orderId): void {
        if (Mpesa::env() !== 'simulate') return;
        foreach (rows("SELECT id FROM refunds WHERE order_id=? AND status='pending' AND method='api' AND originator_conversation_id LIKE 'SIM-%' AND created_at < (NOW() - INTERVAL 4 SECOND)", [$orderId]) as $r)
            self::finalize((int)$r['id'], 0, 'The service request is processed successfully.', 'SIMREV' . strtoupper(bin2hex(random_bytes(3))), '');
    }
    /** A refund the admin gives up on (for example the request never completed). */
    public static function markFailed(int $id): void { Audit::log('refund.cancelled', 'Stopped waiting for refund #' . $id . ' and marked it failed', 'refund', $id); q("UPDATE refunds SET status='failed', result_desc='Cancelled by admin' WHERE id=? AND status='pending'", [$id]); }
}
