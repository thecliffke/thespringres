<?php
define('ADMIN_ONLY', true);
require __DIR__ . '/_guard.php';
$tab = in_array(get('tab'), ['general', 'mpesa', 'sms', 'push', 'email', 'google', 'loyalty', 'security'], true) ? get('tab') : 'general';
$time = fn($v, $d) => preg_match('/^\d{2}:\d{2}$/', $v) ? $v : $d;
if (is_post()) {
    csrf_check();
    $a = post('action');
    if ($a === 'general') {
        $pct = (int)post('deposit_percent');
        if ($pct < 1 || $pct > 100) { flash('danger', 'The upfront payment must be between 1 and 100 percent.'); redirect('/admin/settings.php?tab=general'); }
        foreach (['restaurant_name' => 80, 'restaurant_phone' => 30, 'restaurant_address' => 200, 'legal_email' => 160] as $k => $len) Settings::set($k, mb_substr(post($k), 0, $len));
        if (isset($_POST['remove_logo']) && Settings::get('logo') !== '') { @unlink(PUBLIC_PATH . '/uploads/' . basename(Settings::get('logo'))); Settings::set('logo', ''); }
        if (!empty($_FILES['logo']['name']) && $_FILES['logo']['error'] !== UPLOAD_ERR_NO_FILE) {
            $f = $_FILES['logo'];
            $mime = $f['error'] === UPLOAD_ERR_OK ? (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']) : '';
            $ext = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp'][$mime] ?? null;
            if (!$ext || $f['size'] > 2 * 1024 * 1024) flash('danger', 'Logo not saved: upload a PNG, JPG or WebP image under 2 MB.');
            else {
                $name = 'logo-' . bin2hex(random_bytes(6)) . '.' . $ext;
                if (move_uploaded_file($f['tmp_name'], PUBLIC_PATH . '/uploads/' . $name)) { if (Settings::get('logo') !== '') @unlink(PUBLIC_PATH . '/uploads/' . basename(Settings::get('logo'))); Settings::set('logo', $name); }
                else flash('danger', 'Logo not saved: public/uploads is not writable.');
            }
        }
        Settings::set('deposit_percent', (string)$pct); Settings::set('delivery_fee', (string)max(0, (int)post('delivery_fee')));
        Settings::set('open_time', $time(post('open_time'), '10:00')); Settings::set('close_time', $time(post('close_time'), '21:30'));
        foreach (['lead_dine_in', 'lead_delivery', 'slot_minutes'] as $k) Settings::set($k, (string)max(0, (int)post($k)));
        flash('success', 'Settings saved. New orders will use ' . $pct . '% upfront.');
    } elseif ($a === 'mpesa' || $a === 'mpesa_test') {
        Settings::set('mpesa_env', in_array(post('mpesa_env'), ['simulate', 'sandbox', 'production'], true) ? post('mpesa_env') : 'simulate');
        Settings::set('mpesa_shortcode', preg_replace('/\D/', '', post('mpesa_shortcode')));
        Settings::set('mpesa_party_b', preg_replace('/\D/', '', post('mpesa_party_b')));
        Settings::set('mpesa_transaction_type', post('mpesa_transaction_type') === 'CustomerBuyGoodsOnline' ? 'CustomerBuyGoodsOnline' : 'CustomerPayBillOnline');
        Settings::set('mpesa_callback_url', post('mpesa_callback_url'));
        Settings::set('mpesa_initiator', post('mpesa_initiator')); Settings::set('mpesa_reversal_receiver', preg_replace('/\D/', '', post('mpesa_reversal_receiver')));
        Settings::set('mpesa_reversal_idtype', preg_replace('/\D/', '', post('mpesa_reversal_idtype')) ?: '11');
        if (($_POST['mpesa_initiator_pass'] ?? '') !== '') Settings::set('mpesa_initiator_pass', (string)$_POST['mpesa_initiator_pass']);
        if (!empty($_FILES['mpesa_cert']['name']) && $_FILES['mpesa_cert']['error'] === UPLOAD_ERR_OK) {
            $ce = Mpesa::saveCertificate($_FILES['mpesa_cert']['tmp_name'], post('mpesa_env') === 'production' ? 'production' : 'sandbox');
            if (!$ce) Audit::log('settings.mpesa_certificate', 'Uploaded the Safaricom certificate for ' . (post('mpesa_env') === 'production' ? 'production' : 'sandbox'), 'setting', 'mpesa_cert');
            flash($ce ? 'danger' : 'success', $ce ?: 'Safaricom certificate saved.');
        }
        foreach (['mpesa_consumer_key', 'mpesa_consumer_secret', 'mpesa_passkey'] as $k) if (($_POST[$k] ?? '') !== '') Settings::set($k, trim((string)$_POST[$k]));
        if ($a === 'mpesa_test') { $r = Mpesa::testConnection(); Audit::log('settings.mpesa_test', 'Tested the M-Pesa connection: ' . ($r['ok'] ? 'ok' : 'failed'), 'setting', 'mpesa'); flash($r['ok'] ? 'success' : 'danger', 'Saved. ' . $r['message']); }
        else flash('success', 'M-Pesa settings saved.');
    } elseif ($a === 'regen_token') { Settings::set('mpesa_callback_token', bin2hex(random_bytes(16))); flash('success', 'New callback token generated. The callback URL below has changed.'); }
    elseif ($a === 'push') {
        Settings::set('push_enabled', isset($_POST['push_enabled']) ? '1' : '0'); Settings::set('push_subject', mb_substr(post('push_subject'), 0, 160));
        flash('success', 'Push settings saved.');
    }
    elseif ($a === 'push_test') { [$ok, $n] = Push::sendNow((int)$ME['id'], 'Test notification', 'Push notifications are working.', '/admin/'); flash($ok ? 'success' : 'warning', $n === 0 ? 'You have no device registered yet. Open the site on your phone or browser, sign in and press Turn on notifications.' : "Delivered to $ok of $n of your device(s)."); }
    elseif ($a === 'push_regen') { Audit::log('settings.push_keys', 'Created new push notification keys (all devices must re-subscribe)', 'setting', 'push'); Push::generateKeys(); q('DELETE FROM push_subscriptions'); flash('success', 'New push keys created. Everyone will be asked to turn notifications on again.'); }
    elseif ($a === 'email' || $a === 'email_test') {
        foreach (['smtp_host' => 120, 'smtp_user' => 160, 'mail_from' => 160, 'mail_from_name' => 80] as $k => $len) Settings::set($k, mb_substr(post($k), 0, $len));
        Settings::set('smtp_port', (string)(max(1, (int)post('smtp_port')) ?: 587)); Settings::set('smtp_secure', in_array(post('smtp_secure'), ['tls', 'ssl', 'none'], true) ? post('smtp_secure') : 'tls');
        if (($_POST['smtp_pass'] ?? '') !== '') Settings::set('smtp_pass', (string)$_POST['smtp_pass']);
        if ($a === 'email_test') { $r = Mailer::send(post('test_email'), 'Test email from ' . Settings::get('restaurant_name'), '<p>If you can read this, your email settings work.</p>'); Audit::log('settings.email_test', 'Sent a test email: ' . ($r['ok'] ? 'ok' : 'failed'), 'setting', 'email'); flash($r['ok'] ? 'success' : 'danger', 'Saved. ' . $r['message']); }
        else flash('success', 'Email settings saved.');
    }
    elseif ($a === 'google') {
        $id = trim(post('google_client_id'));
        if ($id !== '' && !preg_match('/^[\w.\-]+\.apps\.googleusercontent\.com$/', $id)) { flash('danger', 'That does not look like a Google client ID. It ends in .apps.googleusercontent.com.'); redirect('/admin/settings.php?tab=google'); }
        Settings::set('google_client_id', $id);
        if (($_POST['google_client_secret'] ?? '') !== '') Settings::set('google_client_secret', trim((string)$_POST['google_client_secret']));
        $on = isset($_POST['google_enabled']) ? '1' : '0';
        if ($on === '1' && (!Settings::has('google_client_id') || !Settings::has('google_client_secret'))) { $on = '0'; flash('warning', 'Add both the client ID and the client secret before turning Google sign-in on.'); }
        else flash('success', $on === '1' ? 'Saved. The Sign in with Google button is now on the sign-in and sign-up pages.' : 'Google settings saved. Google sign-in is off.');
        Settings::set('google_enabled', $on);
    }
    elseif ($a === 'loyalty') {
        Settings::set('loyalty_enabled', isset($_POST['loyalty_enabled']) ? '1' : '0');
        Settings::set('loyalty_earn_per_100', (string)max(0, min(100, (int)post('loyalty_earn_per_100'))));
        Settings::set('loyalty_point_value', (string)max(1, min(100, (int)post('loyalty_point_value'))));
        Settings::set('loyalty_min_redeem', (string)max(1, min(100000, (int)post('loyalty_min_redeem'))));
        Settings::set('loyalty_max_pct', (string)max(1, min(50, (int)post('loyalty_max_pct'))));
        flash('success', Settings::get('loyalty_enabled') === '1' ? 'Loyalty settings saved. The programme is running.' : 'Loyalty settings saved. The programme is switched off: no points are earned or used.');
    }
    elseif ($a === 'security') {
        Settings::set('passkeys_enabled', isset($_POST['passkeys_enabled']) ? '1' : '0'); Settings::set('login_max_attempts', (string)max(3, min(50, (int)post('login_max_attempts')))); Settings::set('login_lockout_minutes', (string)max(1, min(1440, (int)post('login_lockout_minutes'))));
        flash('success', 'Security settings saved.');
    }
    elseif ($a === 'unlock_ip') { Auth::unlock(post('ip')); flash('success', 'Unlocked. That address can sign in again right away.'); }
    elseif ($a === 'unlock_all') { Auth::unlock(null); flash('success', 'All sign-in lockouts cleared.'); }
    elseif ($a === 'sms_reset') { Audit::log('settings.sms_templates_reset', 'Reset all SMS message texts to the defaults', 'setting', 'sms'); foreach (['placed', 'ready', 'dispatched', 'balance', 'refund', 'deposit', 'reminder'] as $k) Settings::set('sms_tpl_' . $k, Settings::DEFAULTS['sms_tpl_' . $k]); flash('success', 'SMS message texts reset to the defaults.'); }
    elseif ($a === 'sms' || $a === 'sms_test') {
        Settings::set('sms_enabled', isset($_POST['sms_enabled']) ? '1' : '0');
        Settings::set('sms_provider', post('sms_provider') === 'smsleopard' ? 'smsleopard' : 'africastalking');
        Settings::set('sl_sender_id', mb_substr(post('sl_sender_id'), 0, 20));
        foreach (['sl_api_key', 'sl_api_secret'] as $k) if (($_POST[$k] ?? '') !== '') Settings::set($k, trim((string)$_POST[$k]));
        Settings::set('at_env', post('at_env') === 'live' ? 'live' : 'sandbox');
        Settings::set('at_username', post('at_username')); Settings::set('at_sender_id', post('at_sender_id'));
        if (($_POST['at_api_key'] ?? '') !== '') Settings::set('at_api_key', trim((string)$_POST['at_api_key']));
        foreach (['placed', 'ready', 'dispatched', 'balance', 'refund', 'deposit'] as $e) { Settings::set('sms_on_' . $e, isset($_POST['sms_on_' . $e]) ? '1' : '0'); if (post('sms_tpl_' . $e) !== '') Settings::set('sms_tpl_' . $e, mb_substr(post('sms_tpl_' . $e), 0, 300)); }
        if (post('sms_tpl_reminder') !== '') Settings::set('sms_tpl_reminder', mb_substr(post('sms_tpl_reminder'), 0, 300));
        if ($a === 'sms_test') {
            $r = Sms::send(post('test_phone'), 'Test message from ' . Settings::get('restaurant_name') . '. SMS is working.', 'test', null, true);
            Audit::log('settings.sms_test', 'Sent a test SMS: ' . ($r['ok'] ? 'ok' : 'failed'), 'setting', 'sms');
            flash($r['ok'] ? 'success' : 'danger', 'Saved. ' . $r['message'] . ' Check the SMS log for details.');
        } else flash('success', 'SMS settings saved.');
    }
    redirect('/admin/settings.php?tab=' . $tab);
}
$S = fn($k) => e(Settings::get($k));
$saved = fn($k) => Settings::has($k) ? '<span class="badge text-bg-success ms-1">saved</span>' : '<span class="badge text-bg-secondary ms-1">not set</span>';
$cb = Mpesa::callbackUrl();
$cbOk = str_starts_with($cb, 'https://') && !preg_match('#//(localhost|127\.|192\.168\.|10\.)#', $cb);
page_header('Settings', ['admin' => true, 'active' => 'settings']);
?>
<ul class="nav nav-tabs mb-3">
 <li class="nav-item"><a class="nav-link <?= $tab === 'general' ? 'active' : '' ?>" href="?tab=general"><i class="bi bi-shop me-1"></i>General</a></li>
 <li class="nav-item"><a class="nav-link <?= $tab === 'mpesa' ? 'active' : '' ?>" href="?tab=mpesa"><i class="bi bi-phone me-1"></i>M-Pesa</a></li>
 <li class="nav-item"><a class="nav-link <?= $tab === 'sms' ? 'active' : '' ?>" href="?tab=sms"><i class="bi bi-chat-dots me-1"></i>SMS</a></li>
 <li class="nav-item"><a class="nav-link <?= $tab === 'push' ? 'active' : '' ?>" href="?tab=push"><i class="bi bi-broadcast me-1"></i>Push</a></li>
 <li class="nav-item"><a class="nav-link <?= $tab === 'email' ? 'active' : '' ?>" href="?tab=email"><i class="bi bi-envelope me-1"></i>Email</a></li>
 <li class="nav-item"><a class="nav-link <?= $tab === 'google' ? 'active' : '' ?>" href="?tab=google"><i class="bi bi-google me-1"></i>Google</a></li>
 <li class="nav-item"><a class="nav-link <?= $tab === 'loyalty' ? 'active' : '' ?>" href="?tab=loyalty"><i class="bi bi-star me-1"></i>Loyalty</a></li>
 <li class="nav-item"><a class="nav-link <?= $tab === 'security' ? 'active' : '' ?>" href="?tab=security"><i class="bi bi-shield-lock me-1"></i>Security</a></li></ul>

<?php if ($tab === 'general'): ?>
<form method="post" enctype="multipart/form-data" class="card" style="max-width:46rem"><div class="card-body"><?= csrf_field() ?><input type="hidden" name="action" value="general">
 <div class="row g-3">
  <div class="col-12"><label class="form-label">Restaurant logo</label>
   <div class="d-flex align-items-center gap-3 flex-wrap"><?php if (Settings::get('logo')): ?><img src="<?= e(url('uploads/' . Settings::get('logo'))) ?>" alt="Current logo" style="height:56px;max-width:180px;object-fit:contain;background:#fff;border-radius:.6rem;padding:.3rem;border:1px solid var(--bs-border-color)"><?php endif; ?>
   <div class="flex-grow-1"><input class="form-control" type="file" name="logo" accept="image/png,image/jpeg,image/webp"><div class="form-text">PNG, JPG or WebP, max 2 MB. A square or wide logo with a transparent background looks best. It appears in the header, on sign-in pages and on receipts.</div>
   <?php if (Settings::get('logo')): ?><div class="form-check mt-1"><input class="form-check-input" type="checkbox" name="remove_logo" id="rl"><label class="form-check-label small" for="rl">Remove the current logo</label></div><?php endif; ?></div></div></div>
  <div class="col-md-6"><label class="form-label">Restaurant name</label><input class="form-control" name="restaurant_name" value="<?= $S('restaurant_name') ?>" required></div>
  <div class="col-md-6"><label class="form-label">Phone (shown on receipts)</label><input class="form-control" name="restaurant_phone" value="<?= $S('restaurant_phone') ?>"></div>
  <div class="col-12"><label class="form-label">Address (shown on receipts)</label><input class="form-control" name="restaurant_address" value="<?= $S('restaurant_address') ?>"></div>
  <div class="col-12"><label class="form-label">Contact email (shown on the Privacy Policy and Terms pages)</label><input class="form-control" type="email" name="legal_email" value="<?= $S('legal_email') ?>" placeholder="hello@yourrestaurant.co.ke"><div class="form-text">Customers use this address for privacy requests and questions about the terms. If left empty, the sender address from the Email tab is used.</div></div>
  <div class="col-md-6"><label class="form-label">Upfront payment (%)</label><input class="form-control" type="number" min="1" max="100" name="deposit_percent" value="<?= $S('deposit_percent') ?>" required><div class="form-text">Customers pay this share when placing an order. On KES 1,000 that is KES <?= (int)ceil(1000 * Settings::depositPct() / 100) ?> now.</div></div>
  <div class="col-md-6"><label class="form-label">Delivery fee (KES)</label><input class="form-control" type="number" min="0" name="delivery_fee" value="<?= $S('delivery_fee') ?>"></div>
  <div class="col-md-6"><label class="form-label">Opens at</label><input class="form-control" type="time" name="open_time" value="<?= $S('open_time') ?>" required></div>
  <div class="col-md-6"><label class="form-label">Last orders at</label><input class="form-control" type="time" name="close_time" value="<?= $S('close_time') ?>" required></div>
  <div class="col-md-4"><label class="form-label">Dine-in lead time (min)</label><input class="form-control" type="number" min="0" name="lead_dine_in" value="<?= $S('lead_dine_in') ?>"></div>
  <div class="col-md-4"><label class="form-label">Delivery lead time (min)</label><input class="form-control" type="number" min="0" name="lead_delivery" value="<?= $S('lead_delivery') ?>"></div>
  <div class="col-md-4"><label class="form-label">Time slot step (min)</label><input class="form-control" type="number" min="10" name="slot_minutes" value="<?= $S('slot_minutes') ?>"></div>
 </div><button class="btn btn-primary mt-4">Save settings</button></div></form>

<?php elseif ($tab === 'mpesa'): ?>
<div class="row g-3"><div class="col-xl-7"><form method="post" enctype="multipart/form-data" class="card"><div class="card-body"><?= csrf_field() ?>
 <h2 class="h5 sp-display">Safaricom Daraja (M-Pesa Express / STK Push)</h2>
 <p class="text-body-secondary small">Create an app on the <b>Daraja portal</b> (developer.safaricom.co.ke), enable <i>M-Pesa Express</i>, and paste its details here. Secrets are encrypted in the database and never shown again; leave a secret box empty to keep the saved one.</p>
 <label class="form-label">Environment</label>
 <select class="form-select mb-3" name="mpesa_env"><option value="simulate" <?= Settings::get('mpesa_env') === 'simulate' ? 'selected' : '' ?>>Simulation (no real money, for testing the app)</option><option value="sandbox" <?= Settings::get('mpesa_env') === 'sandbox' ? 'selected' : '' ?>>Sandbox (Safaricom test environment)</option><option value="production" <?= Settings::get('mpesa_env') === 'production' ? 'selected' : '' ?>>Production (live payments)</option></select>
 <div class="row g-3">
  <div class="col-12"><label class="form-label">Consumer key <?= $saved('mpesa_consumer_key') ?></label><input class="form-control" type="password" name="mpesa_consumer_key" value="" autocomplete="off" placeholder="<?= Settings::has('mpesa_consumer_key') ? 'Saved (type to replace)' : 'Paste consumer key' ?>"></div>
  <div class="col-12"><label class="form-label">Consumer secret <?= $saved('mpesa_consumer_secret') ?></label><input class="form-control" type="password" name="mpesa_consumer_secret" value="" autocomplete="off" placeholder="<?= Settings::has('mpesa_consumer_secret') ? 'Saved (type to replace)' : 'Paste consumer secret' ?>"></div>
  <div class="col-md-6"><label class="form-label">Paybill number, or store number for a Till (business shortcode)</label><input class="form-control" name="mpesa_shortcode" inputmode="numeric" value="<?= $S('mpesa_shortcode') ?>" placeholder="e.g. 174379 for sandbox"></div>
  <div class="col-md-6"><label class="form-label">Transaction type</label><select class="form-select" name="mpesa_transaction_type"><option value="CustomerPayBillOnline">Paybill (CustomerPayBillOnline)</option><option value="CustomerBuyGoodsOnline" <?= Settings::get('mpesa_transaction_type') === 'CustomerBuyGoodsOnline' ? 'selected' : '' ?>>Till (CustomerBuyGoodsOnline)</option></select></div>
  <div class="col-12"><label class="form-label">Till number (only for Buy Goods)</label><input class="form-control" name="mpesa_party_b" inputmode="numeric" value="<?= $S('mpesa_party_b') ?>" placeholder="Leave empty for a Paybill"><div class="form-text">Paybill: leave this empty. Till (Buy Goods): put the <b>store (head office) number</b> above, the <b>till number</b> here, and choose "Till" as the transaction type.</div></div>
  <div class="col-12"><label class="form-label">Lipa na M-Pesa passkey <?= $saved('mpesa_passkey') ?></label><input class="form-control" type="password" name="mpesa_passkey" value="" autocomplete="off" placeholder="<?= Settings::has('mpesa_passkey') ? 'Saved (type to replace)' : 'Paste passkey' ?>"></div>
  <div class="col-12"><label class="form-label">Callback URL override (optional)</label><input class="form-control" name="mpesa_callback_url" value="<?= $S('mpesa_callback_url') ?>" placeholder="Leave empty to use the address below"><div class="form-text">Only needed if your site sits behind a proxy or tunnel.</div></div>
 </div>
 <hr><h2 class="h5 sp-display">Refunds (M-Pesa reversal)</h2>
 <p class="text-body-secondary small">Needed only to refund deposits automatically. You need an <b>M-Pesa API initiator</b> (an operator on your M-Pesa organisation portal that Safaricom has allowed to reverse transactions) and the <b>Safaricom public certificate</b> for the environment you chose above (download it from the Daraja portal under Going Live or API documentation). Without these, refunds can still be recorded manually after you reverse the payment in the M-Pesa portal.</p>
 <div class="row g-3">
  <div class="col-md-6"><label class="form-label">Initiator name</label><input class="form-control" name="mpesa_initiator" value="<?= $S('mpesa_initiator') ?>" autocomplete="off"></div>
  <div class="col-md-6"><label class="form-label">Initiator password <?= $saved('mpesa_initiator_pass') ?></label><input class="form-control" type="password" name="mpesa_initiator_pass" value="" autocomplete="off" placeholder="<?= Settings::has('mpesa_initiator_pass') ? 'Saved (type to replace)' : 'Paste initiator password' ?>"></div>
  <div class="col-12"><label class="form-label">Safaricom certificate (.cer) for the selected environment <span class="badge text-bg-<?= Mpesa::hasCert('sandbox') ? 'success' : 'secondary' ?>">sandbox <?= Mpesa::hasCert('sandbox') ? 'uploaded' : 'missing' ?></span> <span class="badge text-bg-<?= Mpesa::hasCert('production') ? 'success' : 'secondary' ?>">production <?= Mpesa::hasCert('production') ? 'uploaded' : 'missing' ?></span></label><input class="form-control" type="file" name="mpesa_cert" accept=".cer,.crt,.pem"></div>
  <div class="col-md-6"><label class="form-label">Receiver party (optional)</label><input class="form-control" name="mpesa_reversal_receiver" inputmode="numeric" value="<?= $S('mpesa_reversal_receiver') ?>" placeholder="Default: <?= e(Settings::payNumber() ?: 'your pay number') ?>"><div class="form-text">The number that received the customer's payment.</div></div>
  <div class="col-md-6"><label class="form-label">Receiver identifier type</label><input class="form-control" name="mpesa_reversal_idtype" inputmode="numeric" value="<?= $S('mpesa_reversal_idtype') ?>"><div class="form-text">Leave as 11 unless Safaricom tells you otherwise.</div></div>
 </div>
 <div class="d-flex flex-wrap gap-2 mt-4"><button class="btn btn-primary" name="action" value="mpesa">Save M-Pesa settings</button><button class="btn btn-outline-primary" name="action" value="mpesa_test">Save and test connection</button></div>
</div></form></div>
<div class="col-xl-5 vstack gap-3">
 <div class="card"><div class="card-body"><h2 class="h5 sp-display">Callback URL</h2><p class="small text-body-secondary">Safaricom sends the payment result here. It is added to every request automatically and includes a secret token, so nothing needs to be registered on the Daraja portal.</p>
  <input class="form-control form-control-sm font-monospace" readonly value="<?= e($cb) ?>" onclick="this.select()">
  <?php if (Mpesa::env() !== 'simulate' && !$cbOk): ?><div class="alert alert-warning small mt-2 mb-0">This address is not a public HTTPS URL, so Safaricom cannot reach it. Payments will still be confirmed by the status check, but the M-Pesa code may be delayed. Set <code>app_url</code> in <code>config/config.php</code> to your live HTTPS address.</div><?php endif; ?>
  <form method="post" class="mt-2" data-confirm="Generate a new token?"><?= csrf_field() ?><button class="btn btn-outline-secondary btn-sm" name="action" value="regen_token">Regenerate token</button></form></div></div>
 <div class="card"><div class="card-body small"><h2 class="h6">Going live checklist</h2><ol class="mb-0 ps-3"><li>Test in <b>Sandbox</b> with Safaricom's test shortcode and passkey from the Daraja portal.</li><li>Apply for Go Live and receive your production consumer key, secret, Paybill and passkey.</li><li>Paste them here, set the environment to <b>Production</b>, and make a small real payment.</li><li>Check <b>Payments, All M-Pesa requests</b> for any failures.</li></ol></div></div>
</div></div>

<?php elseif ($tab === 'sms'): ?>
<div class="row g-3"><div class="col-xl-8"><form method="post" class="card"><div class="card-body"><?= csrf_field() ?>
 <h2 class="h5 sp-display">SMS provider</h2>
 <label class="form-label" for="prov">Send SMS through</label>
 <select class="form-select mb-3" id="prov" name="sms_provider"><option value="africastalking" <?= Sms::provider() === 'africastalking' ? 'selected' : '' ?>>Africa's Talking</option><option value="smsleopard" <?= Sms::provider() === 'smsleopard' ? 'selected' : '' ?>>SMS Leopard</option></select>
 <div id="prov-sl">
  <p class="text-body-secondary small">In your SMS Leopard dashboard open Settings, then API Keys, and create a key. You get an <b>API key</b> and an <b>API secret</b>. The sender ID must be one assigned to your account; until you have one, <code>SMS_Leopard</code> works for testing. See developers.smsleopard.com.</p>
  <div class="row g-3 mb-3">
   <div class="col-md-6"><label class="form-label">API key <?= $saved('sl_api_key') ?></label><input class="form-control" type="password" name="sl_api_key" value="" autocomplete="off" placeholder="<?= Settings::has('sl_api_key') ? 'Saved (type to replace)' : 'Paste API key' ?>"></div>
   <div class="col-md-6"><label class="form-label">API secret <?= $saved('sl_api_secret') ?></label><input class="form-control" type="password" name="sl_api_secret" value="" autocomplete="off" placeholder="<?= Settings::has('sl_api_secret') ? 'Saved (type to replace)' : 'Paste API secret' ?>"></div>
   <div class="col-md-6"><label class="form-label">Sender ID</label><input class="form-control" name="sl_sender_id" value="<?= $S('sl_sender_id') ?>" placeholder="SMS_Leopard"></div>
  </div>
 </div>
 <div id="prov-at">
 <h3 class="h6">Africa's Talking</h3>
 <p class="text-body-secondary small">Get your username and API key from the Africa's Talking dashboard (Settings, API Key). In <b>Sandbox</b> the username must be <code>sandbox</code> and messages only appear in the AT simulator. The API key is encrypted and never shown again; leave it empty to keep the saved one.</p>
 <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" role="switch" id="se" name="sms_enabled" <?= Settings::get('sms_enabled') === '1' ? 'checked' : '' ?>><label class="form-check-label fw-semibold" for="se">Send SMS notifications</label></div>
 <div class="row g-3">
  <div class="col-md-4"><label class="form-label">Environment</label><select class="form-select" name="at_env"><option value="sandbox" <?= Settings::get('at_env') !== 'live' ? 'selected' : '' ?>>Sandbox</option><option value="live" <?= Settings::get('at_env') === 'live' ? 'selected' : '' ?>>Live</option></select></div>
  <div class="col-md-4"><label class="form-label">Username</label><input class="form-control" name="at_username" value="<?= $S('at_username') ?>" required></div>
  <div class="col-md-4"><label class="form-label">Sender ID (optional)</label><input class="form-control" name="at_sender_id" value="<?= $S('at_sender_id') ?>" placeholder="e.g. THESPRING"></div>
  <div class="col-12"><label class="form-label">API key <?= $saved('at_api_key') ?></label><input class="form-control" type="password" name="at_api_key" value="" autocomplete="off" placeholder="<?= Settings::has('at_api_key') ? 'Saved (type to replace)' : 'Paste API key' ?>"></div>
 </div>
 </div>
 <script>(function(){var s=document.getElementById('prov');function t(){document.getElementById('prov-sl').style.display=s.value==='smsleopard'?'':'none';document.getElementById('prov-at').style.display=s.value==='smsleopard'?'none':''}s.addEventListener('change',t);t()})();</script>
 <hr><h3 class="h6">Which events send an SMS</h3>
 <?php foreach (['placed' => 'Order confirmed (deposit received)', 'ready' => 'Order ready', 'dispatched' => 'Order dispatched', 'balance' => 'Balance due (manual reminders)', 'refund' => 'Deposit refunded', 'deposit' => 'Deposit reminder (sent by staff to unpaid orders)'] as $k => $l): ?>
  <div class="mb-3"><div class="form-check"><input class="form-check-input" type="checkbox" id="on<?= $k ?>" name="sms_on_<?= $k ?>" <?= Settings::get('sms_on_' . $k) === '1' ? 'checked' : '' ?>><label class="form-check-label fw-semibold" for="on<?= $k ?>"><?= e($l) ?></label></div>
  <textarea class="form-control form-control-sm mt-1" rows="2" name="sms_tpl_<?= $k ?>" aria-label="Message for <?= e($l) ?>"><?= $S('sms_tpl_' . $k) ?></textarea></div><?php endforeach; ?>
 <div class="mb-3"><label class="form-label fw-semibold">Order reminder message</label><textarea class="form-control form-control-sm" rows="2" name="sms_tpl_reminder"><?= $S('sms_tpl_reminder') ?></textarea></div>
 <p class="form-text">Placeholders: {name} {order} {restaurant} {paid} {balance} {pay_details} (for example "Till 123456") {till} {amount} {deposit} {ref} {label} {link}. Use <b>{pay_details}</b> for payment instructions: it shows the Till number for Till businesses.</p>
 <button class="btn btn-outline-secondary btn-sm mb-3" name="action" value="sms_reset" onclick="return confirm('Reset all SMS texts to the defaults?')">Reset message texts to defaults</button>
 <hr><label class="form-label">Send a test SMS to</label>
 <div class="input-group mb-3"><input class="form-control" name="test_phone" placeholder="0712 345 678" value="<?= e($ME['phone']) ?>"><button class="btn btn-outline-primary" name="action" value="sms_test">Save and send test</button></div>
 <button class="btn btn-primary" name="action" value="sms">Save SMS settings</button>
</div></form></div>
<div class="col-xl-4"><div class="card"><div class="card-body small"><h2 class="h6">Reminders by SMS</h2><p>Customer reminders are checked whenever someone has the site open and by the scheduled task below, so they fire even when nobody is online.</p><code class="d-block">* * * * * php <?= e(ROOT) ?>/bin/cron.php</code><p class="mt-2 mb-0">Add this line in cPanel, Cron Jobs (run every minute).</p></div></div></div></div>
<?php elseif ($tab === 'push'): $subN = (int)val('SELECT COUNT(*) FROM push_subscriptions'); $subU = (int)val('SELECT COUNT(DISTINCT user_id) FROM push_subscriptions'); $cronAge = time() - (int)Settings::get('cron_last_run'); ?>
<div class="row g-3"><div class="col-xl-7"><form method="post" class="card"><div class="card-body"><?= csrf_field() ?>
 <h2 class="h5 sp-display">Push notifications</h2>
 <p class="text-body-secondary small">Order updates, new-order alerts for staff and customer reminders are sent to phones and computers, even when the app is closed. Each person turns them on once per device (a prompt appears after sign-in, and on the Notifications page). No account with a third party is needed.</p>
 <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" role="switch" id="pe" name="push_enabled" <?= Settings::get('push_enabled') === '1' ? 'checked' : '' ?>><label class="form-check-label fw-semibold" for="pe">Send push notifications</label></div>
 <label class="form-label">Contact for the push services (email or https address)</label><input class="form-control" name="push_subject" value="<?= $S('push_subject') ?>" placeholder="Default: your Email settings address or the admin email"><div class="form-text">Sent with every message so Google, Apple and Mozilla can reach you if something is wrong.</div>
 <div class="d-flex flex-wrap gap-2 mt-4"><button class="btn btn-primary" name="action" value="push">Save</button><button class="btn btn-outline-primary" name="action" value="push_test">Send me a test push</button></div>
</div></form></div>
<div class="col-xl-5 vstack gap-3">
 <div class="card"><div class="card-body small"><h2 class="h6">Status</h2>
  <div class="d-flex justify-content-between py-1"><span>Devices registered</span><b><?= $subN ?> (<?= $subU ?> people)</b></div>
  <div class="d-flex justify-content-between py-1"><span>Secure connection (HTTPS)</span><b class="<?= is_https() ? 'text-success' : 'text-danger' ?>"><?= is_https() ? 'Yes' : 'No' ?></b></div>
  <div class="d-flex justify-content-between py-1"><span>Scheduled task (cron)</span><b class="<?= $cronAge < 600 ? 'text-success' : 'text-danger' ?>"><?= (int)Settings::get('cron_last_run') ? ($cronAge < 600 ? 'Running' : 'Last ran ' . (int)round($cronAge / 60) . ' min ago') : 'Never ran' ?></b></div>
  <?php if (!is_https()): ?><div class="alert alert-warning py-2 mt-2 mb-0">Browsers only allow push notifications on HTTPS (or localhost).</div><?php endif; ?></div></div>
 <div class="card"><div class="card-body small"><h2 class="h6">Reminders when nobody has the site open</h2><p>A reminder is only created at its time when something runs the check. Add this cron job (cPanel, Cron Jobs, every minute) so reminders and their push notifications always go out:</p><code class="d-block mb-2">* * * * * php <?= e(ROOT) ?>/bin/cron.php</code>
  <p class="mb-2"><b>iPhone:</b> push works on iOS 16.4 or newer, after the customer taps Share, then Add to Home Screen, and opens the app from the home screen.</p>
  <form method="post" data-confirm="Create new keys? Every device will need to turn notifications on again."><?= csrf_field() ?><button class="btn btn-outline-danger btn-sm" name="action" value="push_regen">Create new push keys</button></form></div></div>
</div></div>

<?php elseif ($tab === 'email'): ?>
<div class="row g-3"><div class="col-xl-7"><form method="post" class="card"><div class="card-body"><?= csrf_field() ?>
 <h2 class="h5 sp-display">Email (password reset links)</h2>
 <p class="text-body-secondary small">Use the SMTP details of a mailbox on your domain (cPanel, Email Accounts, Connect Devices) or a provider such as Brevo or Gmail with an app password. If left empty the app tries PHP mail(), which many hosts block or send to spam.</p>
 <div class="row g-3">
  <div class="col-md-8"><label class="form-label">SMTP host</label><input class="form-control" name="smtp_host" value="<?= $S('smtp_host') ?>" placeholder="mail.yourdomain.co.ke"></div>
  <div class="col-md-4"><label class="form-label">Port</label><input class="form-control" type="number" name="smtp_port" value="<?= $S('smtp_port') ?>"></div>
  <div class="col-md-4"><label class="form-label">Security</label><select class="form-select" name="smtp_secure"><option value="tls" <?= Settings::get('smtp_secure') === 'tls' ? 'selected' : '' ?>>STARTTLS (port 587)</option><option value="ssl" <?= Settings::get('smtp_secure') === 'ssl' ? 'selected' : '' ?>>SSL (port 465)</option><option value="none" <?= Settings::get('smtp_secure') === 'none' ? 'selected' : '' ?>>None (port 25)</option></select></div>
  <div class="col-md-4"><label class="form-label">Username</label><input class="form-control" name="smtp_user" value="<?= $S('smtp_user') ?>" autocomplete="off"></div>
  <div class="col-md-4"><label class="form-label">Password <?= $saved('smtp_pass') ?></label><input class="form-control" type="password" name="smtp_pass" value="" autocomplete="off" placeholder="<?= Settings::has('smtp_pass') ? 'Saved (type to replace)' : 'Mailbox password' ?>"></div>
  <div class="col-md-6"><label class="form-label">From email</label><input class="form-control" type="email" name="mail_from" value="<?= $S('mail_from') ?>" placeholder="no-reply@yourdomain.co.ke"></div>
  <div class="col-md-6"><label class="form-label">From name</label><input class="form-control" name="mail_from_name" value="<?= $S('mail_from_name') ?>" placeholder="<?= $S('restaurant_name') ?>"></div>
 </div>
 <hr><label class="form-label">Send a test email to</label>
 <div class="input-group mb-3"><input class="form-control" type="email" name="test_email" value="<?= e($ME['email']) ?>"><button class="btn btn-outline-primary" name="action" value="email_test">Save and send test</button></div>
 <button class="btn btn-primary" name="action" value="email">Save email settings</button>
</div></form></div></div>

<?php elseif ($tab === 'loyalty'): $outPts = (int)val('SELECT COALESCE(SUM(points),0) FROM loyalty_ledger'); $holders = (int)val('SELECT COUNT(*) FROM (SELECT user_id FROM loyalty_ledger GROUP BY user_id HAVING SUM(points)>0) x'); ?>
<div class="row g-3"><div class="col-xl-7"><form method="post" class="card"><div class="card-body"><?= csrf_field() ?><input type="hidden" name="action" value="loyalty">
 <h2 class="h5 sp-display">Loyalty points</h2>
 <p class="text-body-secondary small">Customers earn points when an order is completed (so it has been paid in full) and can use them as a discount on the food bill at checkout. Points never discount the delivery fee, and the discount can never cover more than the share you set below.</p>
 <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" role="switch" name="loyalty_enabled" id="le" <?= Loyalty::enabled() ? 'checked' : '' ?>><label class="form-check-label" for="le">Run the loyalty programme (earn and use points)</label></div>
 <div class="row g-3">
  <div class="col-sm-6"><label class="form-label">Points earned per KES 100 spent</label><input class="form-control" type="number" min="0" max="100" name="loyalty_earn_per_100" value="<?= (int)Loyalty::earnRate() ?>"><div class="form-text">2 means a KES 1,000 order earns 20 points. Use 0 to stop earning.</div></div>
  <div class="col-sm-6"><label class="form-label">Value of one point (KES)</label><input class="form-control" type="number" min="1" max="100" name="loyalty_point_value" value="<?= (int)Loyalty::pointValue() ?>"><div class="form-text">Whole shillings, so totals stay round.</div></div>
  <div class="col-sm-6"><label class="form-label">Points needed before they can be used</label><input class="form-control" type="number" min="1" name="loyalty_min_redeem" value="<?= (int)Loyalty::minRedeem() ?>"><div class="form-text">This is the "stamp card" goal customers see a progress bar for.</div></div>
  <div class="col-sm-6"><label class="form-label">Most of the food bill points can pay (%)</label><input class="form-control" type="number" min="1" max="50" name="loyalty_max_pct" value="<?= (int)Loyalty::maxPct() ?>"><div class="form-text">At most 50, so an order always has something to pay.</div></div>
 </div>
 <div class="alert alert-light border small mt-3 mb-0"><b>With today's numbers:</b> every KES 100 spent earns <?= (int)Loyalty::earnRate() ?> point(s), which is worth <?= money(Loyalty::earnRate() * Loyalty::pointValue()) ?> back, about <?= Loyalty::earnRate() > 0 ? rtrim(rtrim(number_format(Loyalty::earnRate() * Loyalty::pointValue(), 1), '0'), '.') : '0' ?>% of spend. Customers can start using points at <?= number_format(Loyalty::minRedeem()) ?>.</div>
 <button class="btn btn-primary mt-3">Save loyalty settings</button>
</div></form></div>
<div class="col-xl-5"><div class="card"><div class="card-body small"><h2 class="h6 sp-display">Right now</h2>
 <div class="d-flex justify-content-between"><span>Customers holding points</span><b><?= number_format($holders) ?></b></div>
 <div class="d-flex justify-content-between"><span>Points outstanding</span><b><?= number_format($outPts) ?></b></div>
 <div class="d-flex justify-content-between"><span>Worth if all were used</span><b><?= money(max(0, $outPts) * Loyalty::pointValue()) ?></b></div>
 <hr><a class="btn btn-outline-primary btn-sm" href="<?= e(url('admin/loyalty.php')) ?>">See customers' points and adjust them</a>
 <p class="form-text mt-3 mb-0">Changing the value of a point changes what all existing points are worth, so adjust it with care. Points already used on an order keep the discount they were given.</p></div></div></div></div>
<?php elseif ($tab === 'google'): $gr = Google::redirectUri(); $gHttps = str_starts_with($gr, 'https://') || preg_match('#^http://(localhost|127\.0\.0\.1)#', $gr); ?>
<div class="row g-3"><div class="col-xl-7"><form method="post" class="card"><div class="card-body"><?= csrf_field() ?><input type="hidden" name="action" value="google">
 <h2 class="h5 sp-display">Sign in and sign up with Google</h2>
 <p class="text-body-secondary small">Customers (and staff who already have an account with the same email) can use their Google account instead of a password. New Google users get an account straight away, with no phone number needed (it is asked for at checkout, and can be added in My profile). The secret is encrypted in the database and never shown again; leave it empty to keep the saved one.</p>
 <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" role="switch" name="google_enabled" id="ge" <?= Settings::get('google_enabled') === '1' ? 'checked' : '' ?>><label class="form-check-label" for="ge">Show the "Sign in with Google" button</label></div>
 <label class="form-label">Client ID <?= $saved('google_client_id') ?></label><input class="form-control mb-3" name="google_client_id" value="<?= $S('google_client_id') ?>" placeholder="1234567890-abc123.apps.googleusercontent.com" autocomplete="off">
 <label class="form-label">Client secret <?= $saved('google_client_secret') ?></label><input class="form-control mb-3" type="password" name="google_client_secret" placeholder="<?= Settings::has('google_client_secret') ? 'Saved (type to replace)' : 'GOCSPX-...' ?>" autocomplete="new-password">
 <button class="btn btn-primary">Save Google settings</button>
 <?php if (Google::enabled()): ?><span class="badge text-bg-success ms-2">Google sign-in is on</span><?php endif; ?>
</div></form></div>
<div class="col-xl-5"><div class="card"><div class="card-body small">
 <h2 class="h6 sp-display">Set up in Google Cloud Console</h2>
 <ol class="ps-3 mb-2">
  <li>Open <b>console.cloud.google.com</b>, create or pick a project, then go to <b>APIs &amp; Services, OAuth consent screen</b> (Google Auth Platform).</li>
  <li>Choose <b>External</b>, fill in the app name and support email, and add these links: Privacy Policy <code><?= e(abs_url('privacy.php')) ?></code> and Terms of Service <code><?= e(abs_url('terms.php')) ?></code>. Add your domain under authorised domains, then <b>Publish</b> the app so any customer can sign in (in testing mode only listed test users can).</li>
  <li>Go to <b>Credentials, Create credentials, OAuth client ID</b>, type <b>Web application</b>.</li>
  <li>Under <b>Authorised redirect URIs</b> add exactly:<br><code class="user-select-all"><?= e($gr) ?></code></li>
  <li>Copy the client ID and secret into this page and switch the button on.</li>
 </ol>
 <?php if (!$gHttps): ?><div class="alert alert-warning py-2 mb-0">Google only accepts <b>https</b> redirect addresses (apart from localhost). Set <code>app_url</code> in <code>config/config.php</code> to your live https address.</div><?php endif; ?>
</div></div></div></div>
<?php else: $locked = Auth::lockedList(); ?>
<div class="row g-3"><div class="col-xl-6"><form method="post" class="card"><div class="card-body"><?= csrf_field() ?><input type="hidden" name="action" value="security">
 <h2 class="h5 sp-display">Sign-in lockout</h2>
 <p class="text-body-secondary small">After too many wrong passwords, that device address is blocked from signing in for a while.</p>
 <div class="row g-3"><div class="col-sm-6"><label class="form-label">Wrong attempts allowed</label><input class="form-control" type="number" min="3" max="50" name="login_max_attempts" value="<?= (int)Auth::maxAttempts() ?>"></div>
 <div class="col-sm-6"><label class="form-label">Locked out for (minutes)</label><input class="form-control" type="number" min="1" max="1440" name="login_lockout_minutes" value="<?= (int)Auth::lockoutMinutes() ?>"></div></div>
 <hr><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" name="passkeys_enabled" id="pke" <?= Passkey::enabled() ? 'checked' : '' ?>><label class="form-check-label" for="pke">Allow fingerprint, face and screen-lock sign-in (passkeys)</label></div>
 <p class="form-text mb-0">People turn it on themselves under My profile. <?= (int)val('SELECT COUNT(DISTINCT user_id) FROM passkeys') ?> account(s) use it now. It needs https and a domain name (not an IP address); a passkey only works on the domain it was created on.</p>
 <button class="btn btn-primary mt-3">Save security settings</button></div></form></div>
<div class="col-xl-6"><div class="card"><div class="card-body"><h2 class="h5 sp-display">Locked out right now</h2>
 <?php if (!$locked) echo '<p class="text-body-secondary mb-0">Nobody is locked out.</p>'; foreach ($locked as $l): ?>
  <form method="post" class="d-flex justify-content-between align-items-center gap-2 py-2 border-bottom"><?= csrf_field() ?><input type="hidden" name="ip" value="<?= e($l['ip']) ?>">
   <div><b><?= e($l['ip']) ?></b> <span class="badge text-bg-danger"><?= (int)$l['remaining'] ?> min left</span><div class="small text-body-secondary"><?= (int)$l['n'] ?> failed attempts, tried: <?= e($l['emails']) ?></div></div>
   <button class="btn btn-primary btn-sm" name="action" value="unlock_ip">Unlock now</button></form><?php endforeach; ?>
 <?php if ($locked): ?><form method="post" class="mt-3"><?= csrf_field() ?><button class="btn btn-outline-danger btn-sm" name="action" value="unlock_all">Unlock everyone</button></form><?php endif; ?>
 <p class="form-text mt-3 mb-0">If every admin is locked out, run <code>php bin/unlock.php</code> on the server (or empty the <code>login_attempts</code> table in phpMyAdmin).</p></div></div></div></div>
<?php endif; ?>
<?php page_footer(['admin' => true]); ?>
