<?php
require __DIR__ . '/../../app/bootstrap.php';
$u = Auth::user();
if (!$u) json_out([], 401);
$o = Orders::find((int)($_GET['id'] ?? 0));
if (!$o || (!Auth::isStaff() && (int)$o['customer_id'] !== (int)$u['id'])) json_out([], 404);
json_out(['status' => $o['status'], 'paid' => (string)$o['amount_paid']]);
