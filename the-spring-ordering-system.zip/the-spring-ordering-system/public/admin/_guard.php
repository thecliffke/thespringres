<?php
// Included at the top of every staff page.
require __DIR__ . '/../../app/bootstrap.php';
$ME = Auth::require(...(defined('ADMIN_ONLY') ? ['admin'] : ['admin', 'waiter']));
