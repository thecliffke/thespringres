(function(){
'use strict';
const data=JSON.parse(document.getElementById('slot-data').textContent);
const f=document.getElementById('checkout-form');
const type=()=>f.querySelector('[name=type]:checked').value;
const day=f.querySelector('[name=day]'),time=f.querySelector('[name=time]');
function fill(){
  const t=type(),d=+day.value,list=(data[t]||{})[d]||[];
  const keep=time.dataset.keep||time.value;
  let h='<option value="">Choose a time</option>';
  if(t==='delivery'&&d===0&&data.asap)h+='<option value="asap">As soon as possible</option>';
  list.forEach(s=>{h+='<option value="'+s.value+'">'+s.label+'</option>'});
  time.innerHTML=h;
  time.value=keep;if(time.value!==keep)time.value=(t==='delivery'&&d===0&&data.asap)?'asap':'';
  time.dataset.keep='';
  f.querySelectorAll('.only-delivery').forEach(x=>x.classList.toggle('d-none',t!=='delivery'));
  f.querySelectorAll('.only-dine').forEach(x=>x.classList.toggle('d-none',t==='delivery'));
  const pb=document.getElementById('use-points'),dis=(pb&&pb.checked)?data.disc:0;
  const fee=data.fee*(t==='delivery'?1:0),total=data.sub+fee-dis,dep=Math.ceil(total*data.pct/100);
  const m=n=>'KES '+Math.round(n).toLocaleString('en-US');
  const dr=document.getElementById('sum-disc-row');if(dr){dr.classList.toggle('d-none',!dis);document.getElementById('sum-disc').textContent='- '+m(dis);}
  const ea=document.getElementById('sum-earn');if(ea)ea.textContent=Math.floor((data.sub-dis)/100*data.earn).toLocaleString('en-US');
  document.getElementById('sum-fee-row').classList.toggle('d-none',t!=='delivery');
  document.getElementById('sum-total').textContent=m(total);
  document.getElementById('sum-now').textContent=m(dep);
  document.getElementById('sum-later').textContent=m(total-dep);
  document.getElementById('sum-later-label').textContent=t==='delivery'?'Pay on delivery':'Pay after eating';
  document.getElementById('pay-btn-amt').textContent=m(dep);
  if(!list.length&&!(t==='delivery'&&d===0&&data.asap))document.getElementById('no-slots').classList.remove('d-none');else document.getElementById('no-slots').classList.add('d-none');
}
f.addEventListener('change',e=>{if(e.target.name==='type'||e.target.name==='day'||e.target.id==='use-points')fill()});
fill();
/* saved addresses: choosing one fills the fields; editing them switches to "Another address" and offers to save it */
const q=s=>f.querySelector(s),adr=q('[name=address]'),lm=q('[name=landmark]'),lat=q('[name=lat]'),lng=q('[name=lng]');
const saveRow=document.getElementById('save-addr-row'),saveBox=q('[name=save_address]'),saveLabel=document.getElementById('sa-label');
const status=q('[data-geo-status]'),clr=q('[data-geo-clear]');
function pinUi(){const has=lat.value!==''&&lng.value!=='';status.innerHTML=has?'<i class="bi bi-geo-alt-fill text-success me-1"></i>Map pin added':'';clr.classList.toggle('d-none',!has);}
function other(){const o=q('[name=saved_addr][value="0"]');if(o)o.checked=true;if(saveRow)saveRow.style.display='';}
f.querySelectorAll('[name=saved_addr]').forEach(r=>r.addEventListener('change',()=>{
  if(r.value==='0'){if(saveRow)saveRow.style.display='';return;}
  adr.value=r.dataset.address||'';lm.value=r.dataset.landmark||'';lat.value=r.dataset.lat||'';lng.value=r.dataset.lng||'';pinUi();
  if(saveRow){saveRow.style.display='none';if(saveBox){saveBox.checked=false;saveBox.dispatchEvent(new Event('change',{bubbles:true}));}}
}));
[adr,lm].forEach(x=>x&&x.addEventListener('input',other));
f.addEventListener('pinchange',()=>{pinUi();other();});
if(saveBox)saveBox.addEventListener('change',()=>{if(saveLabel)saveLabel.classList.toggle('d-none',!saveBox.checked);});
})();
