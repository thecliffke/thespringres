<?php
declare(strict_types=1);

/**
 * Web Push (RFC 8030 + VAPID RFC 8292 + message encryption RFC 8291, aes128gcm).
 * Pure PHP with the openssl extension, no Composer packages. Subscriptions come from the browser
 * (assets/js/push.js + sw.js) and are stored in push_subscriptions.
 */
class Push {
    /** Push services we are willing to POST to (stops a forged "endpoint" from being used to call arbitrary servers). */
    const HOSTS = ['fcm.googleapis.com', 'android.googleapis.com', 'push.services.mozilla.com', 'push.apple.com', 'notify.windows.com'];
    private static array $queue = [];
    private static bool $registered = false;

    public static function enabled(): bool {
        return Settings::get('push_enabled') === '1' && function_exists('openssl_pkey_derive') && function_exists('hash_hkdf');
    }
    public static function b64u(string $s): string { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }
    public static function b64d(string $s): string { return (string)base64_decode(strtr($s, '-_', '+/') . str_repeat('=', (4 - strlen($s) % 4) % 4), true); }

    public static function hostAllowed(string $endpoint): bool {
        $u = parse_url($endpoint);
        if (!$u || empty($u['host']) || !in_array($u['scheme'] ?? '', ['https', 'http'], true)) return false;
        $h = strtolower($u['host']);
        $allow = array_merge(self::HOSTS, (array)cfg('push_extra_hosts', []));   // extra hosts are for local testing only
        foreach ($allow as $a) if ($h === $a || str_ends_with($h, '.' . $a)) return ($u['scheme'] === 'https') || in_array($h, (array)cfg('push_extra_hosts', []), true);
        return false;
    }

    /* ---------- VAPID keys ---------- */
    private static function newKey() {
        $k = openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
        if (!$k) throw new RuntimeException('Could not create an encryption key (OpenSSL is missing its configuration on this server).');
        return $k;
    }
    private static function rawPublic($key): string {
        $d = openssl_pkey_get_details($key)['ec'];
        return "\x04" . str_pad($d['x'], 32, "\0", STR_PAD_LEFT) . str_pad($d['y'], 32, "\0", STR_PAD_LEFT);
    }
    public static function generateKeys(): void {
        $k = self::newKey();
        openssl_pkey_export($k, $pem);
        Settings::set('vapid_private', $pem);
        Settings::set('vapid_public', self::b64u(self::rawPublic($k)));
    }
    public static function publicKey(): string {
        if (Settings::get('vapid_public') === '' || Settings::get('vapid_private') === '') self::generateKeys();
        return Settings::get('vapid_public');
    }
    private static function subject(): string {
        $s = Settings::get('push_subject');
        if ($s === '') $s = Settings::get('mail_from');
        if ($s === '') $s = (string)val("SELECT email FROM users WHERE role='admin' AND is_active=1 ORDER BY id LIMIT 1");
        if (str_starts_with($s, 'https://') || str_starts_with($s, 'mailto:')) return $s;
        return 'mailto:' . ($s !== '' ? $s : 'admin@example.com');
    }
    private static function derToRaw(string $der): string {
        $o = (ord($der[1]) === 0x81) ? 3 : 2;
        $rl = ord($der[$o + 1]); $r = substr($der, $o + 2, $rl); $o += 2 + $rl;
        $sl = ord($der[$o + 1]); $s = substr($der, $o + 2, $sl);
        return str_pad(ltrim($r, "\0"), 32, "\0", STR_PAD_LEFT) . str_pad(ltrim($s, "\0"), 32, "\0", STR_PAD_LEFT);
    }
    private static function vapidHeader(string $endpoint): string {
        $u = parse_url($endpoint);
        $aud = $u['scheme'] . '://' . $u['host'] . (isset($u['port']) ? ':' . $u['port'] : '');
        $in = self::b64u(json_encode(['typ' => 'JWT', 'alg' => 'ES256'])) . '.' . self::b64u(json_encode(['aud' => $aud, 'exp' => time() + 12 * 3600, 'sub' => self::subject()]));
        $pub = self::publicKey();
        if (!openssl_sign($in, $der, Settings::get('vapid_private'), OPENSSL_ALGO_SHA256)) throw new RuntimeException('Could not sign the push request.');
        return 'vapid t=' . $in . '.' . self::b64u(self::derToRaw($der)) . ', k=' . $pub;
    }

    /* ---------- message encryption (RFC 8291, single aes128gcm record) ---------- */
    private static function rawToPem(string $raw): string {
        $der = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200') . $raw;
        return "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PUBLIC KEY-----\n";
    }
    public static function encrypt(string $payload, string $uaPublic, string $authSecret): string {
        $eph = self::newKey(); $asPublic = self::rawPublic($eph);
        $ua = openssl_pkey_get_public(self::rawToPem($uaPublic));
        if (!$ua) throw new RuntimeException('Invalid subscription key.');
        $secret = openssl_pkey_derive($ua, $eph, 32);
        if ($secret === false) throw new RuntimeException('Key agreement failed.');
        $salt = random_bytes(16);
        $ikm = hash_hkdf('sha256', $secret, 32, "WebPush: info\0" . $uaPublic . $asPublic, $authSecret);
        $cek = hash_hkdf('sha256', $ikm, 16, "Content-Encoding: aes128gcm\0", $salt);
        $nonce = hash_hkdf('sha256', $ikm, 12, "Content-Encoding: nonce\0", $salt);
        $tag = '';
        $ct = openssl_encrypt($payload . "\x02", 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag, '', 16);
        return $salt . pack('N', 4096) . chr(65) . $asPublic . $ct . $tag;
    }

    /* ---------- sending ---------- */
    /** @return int HTTP status from the push service (0 on network failure) */
    private static function post(array $sub, string $json): int {
        $body = self::encrypt($json, self::b64d($sub['p256dh']), self::b64d($sub['auth']));
        $res = http_request('POST', $sub['endpoint'], ['Authorization: ' . self::vapidHeader($sub['endpoint']), 'Content-Encoding: aes128gcm', 'Content-Type: application/octet-stream', 'TTL: 86400', 'Urgency: high'], $body, 8);
        return (int)$res['code'];
    }
    private static function deliver(array $sub, string $json): bool {
        try { $code = self::post($sub, $json); } catch (Throwable $e) { error_log('push: ' . $e->getMessage()); $code = 0; }
        if ($code >= 200 && $code < 300) { q('UPDATE push_subscriptions SET failures=0, last_sent_at=NOW() WHERE id=?', [$sub['id']]); return true; }
        if ($code === 404 || $code === 410) q('DELETE FROM push_subscriptions WHERE id=?', [$sub['id']]);          // the device unsubscribed
        else { q('UPDATE push_subscriptions SET failures=failures+1 WHERE id=?', [$sub['id']]); q('DELETE FROM push_subscriptions WHERE id=? AND failures>=10', [$sub['id']]); }
        return false;
    }
    private static function payload(string $title, string $body, string $link): string {
        $url = $link !== '' && str_starts_with($link, '/') ? url($link) : url('/');
        return json_encode(['title' => mb_substr($title, 0, 80), 'body' => mb_substr($body, 0, 200), 'url' => $url, 'tag' => 'sp-' . substr(md5($title . $body), 0, 8)], JSON_UNESCAPED_UNICODE);
    }
    /** Called for every in-app notification; the actual sending happens after the page has been delivered. */
    public static function queue(int $uid, string $title, string $body, string $link): void {
        if (!self::enabled()) return;
        self::$queue[] = [$uid, self::payload($title, $body, $link)];
        if (!self::$registered) { self::$registered = true; register_shutdown_function([self::class, 'flush']); }
    }
    public static function flush(): void {
        if (!self::$queue) return;
        $q = self::$queue; self::$queue = [];
        if (function_exists('fastcgi_finish_request')) @fastcgi_finish_request();
        ignore_user_abort(true);
        try {
            foreach ($q as [$uid, $json]) foreach (rows('SELECT * FROM push_subscriptions WHERE user_id=?', [$uid]) as $sub) self::deliver($sub, $json);
        } catch (Throwable $e) { error_log('push flush: ' . $e->getMessage()); }
    }
    /** Immediate send to all of one person's devices (used by the "send a test" buttons). @return array{0:int,1:int} [delivered, devices] */
    public static function sendNow(int $uid, string $title, string $body, string $link = ''): array {
        $subs = rows('SELECT * FROM push_subscriptions WHERE user_id=?', [$uid]); $ok = 0;
        $json = self::payload($title, $body, $link);
        foreach ($subs as $s) if (self::deliver($s, $json)) $ok++;
        return [$ok, count($subs)];
    }

    /* ---------- subscriptions ---------- */
    public static function subscribe(int $uid, string $endpoint, string $p256dh, string $auth, string $ua): ?string {
        if (!self::hostAllowed($endpoint) || strlen($endpoint) > 1000) return 'This browser uses a push service we do not support.';
        if (strlen(self::b64d($p256dh)) !== 65 || strlen(self::b64d($auth)) < 16) return 'The subscription keys are not valid.';
        $h = hash('sha256', $endpoint);
        q('INSERT INTO push_subscriptions (user_id, endpoint, endpoint_hash, p256dh, auth, user_agent) VALUES (?,?,?,?,?,?)
           ON DUPLICATE KEY UPDATE user_id=VALUES(user_id), p256dh=VALUES(p256dh), auth=VALUES(auth), user_agent=VALUES(user_agent), failures=0', [$uid, $endpoint, $h, $p256dh, $auth, mb_substr($ua, 0, 200)]);
        q('DELETE FROM push_subscriptions WHERE user_id=? AND id NOT IN (SELECT id FROM (SELECT id FROM push_subscriptions WHERE user_id=? ORDER BY id DESC LIMIT 5) t)', [$uid, $uid]);
        $_SESSION['push_hash'] = $h;
        return null;
    }
    public static function unsubscribe(string $endpoint): void { q('DELETE FROM push_subscriptions WHERE endpoint_hash=?', [hash('sha256', $endpoint)]); }
}
