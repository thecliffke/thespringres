<?php
declare(strict_types=1);

/** Key/value settings stored in MySQL. Secret values are encrypted at rest. */
class Settings {
    const DEFAULTS = [
        // general
        'restaurant_name' => 'The Spring', 'restaurant_phone' => '', 'restaurant_address' => '',
        'deposit_percent' => '30', 'delivery_fee' => '150',
        'open_time' => '10:00', 'close_time' => '21:30',
        'lead_dine_in' => '30', 'lead_delivery' => '45', 'slot_minutes' => '30',
        // M-Pesa (Daraja)
        'mpesa_env' => 'simulate', 'mpesa_consumer_key' => '', 'mpesa_consumer_secret' => '', 'mpesa_shortcode' => '', 'mpesa_party_b' => '',
        'mpesa_passkey' => '', 'mpesa_transaction_type' => 'CustomerPayBillOnline', 'mpesa_callback_url' => '', 'mpesa_callback_token' => '',
        // SMS (Africa's Talking)
        'sms_enabled' => '0', 'sms_provider' => 'africastalking', 'sl_api_key' => '', 'sl_api_secret' => '', 'sl_sender_id' => 'SMS_Leopard', 'at_env' => 'sandbox', 'at_username' => 'sandbox', 'at_api_key' => '', 'at_sender_id' => '',
        'sms_on_placed' => '1', 'sms_on_ready' => '1', 'sms_on_dispatched' => '1', 'sms_on_balance' => '1',
        'sms_tpl_placed' => 'Hi {name}, your {restaurant} order {order} is confirmed. Deposit received: {paid}. Balance: {balance}.',
        'sms_tpl_ready' => 'Hi {name}, your {restaurant} order {order} is ready. Balance to pay: {balance}.',
        'sms_tpl_dispatched' => 'Hi {name}, your {restaurant} order {order} is on its way. Balance to pay on delivery: {balance}.',
        'sms_tpl_balance' => 'Hi {name}, a balance of {balance} is due on {restaurant} order {order}. Pay via M-Pesa {pay_details}. Thank you.',
        'sms_tpl_reminder' => 'Hi {name}, reminder from {restaurant}: {label}. Order now at {link}',
        // internal
        'reminders_last_run' => '0', 'schema_version' => '0',
        // branding
        'logo' => '',
        // push notifications (Web Push)
        'push_enabled' => '1', 'push_subject' => '', 'vapid_public' => '', 'vapid_private' => '', 'cron_last_run' => '0', 'reconcile_last_run' => '0',
        // Google sign-in and legal pages
        'google_enabled' => '0', 'google_client_id' => '', 'google_client_secret' => '', 'legal_email' => '', 'passkeys_enabled' => '1',
        // loyalty points (off until the owner switches it on): points per KES 100 spent, KES per point, balance needed to start redeeming, max share of the food bill points can cover
        'loyalty_enabled' => '0', 'loyalty_earn_per_100' => '2', 'loyalty_point_value' => '1', 'loyalty_min_redeem' => '100', 'loyalty_max_pct' => '30',
        // login lockout
        'login_max_attempts' => '8', 'login_lockout_minutes' => '15',
        // email (password reset)
        'smtp_host' => '', 'smtp_port' => '587', 'smtp_secure' => 'tls', 'smtp_user' => '', 'smtp_pass' => '', 'mail_from' => '', 'mail_from_name' => '',
        // M-Pesa reversal (refund of deposits)
        'mpesa_initiator' => '', 'mpesa_initiator_pass' => '', 'mpesa_reversal_receiver' => '', 'mpesa_reversal_idtype' => '11',
        'sms_on_refund' => '1', 'sms_on_deposit' => '1',
        'sms_tpl_deposit' => 'Hi {name}, your {restaurant} order {order} is waiting for its deposit of {deposit}. Pay now to confirm it: {link}',
        'sms_tpl_refund' => 'Hi {name}, your deposit of {amount} for {restaurant} order {order} has been refunded to your M-Pesa. Reference {ref}.',
    ];
    const SECRETS = ['mpesa_consumer_key', 'mpesa_consumer_secret', 'mpesa_passkey', 'mpesa_callback_token', 'at_api_key', 'sl_api_key', 'sl_api_secret', 'smtp_pass', 'mpesa_initiator_pass', 'vapid_private', 'google_client_secret'];
    private static ?array $cache = null;

    private static function load(): array {
        if (self::$cache === null) {
            self::$cache = [];
            foreach (rows('SELECT skey, svalue, is_secret FROM settings') as $r) {
                self::$cache[$r['skey']] = $r['is_secret'] ? Crypto::dec((string)$r['svalue']) : (string)$r['svalue'];
            }
        }
        return self::$cache;
    }
    public static function get(string $k, ?string $d = null): string {
        $all = self::load();
        if (array_key_exists($k, $all)) return $all[$k];
        return $d ?? (self::DEFAULTS[$k] ?? '');
    }
    public static function set(string $k, string $v): void {
        $sec = in_array($k, self::SECRETS, true) ? 1 : 0;
        $old = self::get($k);
        q('INSERT INTO settings (skey, svalue, is_secret) VALUES (?,?,?) ON DUPLICATE KEY UPDATE svalue = VALUES(svalue), is_secret = VALUES(is_secret)',
            [$k, $sec ? Crypto::enc($v) : $v, $sec]);
        self::$cache = null;
        if ($old !== $v && !in_array($k, Audit::QUIET_SETTINGS, true)) {
            $show = fn(string $x) => mb_strlen($x) > 60 ? mb_substr($x, 0, 57) . '...' : ($x === '' ? '(empty)' : $x);
            if ($sec) Audit::log('settings.changed', 'Changed setting ' . $k . ' (value hidden)', 'setting', $k, ['key' => $k, 'secret' => true]);
            else Audit::log('settings.changed', 'Changed setting ' . $k . ': ' . $show($old) . ' to ' . $show($v), 'setting', $k, ['key' => $k, 'from' => mb_substr($old, 0, 300), 'to' => mb_substr($v, 0, 300)]);
        }
    }
    public static function has(string $k): bool { return self::get($k) !== ''; }
    /** True when customers pay a Till (Buy Goods) rather than a Paybill. */
    public static function isTill(): bool { return self::get('mpesa_transaction_type') === 'CustomerBuyGoodsOnline'; }
    /** The number customers actually pay to: the Till number for Till businesses, the Paybill otherwise. */
    public static function payNumber(): string {
        if (self::isTill()) return self::get('mpesa_party_b') ?: self::get('mpesa_shortcode');
        return self::get('mpesa_shortcode');
    }
    public static function payType(): string { return self::isTill() ? 'Till' : 'Paybill'; }
    /** Text for SMS and receipts, e.g. "Till 123456" or "Paybill 123456, account SP-1001". */
    public static function payDetails(string $orderNo = ''): string {
        $n = self::payNumber() ?: '(not set)';
        return self::isTill() ? 'Till ' . $n : 'Paybill ' . $n . ($orderNo !== '' ? ', account ' . $orderNo : '');
    }
    public static function depositPct(): int { return max(1, min(100, (int)self::get('deposit_percent'))); }
    public static function callbackToken(): string {
        $t = self::get('mpesa_callback_token');
        if ($t === '') { $t = bin2hex(random_bytes(16)); self::set('mpesa_callback_token', $t); }
        return $t;
    }
}
