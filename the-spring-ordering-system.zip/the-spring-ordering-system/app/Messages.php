<?php
declare(strict_types=1);

/** In-app conversations between a customer and the restaurant's admins. Threads can go back and forth until closed. */
class Messages {
    const MAX_LEN = 2000;
    const HOURLY_LIMIT = 20;

    public static function customerUnread(int $uid): int { return (int)val('SELECT COALESCE(SUM(customer_unread),0) FROM message_threads WHERE customer_id=?', [$uid]); }
    public static function adminUnread(): int { return (int)val('SELECT COALESCE(SUM(admin_unread),0) FROM message_threads'); }
    public static function thread(int $id): ?array {
        return row('SELECT t.*, u.name customer_name, u.phone customer_phone, u.email customer_email, o.order_no FROM message_threads t JOIN users u ON u.id=t.customer_id LEFT JOIN orders o ON o.id=t.order_id WHERE t.id=?', [$id]);
    }
    /** Display name for a message: customers by name, staff as "First name (Restaurant)". */
    public static function senderName(array $m, array $thread): string {
        if ($m['sender_role'] === 'customer') return (string)$thread['customer_name'];
        $n = (string)val('SELECT name FROM users WHERE id=?', [$m['sender_id']]);
        return ($n !== '' ? explode(' ', $n)[0] : 'Staff') . ' (' . Settings::get('restaurant_name') . ')';
    }
    private static function check(string $body, array $sender): ?string {
        $body = trim($body);
        if ($body === '') return 'Write a message first.';
        if (mb_strlen($body) > self::MAX_LEN) return 'That message is too long. Keep it under ' . self::MAX_LEN . ' characters.';
        if ($sender['role'] === 'customer' && (int)val('SELECT COUNT(*) FROM messages WHERE sender_id=? AND created_at > (NOW() - INTERVAL 1 HOUR)', [$sender['id']]) >= self::HOURLY_LIMIT)
            return 'You have sent a lot of messages in the last hour. Please wait a little before sending more.';
        return null;
    }
    /** @return array{ok:bool,message:string,id?:int} */
    public static function start(array $sender, int $customerId, string $subject, string $body, ?int $orderId): array {
        if ($err = self::check($body, $sender)) return ['ok' => false, 'message' => $err];
        $subject = trim($subject);
        if ($orderId !== null && !row('SELECT id FROM orders WHERE id=? AND customer_id=?', [$orderId, $customerId])) $orderId = null;
        if ($subject === '') $subject = $orderId ? 'About order ' . val('SELECT order_no FROM orders WHERE id=?', [$orderId]) : 'Question';
        $id = exec_id('INSERT INTO message_threads (customer_id,order_id,subject,last_sender) VALUES (?,?,?,?)', [$customerId, $orderId, mb_substr($subject, 0, 160), $sender['role'] === 'customer' ? 'customer' : 'admin']);
        self::add($id, $sender, $body);
        return ['ok' => true, 'message' => 'Message sent.', 'id' => $id];
    }
    /** @return array{ok:bool,message:string,id?:int} */
    public static function reply(array $thread, array $sender, string $body): array {
        if ($err = self::check($body, $sender)) return ['ok' => false, 'message' => $err];
        return ['ok' => true, 'message' => 'Sent.', 'id' => self::add((int)$thread['id'], $sender, $body)];
    }
    private static function add(int $threadId, array $sender, string $body): int {
        $role = $sender['role'] === 'customer' ? 'customer' : 'admin';
        $body = trim($body);
        $mid = exec_id('INSERT INTO messages (thread_id,sender_id,sender_role,body) VALUES (?,?,?,?)', [$threadId, $sender['id'], $role, $body]);
        q("UPDATE message_threads SET status='open', last_sender=?, last_message_at=NOW(), customer_unread = customer_unread + ?, admin_unread = admin_unread + ? WHERE id=?", [$role, $role === 'admin' ? 1 : 0, $role === 'customer' ? 1 : 0, $threadId]);
        $t = self::thread($threadId);
        $preview = mb_strlen($body) > 100 ? mb_substr($body, 0, 97) . '...' : $body;
        if ($role === 'customer') Notify::admins('Message from ' . $t['customer_name'], $t['subject'] . ': ' . $preview, '/admin/thread.php?id=' . $threadId);
        else Notify::user((int)$t['customer_id'], 'New message from ' . Settings::get('restaurant_name'), $t['subject'] . ': ' . $preview, '/thread.php?id=' . $threadId);
        Audit::log($role === 'customer' ? 'message.sent' : 'message.replied', ($role === 'customer' ? $t['customer_name'] . ' sent a message' : 'Replied to ' . $t['customer_name']) . ' in "' . mb_substr($t['subject'], 0, 60) . '" (conversation #' . $threadId . ')', 'thread', $threadId, ['order' => $t['order_no'], 'length' => mb_strlen($body)], $sender);
        return $mid;
    }
    /** Marks a conversation read for the person looking at it. */
    public static function markRead(int $threadId, bool $asAdmin): void {
        q('UPDATE message_threads SET ' . ($asAdmin ? 'admin_unread' : 'customer_unread') . '=0 WHERE id=?', [$threadId]);
    }
    public static function setStatus(int $threadId, string $status): void {
        q('UPDATE message_threads SET status=? WHERE id=?', [$status === 'closed' ? 'closed' : 'open', $threadId]);
        Audit::log($status === 'closed' ? 'message.closed' : 'message.reopened', ($status === 'closed' ? 'Closed' : 'Reopened') . ' conversation #' . $threadId, 'thread', $threadId);
    }
    public static function after(int $threadId, int $afterId): array {
        return rows('SELECT id, sender_id, sender_role, body, created_at FROM messages WHERE thread_id=? AND id>? ORDER BY id LIMIT 100', [$threadId, $afterId]);
    }
}
