SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  phone VARCHAR(15) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  google_id VARCHAR(40) NULL,
  password_set TINYINT(1) NOT NULL DEFAULT 1,
  role ENUM('admin','waiter','customer') NOT NULL DEFAULT 'customer',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login DATETIME NULL,
  UNIQUE KEY uq_google (google_id),
  KEY idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS login_attempts (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ip VARCHAR(45) NOT NULL,
  email VARCHAR(160) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_ip (ip, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS passkeys (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  credential_id VARCHAR(400) NOT NULL,
  public_key TEXT NOT NULL,
  alg SMALLINT NOT NULL DEFAULT -7,
  sign_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
  label VARCHAR(80) NOT NULL DEFAULT '',
  transports VARCHAR(80) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_used_at DATETIME NULL,
  UNIQUE KEY uq_cred (credential_id(255)),
  KEY idx_user (user_id),
  CONSTRAINT fk_pk_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS menu_items (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NOT NULL,
  name VARCHAR(120) NOT NULL,
  description VARCHAR(400) NOT NULL DEFAULT '',
  price DECIMAL(10,2) NOT NULL,
  emoji VARCHAR(16) NOT NULL DEFAULT '',
  image VARCHAR(200) NULL,
  is_available TINYINT(1) NOT NULL DEFAULT 1,
  offer_percent TINYINT UNSIGNED NOT NULL DEFAULT 0,
  offer_label VARCHAR(60) NOT NULL DEFAULT '',
  offer_ends DATE NULL,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_menu_cat FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS orders (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_no VARCHAR(20) NOT NULL UNIQUE,
  customer_id INT UNSIGNED NOT NULL,
  customer_name VARCHAR(120) NOT NULL,
  phone VARCHAR(15) NOT NULL,
  type ENUM('dine_in','delivery') NOT NULL,
  scheduled_at DATETIME NOT NULL,
  asap TINYINT(1) NOT NULL DEFAULT 0,
  party_size TINYINT UNSIGNED NOT NULL DEFAULT 0,
  address VARCHAR(255) NOT NULL DEFAULT '',
  landmark VARCHAR(160) NOT NULL DEFAULT '',
  lat DECIMAL(9,6) NULL,
  lng DECIMAL(9,6) NULL,
  notes VARCHAR(500) NOT NULL DEFAULT '',
  subtotal DECIMAL(10,2) NOT NULL,
  delivery_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
  loyalty_points INT UNSIGNED NOT NULL DEFAULT 0,
  loyalty_discount DECIMAL(10,2) NOT NULL DEFAULT 0,
  total DECIMAL(10,2) NOT NULL,
  deposit_pct TINYINT UNSIGNED NOT NULL,
  deposit_due DECIMAL(10,2) NOT NULL,
  amount_paid DECIMAL(10,2) NOT NULL DEFAULT 0,
  status ENUM('awaiting_deposit','placed','preparing','ready','dispatched','completed','cancelled') NOT NULL DEFAULT 'awaiting_deposit',
  handled_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_status (status), KEY idx_customer (customer_id), KEY idx_sched (scheduled_at),
  CONSTRAINT fk_order_customer FOREIGN KEY (customer_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS saved_addresses (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  label VARCHAR(40) NOT NULL,
  address VARCHAR(255) NOT NULL,
  landmark VARCHAR(160) NOT NULL DEFAULT '',
  lat DECIMAL(9,6) NULL,
  lng DECIMAL(9,6) NULL,
  is_default TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user (user_id),
  CONSTRAINT fk_addr_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS loyalty_ledger (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  order_id INT UNSIGNED NULL,
  points INT NOT NULL,
  type ENUM('earn','redeem','restore','reverse','adjust') NOT NULL,
  note VARCHAR(160) NOT NULL DEFAULT '',
  uniq VARCHAR(40) NULL,
  created_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_uniq (uniq),
  KEY idx_user (user_id),
  CONSTRAINT fk_ll_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_ll_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS order_items (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  menu_item_id INT UNSIGNED NULL,
  name VARCHAR(120) NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  qty SMALLINT UNSIGNED NOT NULL,
  CONSTRAINT fk_oi_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  CONSTRAINT fk_oi_item FOREIGN KEY (menu_item_id) REFERENCES menu_items(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS order_events (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  status VARCHAR(30) NOT NULL,
  user_id INT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_order (order_id),
  CONSTRAINT fk_oe_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mpesa_requests (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  kind ENUM('deposit','balance') NOT NULL,
  phone VARCHAR(15) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  account_ref VARCHAR(20) NOT NULL,
  merchant_request_id VARCHAR(80) NULL,
  checkout_request_id VARCHAR(80) NULL UNIQUE,
  status ENUM('pending','success','failed','cancelled','timeout') NOT NULL DEFAULT 'pending',
  result_code INT NULL,
  result_desc VARCHAR(255) NULL,
  mpesa_receipt VARCHAR(30) NULL,
  raw_callback MEDIUMTEXT NULL,
  requested_by INT UNSIGNED NULL,
  last_query_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_order (order_id), KEY idx_status (status), KEY idx_phone (phone),
  CONSTRAINT fk_mr_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  receipt_no VARCHAR(24) NOT NULL UNIQUE,
  order_id INT UNSIGNED NOT NULL,
  kind ENUM('deposit','balance') NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  phone VARCHAR(15) NOT NULL,
  mpesa_receipt VARCHAR(30) NULL,
  mpesa_request_id INT UNSIGNED NULL,
  method ENUM('mpesa','cash','mpesa_manual') NOT NULL DEFAULT 'mpesa',
  received_by INT UNSIGNED NULL,
  pct_of_total DECIMAL(6,2) NULL,
  balance_after DECIMAL(10,2) NULL,
  note VARCHAR(255) NULL,
  reversed_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_mpesa (mpesa_receipt), KEY idx_phone (phone), KEY idx_paid (paid_at), KEY idx_order (order_id),
  CONSTRAINT fk_pay_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notifications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(160) NOT NULL,
  body VARCHAR(400) NOT NULL DEFAULT '',
  link VARCHAR(200) NOT NULL DEFAULT '',
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user (user_id, is_read),
  CONSTRAINT fk_n_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS reminders (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  label VARCHAR(80) NOT NULL,
  next_run DATETIME NOT NULL,
  repeat_type ENUM('once','daily','weekdays') NOT NULL DEFAULT 'once',
  channel_sms TINYINT(1) NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  last_run DATETIME NULL,
  KEY idx_due (is_active, next_run),
  CONSTRAINT fk_r_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS sms_log (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  phone VARCHAR(16) NOT NULL,
  event VARCHAR(40) NOT NULL DEFAULT '',
  message VARCHAR(700) NOT NULL,
  status VARCHAR(20) NOT NULL,
  provider_status VARCHAR(120) NULL,
  message_id VARCHAR(80) NULL,
  cost VARCHAR(20) NULL,
  response TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_phone (phone), KEY idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS settings (
  skey VARCHAR(60) PRIMARY KEY,
  svalue TEXT NULL,
  is_secret TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS password_resets (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  ip VARCHAR(45) NOT NULL DEFAULT '',
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_user (user_id),
  CONSTRAINT fk_pr_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS refunds (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  payment_id INT UNSIGNED NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  reason VARCHAR(255) NOT NULL DEFAULT '',
  method ENUM('api','manual') NOT NULL DEFAULT 'api',
  status ENUM('pending','success','failed') NOT NULL DEFAULT 'pending',
  original_receipt VARCHAR(30) NULL,
  originator_conversation_id VARCHAR(80) NULL,
  conversation_id VARCHAR(80) NULL,
  result_code INT NULL,
  result_desc VARCHAR(255) NULL,
  reversal_ref VARCHAR(40) NULL,
  cancel_order TINYINT(1) NOT NULL DEFAULT 0,
  initiated_by INT UNSIGNED NULL,
  raw_result MEDIUMTEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_order (order_id), KEY idx_status (status), KEY idx_orig (originator_conversation_id),
  CONSTRAINT fk_rf_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  CONSTRAINT fk_rf_pay FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS push_subscriptions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  endpoint TEXT NOT NULL,
  endpoint_hash CHAR(64) NOT NULL UNIQUE,
  p256dh VARCHAR(140) NOT NULL,
  auth VARCHAR(40) NOT NULL,
  user_agent VARCHAR(200) NOT NULL DEFAULT '',
  failures TINYINT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_sent_at DATETIME NULL,
  KEY idx_user (user_id),
  CONSTRAINT fk_ps_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS audit_log (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  created_at DATETIME NOT NULL,
  user_id INT UNSIGNED NULL,
  user_name VARCHAR(120) NOT NULL DEFAULT 'System',
  user_role VARCHAR(20) NOT NULL DEFAULT 'system',
  action VARCHAR(60) NOT NULL,
  summary VARCHAR(400) NOT NULL,
  entity_type VARCHAR(30) NULL,
  entity_id VARCHAR(40) NULL,
  details TEXT NULL,
  ip VARCHAR(45) NOT NULL DEFAULT '',
  user_agent VARCHAR(200) NOT NULL DEFAULT '',
  prev_hash CHAR(64) NOT NULL,
  row_hash CHAR(64) NOT NULL,
  KEY idx_created (created_at), KEY idx_user (user_id), KEY idx_action (action), KEY idx_entity (entity_type, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS message_threads (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  customer_id INT UNSIGNED NOT NULL,
  order_id INT UNSIGNED NULL,
  subject VARCHAR(160) NOT NULL,
  status ENUM('open','closed') NOT NULL DEFAULT 'open',
  customer_unread SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  admin_unread SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  last_sender ENUM('customer','admin') NOT NULL DEFAULT 'customer',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_message_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_customer (customer_id), KEY idx_last (last_message_at), KEY idx_status (status),
  CONSTRAINT fk_mt_customer FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_mt_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS messages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  thread_id INT UNSIGNED NOT NULL,
  sender_id INT UNSIGNED NULL,
  sender_role ENUM('customer','admin') NOT NULL,
  body TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_thread (thread_id, id),
  CONSTRAINT fk_msg_thread FOREIGN KEY (thread_id) REFERENCES message_threads(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Starter menu (edit or delete from Admin > Menu)
INSERT INTO categories (id,name,sort_order) VALUES (1,'Grills',1),(2,'Mains',2),(3,'Sides',3),(4,'Snacks',4),(5,'Drinks',5);
INSERT INTO menu_items (category_id,name,description,price,emoji,offer_percent,offer_label) VALUES
(1,'Nyama choma (half kilo)','Slow-roasted goat ribs with kachumbari and ugali.',900,'🍖',0,''),
(1,'Chicken grill (quarter)','Marinated in lemon and garlic, charred over coals.',550,'🍗',0,''),
(2,'Tilapia fry with ugali','Whole tilapia, crisp skin, served with greens.',750,'🐟',15,'Fish special'),
(2,'Beef stew with rice','Tender beef simmered in a rich tomato gravy.',450,'🍛',0,''),
(2,'Pilau with kachumbari','Spiced rice cooked in beef stock.',400,'🥘',0,''),
(2,'Ugali, sukuma and beef','The everyday plate, done properly.',350,'🥬',0,''),
(2,'Chapati and beans','Soft layered chapati with coconut beans.',250,'🫓',0,''),
(3,'Chips masala','Crisp fries tossed in a tangy masala sauce.',300,'🍟',20,'Happy hour'),
(3,'Kachumbari bowl','Fresh tomato, onion and coriander.',100,'🥗',0,''),
(4,'Samosa (2 pieces)','Beef samosas, fried to order.',120,'🥟',0,''),
(4,'Mandazi (4 pieces)','Cardamom-scented and still warm.',100,'🍩',0,''),
(5,'Masala chai','Milk tea with ginger and spices.',80,'☕',0,''),
(5,'Fresh passion juice','Pressed to order, lightly sweetened.',200,'🍹',10,'Lunch deal'),
(5,'Dawa','Honey, lime and ginger, served hot or cold.',250,'🍵',0,''),
(5,'Soda (500 ml)','Ice cold.',70,'🥤',0,'');
