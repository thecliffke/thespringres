<?php
require __DIR__ . '/../app/bootstrap.php';
$q = get('q'); $catId = (int)get('cat');
$cats = rows('SELECT * FROM categories ORDER BY sort_order, name');
$hue = []; foreach ($cats as $i => $c) $hue[$c['id']] = [42, 85, 22, 358, 72, 12][$i % 6];
$where = ['1=1']; $p = [];
if ($catId) { $where[] = 'm.category_id=?'; $p[] = $catId; }
if ($q !== '') { $where[] = '(m.name LIKE ? OR m.description LIKE ?)'; $p[] = "%$q%"; $p[] = "%$q%"; }
$items = rows('SELECT m.*, c.name cat_name FROM menu_items m JOIN categories c ON c.id=m.category_id WHERE ' . implode(' AND ', $where) . ' ORDER BY c.sort_order, c.name, m.sort_order, m.name', $p);
$offers = array_values(array_filter(rows('SELECT * FROM menu_items WHERE is_available=1 AND offer_percent>0 ORDER BY offer_percent DESC'), fn($i) => Orders::offerActive($i)));
$grouped = []; foreach ($items as $i) $grouped[$i['cat_name']][] = $i;
$canBuy = !Auth::user() || Auth::user()['role'] === 'customer';
$cart = $_SESSION['cart'] ?? [];
$open = Orders::isOpenNow(); $pct = Settings::depositPct();
page_header('Menu', ['active' => 'menu']);
?>
<?= Passkey::promptHtml() ?>
<?php if ($canBuy && Auth::user() && Loyalty::enabled() && ($lp = Loyalty::summary((int)Auth::id())) && $lp['balance'] > 0): ?><a class="alert alert-warning d-flex justify-content-between align-items-center text-decoration-none py-2" href="<?= e(url('loyalty.php')) ?>"><span><i class="bi bi-star-fill me-1"></i>You have <b><?= number_format($lp['balance']) ?> points</b> (<?= money($lp['kes']) ?>)<?= $lp['unlocked'] ? ', ready to use at checkout' : '' ?></span><i class="bi bi-chevron-right"></i></a><?php endif; ?>
<section class="hero">
  <div class="ripple"></div>
  <span class="badge chip-lime rounded-pill px-3 py-2"><?= $open ? 'Open now, last orders ' . e(date('g:i A', strtotime(Settings::get('close_time')))) : 'Closed now, opens ' . e(date('g:i A', strtotime(Settings::get('open_time')))) ?></span>
  <h1>Order ahead. Eat in or have it delivered.</h1>
  <p>Choose your dishes, pick a time, and pay <?= $pct ?>% now with M-Pesa. You settle the rest when you eat or when your delivery arrives.</p>
</section>

<?php if ($offers): ?>
<h2 class="h4 mb-1 sp-display">Offers today</h2>
<?php if (count($offers) > 1): ?><p class="swipe-hint d-md-none mb-2"><i class="bi bi-arrow-left-right me-1"></i>Swipe left or right to see more offers</p><?php endif; ?>
<div class="offer-strip mb-3">
  <?php foreach ($offers as $i): ?>
  <div class="offer"><div class="em"><?= $i['image'] ? '<img alt="" src="' . e(url('uploads/' . $i['image'])) . '">' : e($i['emoji']) ?></div>
    <div class="offer-body"><small class="offer-tag"><?= e($i['offer_label'] ?: 'Special offer') ?>, <?= (int)$i['offer_percent'] ?>% off</small><b><?= e($i['name']) ?></b>
    <div class="offer-buy"><span class="offer-price"><?= money(Orders::priceOf($i)) ?> <s class="opacity-75"><?= money($i['price']) ?></s></span>
    <?php if ($canBuy): $oq = (int)($cart[$i['id']] ?? 0); ?><span data-qty="<?= $oq ?>" data-item="<?= (int)$i['id'] ?>">
      <?php if ($oq): ?><div class="qty"><button type="button" data-cart="dec" data-id="<?= (int)$i['id'] ?>" aria-label="Remove one">&minus;</button><b><?= $oq ?></b><button type="button" data-cart="inc" data-id="<?= (int)$i['id'] ?>" aria-label="Add one">+</button></div>
      <?php else: ?><button type="button" class="btn btn-orange btn-sm" data-cart="inc" data-id="<?= (int)$i['id'] ?>">Add</button><?php endif; ?></span><?php endif; ?></div></div></div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<form method="get" class="mb-2"><input type="search" id="menuSearch" name="q" value="<?= e($q) ?>" class="form-control form-control-lg" placeholder="Search the menu" aria-label="Search the menu"><?php if ($catId): ?><input type="hidden" name="cat" value="<?= $catId ?>"><?php endif; ?></form>
<div class="cat-pills">
  <a href="<?= e(url('/')) ?>" class="<?= $catId ? '' : 'on' ?>">All</a>
  <?php foreach ($cats as $c): ?><a href="?cat=<?= (int)$c['id'] ?>" class="<?= $catId === (int)$c['id'] ? 'on' : '' ?>"><?= e($c['name']) ?></a><?php endforeach; ?>
</div>

<?php if (!$grouped): ?><div class="card card-body text-center py-5"><h2 class="h5">No dishes match</h2><p class="text-body-secondary mb-0">Try a different word or pick another category.</p></div><?php endif; ?>
<?php foreach ($grouped as $cat => $list): ?>
<section class="menu-cat mb-4"><h2 class="h4 sp-display mt-3 mb-3"><?= e($cat) ?></h2><div class="row g-3">
  <?php foreach ($list as $i): $qty = (int)($cart[$i['id']] ?? 0); $on = Orders::offerActive($i); ?>
  <div class="col-6 col-md-4 col-lg-3 menu-item" data-text="<?= e(mb_strtolower($i['name'] . ' ' . $i['description'] . ' ' . $cat)) ?>">
    <article class="item-card">
      <div class="tile" style="--h:<?= $hue[$i['category_id']] ?? 150 ?>"><?= $i['image'] ? '<img alt="" loading="lazy" src="' . e(url('uploads/' . $i['image'])) . '">' : e($i['emoji'] ?: '🍽️') ?><?php if ($on): ?><span class="badge rounded-pill"><?= (int)$i['offer_percent'] ?>% off</span><?php endif; ?></div>
      <div class="p-3 d-flex flex-column gap-1 flex-grow-1">
        <h3 class="h6 mb-0"><?= e($i['name']) ?></h3>
        <p class="small text-body-secondary flex-grow-1 mb-1"><?= e($i['description']) ?></p>
        <div class="d-flex align-items-center justify-content-between gap-2 mt-1">
          <span class="price"><?= money(Orders::priceOf($i)) ?><?php if ($on): ?><s><?= money($i['price']) ?></s><?php endif; ?></span>
          <?php if (!$i['is_available']): ?><span class="badge text-bg-secondary">Sold out</span>
          <?php elseif ($canBuy): ?><span data-qty="<?= $qty ?>" data-item="<?= (int)$i['id'] ?>">
            <?php if ($qty): ?><div class="qty"><button type="button" data-cart="dec" data-id="<?= (int)$i['id'] ?>" aria-label="Remove one">&minus;</button><b><?= $qty ?></b><button type="button" data-cart="inc" data-id="<?= (int)$i['id'] ?>" aria-label="Add one">+</button></div>
            <?php else: ?><button type="button" class="btn btn-primary btn-sm" data-cart="inc" data-id="<?= (int)$i['id'] ?>">Add</button><?php endif; ?></span><?php endif; ?>
        </div>
      </div>
    </article>
  </div>
  <?php endforeach; ?>
</div></section>
<?php endforeach; ?>
<?php if ($canBuy && cart_count()):
    $t = 0; foreach (rows('SELECT * FROM menu_items WHERE id IN (' . implode(',', array_map('intval', array_keys($cart))) . ')') as $i) $t += Orders::priceOf($i) * $cart[$i['id']]; ?>
<a class="cartbar" href="<?= e(url('checkout.php')) ?>"><span><?= cart_count() ?> item<?= cart_count() > 1 ? 's' : '' ?> in your order</span><span class="go">View order <?= money($t) ?></span></a>
<?php endif; ?>
<?php page_footer(['scripts' => ['passkey.js']]); ?>
