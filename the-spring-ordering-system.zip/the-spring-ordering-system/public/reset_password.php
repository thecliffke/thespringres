<?php
require __DIR__ . '/../app/bootstrap.php';
$raw = (string)($_GET['token'] ?? $_POST['token'] ?? '');
$row = preg_match('/^[a-f0-9]{64}$/', $raw) ? row('SELECT * FROM password_resets WHERE token_hash=? AND used_at IS NULL AND expires_at > NOW()', [hash('sha256', $raw)]) : null;
$err = '';
if ($row && is_post()) {
    csrf_check();
    $pw = (string)($_POST['password'] ?? '');
    if (strlen($pw) < 6) $err = 'Use a password with at least 6 characters.';
    elseif ($pw !== (string)($_POST['password2'] ?? '')) $err = 'The two passwords do not match.';
    else {
        q('UPDATE users SET password_hash=?, password_set=1 WHERE id=?', [password_hash($pw, PASSWORD_DEFAULT), $row['user_id']]);
        $ru = row('SELECT id,name,role,email FROM users WHERE id=?', [$row['user_id']]);
        Audit::log('auth.password_reset', 'Password changed through the reset link for ' . $ru['email'], 'user', $ru['id'], [], $ru);
        q('UPDATE password_resets SET used_at=NOW() WHERE user_id=?', [$row['user_id']]);
        q('DELETE FROM login_attempts WHERE ip=?', [client_ip()]);
        flash('success', 'Your password has been changed. Sign in with the new password.');
        redirect('/login.php');
    }
}
page_header('Reset password');
?>
<div class="row justify-content-center"><div class="col-md-6 col-lg-5"><div class="card shadow-sm"><div class="card-body p-4">
<?php if (!$row): ?>
  <h1 class="h3 sp-display">Link expired</h1><p class="text-body-secondary">This reset link is invalid, already used, or older than 60 minutes.</p>
  <a class="btn btn-primary w-100" href="<?= e(url('forgot_password.php')) ?>">Request a new link</a>
<?php else: ?>
  <h1 class="h3 sp-display mb-3">Choose a new password</h1>
  <?php if ($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
  <form method="post" novalidate><?= csrf_field() ?><input type="hidden" name="token" value="<?= e($raw) ?>">
    <label class="form-label" for="p1">New password</label><input class="form-control mb-3" id="p1" type="password" name="password" minlength="6" required autocomplete="new-password" autofocus>
    <label class="form-label" for="p2">Repeat new password</label><input class="form-control mb-3" id="p2" type="password" name="password2" minlength="6" required autocomplete="new-password">
    <button class="btn btn-primary w-100 btn-lg">Change password</button></form>
<?php endif; ?>
</div></div></div></div>
<?php page_footer(); ?>
