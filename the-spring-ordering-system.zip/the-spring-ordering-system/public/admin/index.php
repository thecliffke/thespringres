<?php
define('ADMIN_ONLY', true);
require __DIR__ . '/_guard.php';
$today = date('Y-m-d');
$ordersToday = (int)val("SELECT COUNT(*) FROM orders WHERE DATE(created_at)=? AND status NOT IN ('awaiting_deposit','cancelled')", [$today]);
$collToday = (float)val('SELECT COALESCE(SUM(amount),0) FROM payments WHERE DATE(paid_at)=?', [$today]) - (float)val("SELECT COALESCE(SUM(amount),0) FROM refunds WHERE status='success' AND DATE(updated_at)=?", [$today]);
$active = (int)val("SELECT COUNT(*) FROM orders WHERE status IN ('placed','preparing','ready','dispatched')");
$out = row("SELECT COALESCE(SUM(total-amount_paid),0) s, COUNT(*) c FROM orders WHERE status NOT IN ('awaiting_deposit','cancelled') AND total-amount_paid>0.009");
$days = []; for ($i = 13; $i >= 0; $i--) $days[date('Y-m-d', strtotime("-$i day"))] = 0.0;
foreach (rows('SELECT DATE(paid_at) d, SUM(amount) s FROM payments WHERE paid_at >= (CURDATE() - INTERVAL 13 DAY) GROUP BY DATE(paid_at)') as $r) $days[$r['d']] = (float)$r['s'];
foreach (rows("SELECT DATE(updated_at) d, SUM(amount) s FROM refunds WHERE status='success' AND updated_at >= (CURDATE() - INTERVAL 13 DAY) GROUP BY DATE(updated_at)") as $r) if (isset($days[$r['d']])) $days[$r['d']] -= (float)$r['s'];
$top = rows("SELECT oi.name, SUM(oi.qty) q FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE o.status NOT IN ('awaiting_deposit','cancelled') GROUP BY oi.name ORDER BY q DESC LIMIT 5");
$recent = rows('SELECT p.*, o.order_no, o.customer_name FROM payments p JOIN orders o ON o.id=p.order_id ORDER BY p.id DESC LIMIT 6');
$pendingReq = (int)val("SELECT COUNT(*) FROM mpesa_requests WHERE status='pending' AND created_at > (NOW() - INTERVAL 10 MINUTE)");
page_header('Dashboard', ['admin' => true, 'active' => 'dash']);
echo Passkey::promptHtml();
$setup = [];
if (Mpesa::env() === 'simulate') $setup[] = 'M-Pesa is in <b>simulation mode</b>. Add your Daraja credentials under <a href="settings.php?tab=mpesa">Settings, M-Pesa</a> to take real payments.';
if (!Sms::configured() || !Sms::enabled()) $setup[] = 'SMS is not active. Add your SMS provider details under <a href="settings.php?tab=sms">Settings, SMS</a>.';
$cronAge = time() - (int)Settings::get('cron_last_run');
if ($cronAge > 600) $setup[] = 'The scheduled task is <b>not running</b>' . ((int)Settings::get('cron_last_run') ? ' (last run ' . (int)round($cronAge / 60) . ' minutes ago)' : ' (it has never run)') . '. Customer reminders and push notifications for them only fire while someone has the site open. Add the cron job from <a href="settings.php?tab=push">Settings, Push</a>.';
foreach ($setup as $s) echo '<div class="alert alert-info py-2">' . $s . '</div>';
?>
<div class="row g-3 mb-3 kpis">
  <div class="col-6 col-xl-3"><div class="kpi"><small>Orders today</small><b><?= $ordersToday ?></b></div></div>
  <div class="col-6 col-xl-3"><div class="kpi"><small>Collected today (after refunds)</small><b><?= money($collToday) ?></b></div></div>
  <div class="col-6 col-xl-3"><div class="kpi"><small>Active orders</small><b><?= $active ?></b></div></div>
  <div class="col-6 col-xl-3"><a class="kpi d-block text-decoration-none text-body" href="balances.php"><small>Balances to collect (<?= (int)$out['c'] ?>)</small><b><?= money($out['s']) ?></b></a></div>
</div>
<div class="row g-3">
  <div class="col-lg-8"><div class="card"><div class="card-body"><h2 class="h5 sp-display">Money collected, last 14 days</h2><canvas id="chart" height="110"></canvas></div></div></div>
  <div class="col-lg-4 vstack gap-3">
    <div class="card"><div class="card-body"><h2 class="h5 sp-display">Best sellers</h2>
      <?php if (!$top) echo '<p class="text-body-secondary mb-0">Sales appear here.</p>'; foreach ($top as $t) echo '<div class="d-flex justify-content-between py-1"><span>' . e($t['name']) . '</span><b>' . (int)$t['q'] . '</b></div>'; ?></div></div>
    <div class="card"><div class="card-body"><h2 class="h5 sp-display">Latest payments</h2>
      <?php if (!$recent) echo '<p class="text-body-secondary mb-0">No payments yet.</p>'; foreach ($recent as $p) echo '<div class="d-flex justify-content-between py-1 small"><span>' . e($p['order_no']) . ' ' . e($p['customer_name']) . '</span><b>' . money($p['amount']) . '</b></div>'; ?>
      <a href="payments.php" class="small">Search all payments</a><?php if ($pendingReq): ?><div class="small text-warning-emphasis mt-1"><?= $pendingReq ?> M-Pesa request(s) waiting for the customer.</div><?php endif; ?></div></div>
  </div>
</div>
<script>window.CHART=<?= json_encode(['labels' => array_map(fn($d) => date('D j', strtotime($d)), array_keys($days)), 'data' => array_values($days)]) ?>;</script>
<script>document.addEventListener('DOMContentLoaded',function(){
  var s=getComputedStyle(document.documentElement);
  new Chart(document.getElementById('chart'),{type:'bar',data:{labels:CHART.labels,datasets:[{label:'KES',data:CHART.data,backgroundColor:s.getPropertyValue('--sp-leaf').trim()||'#79A33D',borderRadius:8}]},options:{plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{callback:function(v){return v>=1000?(v/1000)+'k':v}}}}}});
});</script>
<?php page_footer(['admin' => true, 'chart' => true, 'scripts' => ['passkey.js']]); ?>
