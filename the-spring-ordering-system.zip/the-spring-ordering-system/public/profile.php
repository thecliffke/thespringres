<?php
require __DIR__ . '/../app/bootstrap.php';
$u = Auth::require();
if (is_post()) {
    csrf_check();
    $name = post('name'); $new = (string)($_POST['new_password'] ?? '');
    $blankOk = !empty($u['google_id']) && post('phone') === '';   // Google sign-ups may leave the phone empty
    $ph = $blankOk ? '' : norm_phone(post('phone'));
    if ($name === '' || $ph === null) flash('danger', $name === '' ? 'Enter your name.' : 'Enter a valid Safaricom number, for example 0712 345 678.');
    else {
        q('UPDATE users SET name=?, phone=? WHERE id=?', [$name, $ph, $u['id']]);
        if ($name !== $u['name'] || $ph !== $u['phone']) Audit::log('user.profile_updated', 'Updated own profile' . ($ph !== $u['phone'] ? ' (phone changed)' : '') . ($name !== $u['name'] ? ' (name changed)' : ''), 'user', $u['id']);
        if ($new !== '') {
            $hash = (string)val('SELECT password_hash FROM users WHERE id=?', [$u['id']]);
            if ((int)$u['password_set'] === 1 && !password_verify((string)($_POST['current_password'] ?? ''), $hash)) { flash('danger', 'Your current password is wrong, so the password was not changed.'); redirect('/profile.php'); }
            if (strlen($new) < 6) { flash('danger', 'The new password needs at least 6 characters.'); redirect('/profile.php'); }
            q('UPDATE users SET password_hash=?, password_set=1 WHERE id=?', [password_hash($new, PASSWORD_DEFAULT), $u['id']]);
            Audit::log('user.password_changed', 'Changed own password', 'user', $u['id']);
        }
        flash('success', 'Profile saved.'); redirect('/profile.php');
    }
}
page_header('My profile');
?>
<div class="row justify-content-center"><div class="col-md-7 col-lg-5"><div class="card"><div class="card-body p-4">
<h1 class="h3 sp-display mb-3">My profile</h1>
<?php if ($u['role'] === 'customer'): ?><a class="d-flex justify-content-between align-items-center border rounded-3 p-3 mb-3 text-decoration-none text-body" href="<?= e(url('addresses.php')) ?>"><span><i class="bi bi-geo-alt me-1"></i><b>Delivery addresses</b><span class="d-block small text-body-secondary">Save places you order to, with a landmark and map pin</span></span><i class="bi bi-chevron-right"></i></a><?php endif; ?>
<?php if (Passkey::enabled()): $pks = Passkey::forUser((int)$u['id']); ?>
<div class="border rounded-3 p-3 mb-4">
  <div class="fw-semibold mb-1"><i class="bi bi-fingerprint me-1"></i>Fingerprint sign-in</div>
  <p class="small text-body-secondary mb-2">Sign in with your fingerprint, face or screen lock. Your biometrics never leave your phone; we only keep a public key.</p>
  <?php foreach ($pks as $k): ?><div class="d-flex justify-content-between align-items-center gap-2 py-1 border-top small"><span><b><?= e($k['label']) ?></b><br><span class="text-body-secondary">Added <?= e(fmt_dt($k['created_at'], 'j M Y')) ?><?= $k['last_used_at'] ? ', last used ' . e(fmt_dt($k['last_used_at'], 'j M Y, g:i A')) : ', not used yet' ?></span></span><button type="button" class="btn btn-outline-danger btn-sm" data-passkey-remove="<?= (int)$k['id'] ?>">Remove</button></div><?php endforeach; ?>
  <button type="button" class="btn btn-outline-primary btn-sm mt-2 d-none" data-passkey-add><i class="bi bi-plus-lg me-1"></i><?= $pks ? 'Add another device' : 'Turn on for this device' ?></button>
  <div class="small mt-2 d-none" data-passkey-msg role="status" aria-live="polite"></div>
  <div class="small text-body-secondary mt-2 d-none" data-passkey-unsupported>This browser or device cannot use fingerprint sign-in (it needs https and a screen lock or biometric).</div>
</div>
<?php endif; ?>
<form method="post"><?= csrf_field() ?>
  <label class="form-label">Email</label><input class="form-control mb-3" value="<?= e($u['email']) ?>" disabled>
  <label class="form-label" for="n">Full name</label><input class="form-control mb-3" id="n" name="name" value="<?= e($u['name']) ?>" required>
  <label class="form-label" for="p">Phone<?= $u['google_id'] ? ' (optional)' : '' ?></label><input class="form-control mb-3" id="p" name="phone" inputmode="tel" value="<?= e(local_phone($u['phone'])) ?>" placeholder="0712 345 678"<?= $u['google_id'] ? '' : ' required' ?>>
  <?php if ($u['google_id']): ?><p class="small text-body-secondary mb-3"><i class="bi bi-google me-1"></i>Your account is linked to Google, so you can sign in with the Google button.</p><?php endif; ?>
  <hr><p class="fw-semibold mb-2"><?= (int)$u['password_set'] === 1 ? 'Change password (optional)' : 'Set a password (optional)' ?></p>
  <?php if ((int)$u['password_set'] === 1): ?><input class="form-control mb-2" type="password" name="current_password" placeholder="Current password" autocomplete="current-password"><?php else: ?><p class="form-text mt-0">You signed up with Google, so you have no password yet. Set one if you also want to sign in with your email.</p><?php endif; ?>
  <input class="form-control mb-3" type="password" name="new_password" placeholder="New password" autocomplete="new-password">
  <button class="btn btn-primary">Save profile</button>
</form></div></div></div></div>
<?php page_footer(['scripts' => ['passkey.js']]); ?>
