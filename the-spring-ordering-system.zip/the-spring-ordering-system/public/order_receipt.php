<?php
/** Combined (reconciled) receipt: every payment made on one order, with refunds netted off, in one statement. */
require __DIR__ . '/../app/bootstrap.php';
$u = Auth::require();
$o = Orders::find((int)get('order'));
if (!$o || (!Auth::isStaff() && (int)$o['customer_id'] !== (int)$u['id'])) { http_response_code(404); flash('danger', 'Order not found.'); redirect(Auth::home($u)); }
$pays = rows('SELECT p.*, u.name received_name FROM payments p LEFT JOIN users u ON u.id=p.received_by WHERE p.order_id=? ORDER BY p.paid_at, p.id', [$o['id']]);
if (!$pays) { flash('warning', 'There are no payments on ' . $o['order_no'] . ' yet, so there is no receipt to show.'); redirect(Auth::isStaff() ? '/admin/order.php?id=' . $o['id'] : '/order.php?id=' . $o['id']); }
$items = Orders::items((int)$o['id']);
$total = (float)$o['total'];
$gross = 0.0; $refunded = 0.0;
foreach ($pays as $p) { $gross += (float)$p['amount']; $refunded += (float)$p['reversed_amount']; }
$net = $gross - $refunded;
$balance = max(0.0, $total - $net);
$credit = max(0.0, $net - $total);
$paidInFull = $balance < 1;
$pct = fn(float $a) => $total > 0 ? rtrim(rtrim(number_format($a / $total * 100, 1), '0'), '.') . '%' : '0%';
$r = fn($a, $b, $c = '') => '<div class="r ' . $c . '"><span>' . $a . '</span><span>' . $b . '</span></div>';
$sub = fn($t) => '<div class="r sub"><span>' . $t . '</span></div>';
$last = end($pays); $first = reset($pays);
$title = 'Order receipt ' . $o['order_no'];
page_header($title, ['admin' => Auth::isStaff(), 'active' => 'payments']);
?>
<div class="receipt receipt-order">
  <?php if (Settings::get('logo')): ?><div class="text-center mb-2"><img src="<?= e(url('uploads/' . basename(Settings::get('logo')))) ?>" alt="" style="max-height:60px;max-width:200px"></div><?php endif; ?>
  <h2><?= e(Settings::get('restaurant_name')) ?></h2>
  <div class="text-center small"><?= Settings::get('restaurant_address') ? e(Settings::get('restaurant_address')) . '<br>' : '' ?><?= Settings::get('restaurant_phone') ? e(Settings::get('restaurant_phone')) . '<br>' : '' ?><b>Combined receipt: all payments for this order</b></div>
  <div class="text-center"><span class="stamp <?= $paidInFull ? 'paid' : 'part' ?>"><?= $paidInFull ? 'Paid in full' : 'Part paid, balance due' ?></span></div><hr>
  <?= $r('Order', e($o['order_no'])) . $r('Placed', e(fmt_dt($o['created_at'], 'j M Y, g:i A'))) . $r('Customer', e($o['customer_name'])) . $r('Type', e(type_label($o['type']))) . $r('Order status', e(status_label($o['status'], $o['type']))) . $r('Issued', e(date('j M Y, g:i A'))) ?><hr>
  <?php foreach ($items as $i) echo $r((int)$i['qty'] . ' x ' . e($i['name']), money($i['qty'] * $i['unit_price'])); ?>
  <?= $r('Subtotal', money($o['subtotal'])) . ($o['delivery_fee'] > 0 ? $r('Delivery fee', money($o['delivery_fee'])) : '') . ($o['loyalty_discount'] > 0 ? $r('Loyalty discount (' . number_format((int)$o['loyalty_points']) . ' points)', '- ' . money($o['loyalty_discount'])) : '') . $r('Order total', money($total), 't') ?><hr>
  <div class="fw-bold mb-1">Payments received</div>
  <?php $run = 0.0; foreach ($pays as $n => $p):
      $run += (float)$p['amount'] - (float)$p['reversed_amount'];
      $how = $p['method'] === 'cash' ? 'Cash' . ($p['received_name'] ? ', received by ' . e($p['received_name']) : '') : 'M-Pesa ' . e($p['mpesa_receipt'] ?: 'code pending') . ($p['method'] === 'mpesa_manual' ? ' (confirmed by staff)' : '');
  ?>
  <?= $r(($n + 1) . '. ' . e($p['receipt_no']) . ' ' . ($p['kind'] === 'deposit' ? 'Deposit' : 'Balance'), money($p['amount']), 'p') ?>
  <?= $sub(e(fmt_dt($p['paid_at'], 'j M Y, g:i A')) . ' &middot; ' . $how) ?>
  <?= $sub($pct((float)$p['amount']) . ' of order' . ((float)$p['reversed_amount'] > 0 ? ' &middot; refunded ' . money($p['reversed_amount']) : '') . ' &middot; balance after: ' . money(max(0, $total - $run))) ?>
  <?php endforeach; ?><hr>
  <div class="fw-bold mb-1">Reconciliation</div>
  <?= $r('Order total', money($total)) . $r('Total received (' . count($pays) . ' payment' . (count($pays) === 1 ? '' : 's') . ')', money($gross)) ?>
  <?= $refunded > 0 ? $r('Less refunds', '- ' . money($refunded)) . $r('Net paid', money($net), 't') : $r('Net paid', money($net), 't') ?>
  <?= $r('Share of order paid', $pct($net)) ?>
  <?= $credit >= 1 ? $r('Overpaid (to be refunded or credited)', money($credit), 't') : $r('Balance remaining', money($balance), 't') ?><hr>
  <div class="text-center small mb-1">Individual receipts: <?= e(implode(', ', array_column($pays, 'receipt_no'))) ?></div>
  <div class="text-center">Thank you for choosing <?= e(Settings::get('restaurant_name')) ?>.</div>
</div>
<div class="text-center mt-3 no-print d-flex flex-wrap gap-2 justify-content-center"><button class="btn btn-primary" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print or save as PDF</button>
  <a class="btn btn-outline-secondary" href="<?= e(url(Auth::isStaff() ? 'admin/order.php?id=' . $o['id'] : 'order.php?id=' . $o['id'])) ?>">Back to order</a></div>
<?php if (Auth::isStaff() && abs($net - (float)$o['amount_paid']) >= 1): ?><div class="alert alert-warning mt-3 no-print small mx-auto" style="max-width:30rem">Staff note: the order record says <?= e(money($o['amount_paid'])) ?> has been paid, but its payments add up to <?= e(money($net)) ?> net. Check the payments and refunds on this order.</div><?php endif; ?>
<?php page_footer(['admin' => Auth::isStaff()]); ?>
