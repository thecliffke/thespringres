<?php
define('ADMIN_ONLY', true);
require __DIR__ . '/_guard.php';
if (is_post()) {
    csrf_check();
    if (post('action') === 'start') {
        $cid = (int)post('customer_id');
        if (!val("SELECT 1 FROM users WHERE id=? AND role='customer'", [$cid])) { flash('danger', 'Customer not found.'); redirect('/admin/messages.php'); }
        $r = Messages::start($ME, $cid, post('subject'), post('body'), (int)post('order_id') ?: null);
        flash($r['ok'] ? 'success' : 'danger', $r['ok'] ? 'Message sent. The customer has been notified.' : $r['message']);
        redirect($r['ok'] ? '/admin/thread.php?id=' . $r['id'] : '/admin/messages.php');
    }
    redirect('/admin/messages.php');
}
$qv = get('q'); $st = in_array(get('s'), ['open', 'closed', 'unread'], true) ? get('s') : 'all'; $per = 25; $pg = page_num();
$where = ['1=1']; $p = [];
if ($qv !== '') {
    $where[] = '(t.subject LIKE ? OR u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR o.order_no LIKE ? OR EXISTS (SELECT 1 FROM messages m WHERE m.thread_id=t.id AND m.body LIKE ?))';
    array_push($p, "%$qv%", "%$qv%", "%$qv%", phone_term($qv), "%$qv%", "%$qv%");
}
if ($st === 'open' || $st === 'closed') { $where[] = 't.status=?'; $p[] = $st; }
if ($st === 'unread') $where[] = 't.admin_unread > 0';
$W = implode(' AND ', $where);
$base = "FROM message_threads t JOIN users u ON u.id=t.customer_id LEFT JOIN orders o ON o.id=t.order_id WHERE $W";
$total = (int)val("SELECT COUNT(*) $base", $p);
$list = rows("SELECT t.*, u.name customer_name, o.order_no, (SELECT body FROM messages m WHERE m.thread_id=t.id ORDER BY m.id DESC LIMIT 1) last_body $base ORDER BY (t.admin_unread > 0) DESC, t.last_message_at DESC LIMIT $per OFFSET " . (($pg - 1) * $per), $p);
$unread = Messages::adminUnread();
page_header('Messages', ['admin' => true, 'active' => 'messages']);
?>
<form class="row g-2 mb-3" method="get"><input type="hidden" name="s" value="<?= e($st) ?>">
  <div class="col"><input class="form-control" type="search" name="q" value="<?= e($qv) ?>" placeholder="Search a customer, order number, subject or what was said"></div>
  <div class="col-auto"><button class="btn btn-primary">Search</button></div></form>
<ul class="nav nav-pills mb-3 flex-nowrap overflow-auto"><?php foreach (['all' => 'All', 'unread' => 'Unread' . ($unread ? ' (' . $unread . ')' : ''), 'open' => 'Open', 'closed' => 'Closed'] as $k => $l) echo '<li class="nav-item"><a class="nav-link text-nowrap ' . ($st === $k ? 'active' : '') . '" href="?' . e(http_build_query(['s' => $k, 'q' => $qv])) . '">' . e($l) . '</a></li>'; ?></ul>
<div class="card"><div class="list-group list-group-flush">
<?php if (!$list) echo '<div class="list-group-item text-body-secondary py-4">No conversations here.</div>'; ?>
<?php foreach ($list as $t): ?>
  <a class="list-group-item list-group-item-action d-flex gap-3 align-items-start <?= $t['admin_unread'] ? 'fw-semibold' : '' ?>" href="thread.php?id=<?= (int)$t['id'] ?>">
    <span class="mt-2 rounded-circle" style="width:10px;height:10px;flex:none;background:<?= $t['admin_unread'] ? 'var(--sp-yellow)' : 'transparent' ?>"></span>
    <span class="flex-grow-1" style="min-width:0"><?= e($t['customer_name']) ?>: <?= e($t['subject']) ?> <?= $t['status'] === 'closed' ? '<span class="badge text-bg-secondary">Closed</span>' : '' ?><?= $t['order_no'] ? ' <span class="badge text-bg-light border">' . e($t['order_no']) . '</span>' : '' ?><?= $t['admin_unread'] ? ' <span class="badge text-bg-warning">' . (int)$t['admin_unread'] . ' new</span>' : '' ?>
      <br><span class="fw-normal small text-body-secondary d-block text-truncate"><?= $t['last_sender'] === 'admin' ? 'You: ' : '' ?><?= e(mb_substr((string)$t['last_body'], 0, 110)) ?></span></span>
    <small class="text-body-secondary text-nowrap"><?= e(fmt_dt($t['last_message_at'], 'j M, g:i A')) ?></small></a>
<?php endforeach; ?></div></div>
<div class="d-flex justify-content-between align-items-center mt-3"><small class="text-body-secondary"><?= $total ?> conversation<?= $total === 1 ? '' : 's' ?></small><?= pager($total, $pg, $per) ?></div>
<?php page_footer(['admin' => true]); ?>
