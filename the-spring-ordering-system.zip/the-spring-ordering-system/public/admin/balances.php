<?php
require __DIR__ . '/_guard.php';
if (is_post()) {
    csrf_check();
    $o = Orders::find((int)post('id'));
    if ($o && post('action') === 'sms' && Orders::balance($o) >= 1) {
        $msg = Sms::render('sms_tpl_balance', ['name' => explode(' ', $o['customer_name'])[0], 'order' => $o['order_no'], 'restaurant' => Settings::get('restaurant_name'), 'balance' => money(Orders::balance($o)), 'paid' => money($o['amount_paid']), 'paybill' => Settings::payNumber() ?: '(not set)', 'till' => Settings::payNumber() ?: '(not set)', 'pay_details' => Settings::payDetails($o['order_no'])]);
        $r = Sms::send($o['phone'], $msg, 'balance', (int)$o['customer_id']); Audit::log('order.balance_sms', 'Balance reminder SMS ' . ($r['ok'] ? 'sent' : 'failed') . ' for ' . $o['order_no'], 'order', (int)$o['id']); flash($r['ok'] ? 'success' : 'danger', $o['order_no'] . ': ' . $r['message']);
    }
    redirect('/admin/balances.php?' . http_build_query(array_filter(['q' => post('qq')])));
}
$qv = get('q'); $type = get('type'); $age = get('age');
$where = ["o.status NOT IN ('awaiting_deposit','cancelled')", '(o.total - o.amount_paid) > 0.009']; $p = [];
if ($qv !== '') { $where[] = '(o.order_no LIKE ? OR o.customer_name LIKE ? OR o.phone LIKE ?)'; array_push($p, "%$qv%", "%$qv%", phone_term($qv)); }
if ($type === 'dine_in' || $type === 'delivery') { $where[] = 'o.type=?'; $p[] = $type; }
if ($age === 'overdue') $where[] = "(o.status IN ('ready','dispatched','completed') OR o.scheduled_at < NOW())";
$W = implode(' AND ', $where);
$rowsAll = rows("SELECT o.*, (o.total - o.amount_paid) AS bal FROM orders o WHERE $W ORDER BY o.scheduled_at ASC", $p);
if (get('export') === '1') { Audit::log('export.balances', 'Exported ' . count($rowsAll) . ' outstanding balance(s) to CSV', 'export', null, ['rows' => count($rowsAll)]); }
if (get('export') === '1') csv_out('balances', ['Order', 'Customer', 'Phone', 'Type', 'Status', 'Scheduled', 'Total', 'Paid', 'Balance'],
    array_map(fn($o) => [$o['order_no'], $o['customer_name'], $o['phone'], type_label($o['type']), status_label($o['status'], $o['type']), $o['scheduled_at'], $o['total'], $o['amount_paid'], $o['bal']], $rowsAll));
$sum = array_sum(array_column($rowsAll, 'bal'));
page_header('Balances to collect', ['admin' => true, 'active' => 'balances']);
?>
<div class="row g-3 mb-3"><div class="col-6 col-md-3"><div class="kpi"><small>Total outstanding</small><b><?= money($sum) ?></b></div></div><div class="col-6 col-md-3"><div class="kpi"><small>Orders with a balance</small><b><?= count($rowsAll) ?></b></div></div></div>
<form class="row g-2 mb-3" method="get">
  <div class="col-12 col-md"><input class="form-control" type="search" name="q" value="<?= e($qv) ?>" placeholder="Search order no, customer name or phone"></div>
  <div class="col-6 col-md-2"><select class="form-select" name="type"><option value="">Any type</option><option value="dine_in" <?= $type === 'dine_in' ? 'selected' : '' ?>>Dine in</option><option value="delivery" <?= $type === 'delivery' ? 'selected' : '' ?>>Delivery</option></select></div>
  <div class="col-6 col-md-2"><select class="form-select" name="age"><option value="">All</option><option value="overdue" <?= $age === 'overdue' ? 'selected' : '' ?>>Due now</option></select></div>
  <div class="col-12 col-md-auto d-flex gap-2"><button class="btn btn-primary flex-grow-1">Search</button><a class="btn btn-outline-primary" href="?<?= e(http_build_query(array_merge($_GET, ['export' => 1]))) ?>" title="Export CSV"><i class="bi bi-download"></i></a></div></form>
<div class="card"><div class="table-responsive"><table class="table align-middle mb-0">
<thead><tr><th>Order</th><th>Customer</th><th>Type</th><th>Scheduled</th><th>Status</th><th class="text-end">Total</th><th class="text-end">Paid</th><th class="text-end">Balance</th><th></th></tr></thead><tbody>
<?php if (!$rowsAll) echo '<tr><td colspan="9" class="text-center text-body-secondary py-4">No outstanding balances.</td></tr>'; ?>
<?php foreach ($rowsAll as $o): $canAsk = in_array($o['status'], ['ready', 'dispatched', 'completed', 'preparing', 'placed'], true); ?>
<tr><td><a class="fw-bold" href="order.php?id=<?= (int)$o['id'] ?>"><?= e($o['order_no']) ?></a></td><td><?= e($o['customer_name']) ?><div class="small">+<?= e($o['phone']) ?></div></td><td><?= e(type_label($o['type'])) ?></td>
 <td class="text-nowrap"><?= $o['asap'] ? 'ASAP' : e(fmt_dt($o['scheduled_at'])) ?></td><td><?= status_badge($o) ?></td>
 <td class="text-end"><?= money($o['total']) ?></td><td class="text-end"><?= money($o['amount_paid']) ?></td><td class="text-end fw-bold text-danger"><?= money($o['bal']) ?></td>
 <td class="text-end text-nowrap"><a class="btn btn-primary btn-sm" href="order.php?id=<?= (int)$o['id'] ?>#pay"><i class="bi bi-phone me-1"></i>Request M-Pesa</a>
  <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="sms"><input type="hidden" name="id" value="<?= (int)$o['id'] ?>"><input type="hidden" name="qq" value="<?= e($qv) ?>"><button class="btn btn-outline-secondary btn-sm" title="Send SMS reminder"><i class="bi bi-chat-dots"></i></button></form></td></tr>
<?php endforeach; ?></tbody>
<?php if ($rowsAll): ?><tfoot><tr class="fw-bold"><td colspan="7" class="text-end">Total outstanding</td><td class="text-end text-danger"><?= money($sum) ?></td><td></td></tr></tfoot><?php endif; ?></table></div></div>
<?php page_footer(['admin' => true]); ?>
