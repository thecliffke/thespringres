<?php
require __DIR__ . '/../../app/bootstrap.php';
if (!is_post()) json_out(['ok' => false], 405);
csrf_check();
$u = Auth::user();
if (!$u) json_out(['ok' => false, 'message' => 'Please sign in again.'], 401);
$o = Orders::find((int)($_POST['order_id'] ?? 0));
$staff = Auth::isStaff();
if (!$o || (!$staff && (int)$o['customer_id'] !== (int)$u['id'])) json_out(['ok' => false, 'message' => 'Order not found.'], 404);
$kind = ($_POST['kind'] ?? '') === 'balance' ? 'balance' : 'deposit';
if ($kind === 'deposit' && $staff && (int)$o['customer_id'] !== (int)$u['id']) { /* staff may also trigger a stuck deposit */ }
$amt = isset($_POST['amount']) && $_POST['amount'] !== '' ? (float)str_replace(',', '', (string)$_POST['amount']) : null;
try { json_out(Mpesa::initiate((int)$o['id'], $kind, (string)($_POST['phone'] ?? ''), (int)$u['id'], $staff, $amt)); }
catch (Throwable $e) { error_log($e->getMessage()); json_out(['ok' => false, 'message' => 'Something went wrong starting the payment. Try again.']); }
