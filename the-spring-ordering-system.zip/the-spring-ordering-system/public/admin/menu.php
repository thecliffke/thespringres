<?php
define('ADMIN_ONLY', true);
require __DIR__ . '/_guard.php';
if (is_post()) {
    csrf_check();
    $a = post('action'); $id = (int)post('id');
    if ($a === 'toggle') { q('UPDATE menu_items SET is_available = 1 - is_available WHERE id=?', [$id]); $mi = row('SELECT name,is_available FROM menu_items WHERE id=?', [$id]); if ($mi) Audit::log('menu.availability', ($mi['is_available'] ? 'Showed ' : 'Hid ') . $mi['name'] . ' on the menu', 'menu_item', $id); }
    elseif ($a === 'delete') {
        $img = val('SELECT image FROM menu_items WHERE id=?', [$id]);
        $mi = row('SELECT name,price FROM menu_items WHERE id=?', [$id]);
        q('DELETE FROM menu_items WHERE id=?', [$id]);
        Audit::log('menu.item_deleted', 'Deleted menu item ' . ($mi['name'] ?? '#' . $id), 'menu_item', $id, ['price' => $mi['price'] ?? null]);
        if ($img && is_file(PUBLIC_PATH . '/uploads/' . basename($img))) @unlink(PUBLIC_PATH . '/uploads/' . basename($img));
        flash('success', 'Menu item deleted. Past orders keep their records.');
    } elseif ($a === 'cat_add' && post('name') !== '') { q('INSERT INTO categories (name, sort_order) VALUES (?, ?)', [mb_substr(post('name'), 0, 80), (int)val('SELECT COALESCE(MAX(sort_order),0)+1 FROM categories')]); Audit::log('menu.category_added', 'Added category ' . post('name'), 'category', null); flash('success', 'Category added.'); }
    elseif ($a === 'cat_rename' && post('name') !== '') { q('UPDATE categories SET name=?, sort_order=? WHERE id=?', [mb_substr(post('name'), 0, 80), (int)post('sort'), $id]); Audit::log('menu.category_updated', 'Saved category ' . post('name'), 'category', $id); flash('success', 'Category saved.'); }
    elseif ($a === 'cat_delete') {
        if ((int)val('SELECT COUNT(*) FROM menu_items WHERE category_id=?', [$id]) > 0) flash('danger', 'Move or delete the dishes in that category first.');
        else { $cn = (string)val('SELECT name FROM categories WHERE id=?', [$id]); q('DELETE FROM categories WHERE id=?', [$id]); Audit::log('menu.category_deleted', 'Deleted category ' . $cn, 'category', $id); flash('success', 'Category deleted.'); }
    }
    redirect('/admin/menu.php');
}
$qv = get('q'); $cat = (int)get('cat');
$cats = rows('SELECT c.*, (SELECT COUNT(*) FROM menu_items m WHERE m.category_id=c.id) n FROM categories c ORDER BY sort_order, name');
$where = ['1=1']; $p = [];
if ($qv !== '') { $where[] = '(m.name LIKE ? OR m.description LIKE ?)'; array_push($p, "%$qv%", "%$qv%"); }
if ($cat) { $where[] = 'm.category_id=?'; $p[] = $cat; }
$items = rows('SELECT m.*, c.name cat FROM menu_items m JOIN categories c ON c.id=m.category_id WHERE ' . implode(' AND ', $where) . ' ORDER BY c.sort_order, m.sort_order, m.name', $p);
page_header('Menu and offers', ['admin' => true, 'active' => 'menu']);
?>
<div class="row g-3">
 <div class="col-xl-8">
  <div class="d-flex flex-wrap gap-2 mb-3"><form class="d-flex gap-2 flex-grow-1" method="get"><input class="form-control" type="search" name="q" value="<?= e($qv) ?>" placeholder="Search dishes">
    <select class="form-select w-auto" name="cat"><option value="0">All categories</option><?php foreach ($cats as $c) echo '<option value="' . (int)$c['id'] . '"' . ($cat === (int)$c['id'] ? ' selected' : '') . '>' . e($c['name']) . '</option>'; ?></select><button class="btn btn-outline-primary">Filter</button></form>
    <a class="btn btn-primary" href="menu_edit.php"><i class="bi bi-plus-lg me-1"></i>Add dish</a></div>
  <div class="card"><div class="list-group list-group-flush">
  <?php if (!$items) echo '<div class="list-group-item text-body-secondary py-4">No dishes found.</div>'; foreach ($items as $i): $on = Orders::offerActive($i); ?>
   <div class="list-group-item d-flex align-items-center gap-3 flex-wrap">
    <div class="thumb"><?= $i['image'] ? '<img alt="" src="' . e(url('uploads/' . $i['image'])) . '">' : e($i['emoji'] ?: '🍽️') ?></div>
    <div class="flex-grow-1" style="min-width:10rem"><b><?= e($i['name']) ?></b> <?= $i['is_available'] ? '' : '<span class="badge text-bg-secondary">Hidden</span>' ?><div class="small text-body-secondary"><?= e($i['cat']) ?>, <?= money($i['price']) ?>
      <?php if ($on): ?><span class="badge text-bg-warning"><?= (int)$i['offer_percent'] ?>% off now <?= money(Orders::priceOf($i)) ?></span><?php elseif ($i['offer_percent'] > 0): ?><span class="badge text-bg-light border">Offer ended</span><?php endif; ?></div></div>
    <div class="d-flex gap-2"><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$i['id'] ?>"><button class="btn btn-outline-secondary btn-sm"><?= $i['is_available'] ? 'Hide' : 'Show' ?></button></form>
     <a class="btn btn-outline-primary btn-sm" href="menu_edit.php?id=<?= (int)$i['id'] ?>">Edit</a>
     <form method="post" data-confirm="Delete <?= e($i['name']) ?>?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$i['id'] ?>"><button class="btn btn-outline-danger btn-sm">Delete</button></form></div>
   </div><?php endforeach; ?>
  </div></div>
 </div>
 <div class="col-xl-4"><div class="card"><div class="card-body"><h2 class="h5 sp-display">Categories</h2>
  <?php foreach ($cats as $c): ?><form method="post" class="d-flex gap-2 mb-2"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
   <input class="form-control form-control-sm" name="name" value="<?= e($c['name']) ?>" aria-label="Category name"><input class="form-control form-control-sm" style="width:4rem" type="number" name="sort" value="<?= (int)$c['sort_order'] ?>" aria-label="Order" title="Sort order">
   <button class="btn btn-outline-primary btn-sm" name="action" value="cat_rename">Save</button><button class="btn btn-outline-danger btn-sm" name="action" value="cat_delete" title="<?= (int)$c['n'] ?> dishes" onclick="return confirm('Delete this category?')"><i class="bi bi-trash"></i></button></form><?php endforeach; ?>
  <form method="post" class="d-flex gap-2 mt-3"><?= csrf_field() ?><input type="hidden" name="action" value="cat_add"><input class="form-control form-control-sm" name="name" placeholder="New category" required><button class="btn btn-primary btn-sm">Add</button></form>
 </div></div></div>
</div>
<?php page_footer(['admin' => true]); ?>
