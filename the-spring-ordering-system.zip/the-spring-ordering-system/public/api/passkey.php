<?php
/** JSON endpoint for fingerprint (passkey) sign-in. Every call is a POST with the page's CSRF token in X-CSRF-Token. */
require __DIR__ . '/../../app/bootstrap.php';
if (!is_post()) json_out(['ok' => false, 'message' => 'Method not allowed.'], 405);
csrf_check();
if (!Passkey::enabled()) json_out(['ok' => false, 'message' => 'Fingerprint sign-in is switched off.'], 403);
$in = json_decode((string)file_get_contents('php://input'), true);
if (!is_array($in)) json_out(['ok' => false, 'message' => 'Bad request.'], 400);
$a = (string)($in['action'] ?? '');
$fail = fn(string $m, int $c = 400) => json_out(['ok' => false, 'message' => $m], $c);

try {
    if ($a === 'login_options') {
        if (Auth::user()) $fail('You are already signed in.');
        if (Auth::lockRemaining(client_ip()) > 0) $fail('Too many failed attempts. Please try again in a few minutes.', 429);
        json_out(['ok' => true, 'options' => Passkey::requestOptions()]);
    }
    if ($a === 'login') {
        if (Auth::user()) $fail('You are already signed in.');
        $ip = client_ip();
        if (Auth::lockRemaining($ip) > 0) $fail('Too many failed attempts. Please try again in a few minutes.', 429);
        try { $u = Passkey::authenticate((array)($in['credential'] ?? [])); }
        catch (RuntimeException $e) {
            q('INSERT INTO login_attempts (ip,email) VALUES (?,?)', [$ip, 'fingerprint']);
            Audit::log('auth.passkey_failed', 'Failed fingerprint sign-in: ' . $e->getMessage(), null, null, [], []);
            $fail($e->getMessage(), 401);
        }
        if (!$u['is_active']) { Audit::log('auth.login_blocked', 'Fingerprint sign-in refused: account is deactivated (' . $u['email'] . ')', 'user', $u['id'], [], []); $fail('This account is deactivated. Contact the restaurant.', 403); }
        q('DELETE FROM login_attempts WHERE ip=?', [$ip]);
        Auth::start($u);
        Audit::log('auth.login', 'Signed in with fingerprint (passkey)', 'user', $u['id'], ['method' => 'passkey', 'passkey_id' => $u['_passkey_id']], $u);
        json_out(['ok' => true, 'redirect' => url(Auth::nextUrl())]);
    }

    $me = Auth::user();
    if (!$me) $fail('Please sign in first.', 401);
    if ($a === 'create_options') json_out(['ok' => true, 'options' => Passkey::creationOptions($me)]);
    if ($a === 'create') {
        $id = Passkey::register($me, (array)($in['credential'] ?? []), (string)($_SERVER['HTTP_USER_AGENT'] ?? ''));
        Audit::log('auth.passkey_added', 'Turned on fingerprint sign-in for ' . $me['email'] . ' (' . Passkey::deviceLabel((string)($_SERVER['HTTP_USER_AGENT'] ?? '')) . ')', 'user', $me['id'], ['passkey_id' => $id]);
        json_out(['ok' => true, 'message' => 'Fingerprint sign-in is on for this device.']);
    }
    if ($a === 'remove') {
        $k = row('SELECT id,label FROM passkeys WHERE id=? AND user_id=?', [(int)($in['id'] ?? 0), $me['id']]);
        if (!$k) $fail('That device was not found.', 404);
        q('DELETE FROM passkeys WHERE id=?', [$k['id']]);
        Audit::log('auth.passkey_removed', 'Removed fingerprint sign-in for ' . $k['label'], 'user', $me['id'], ['passkey_id' => (int)$k['id']]);
        json_out(['ok' => true, 'message' => 'Removed.']);
    }
    $fail('Unknown action.');
} catch (RuntimeException $e) {
    $fail($e->getMessage());
} catch (Throwable $e) {
    error_log('passkey api: ' . $e->getMessage());
    $fail('Something went wrong. Please try again.', 500);
}
