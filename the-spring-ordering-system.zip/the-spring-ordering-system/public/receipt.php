<?php
require __DIR__ . '/../app/bootstrap.php';
$u = Auth::require();
$p = row('SELECT * FROM payments WHERE id=?', [(int)get('id')]);
$o = $p ? Orders::find((int)$p['order_id']) : null;
if (!$p || !$o || (!Auth::isStaff() && (int)$o['customer_id'] !== (int)$u['id'])) { http_response_code(404); flash('danger', 'Receipt not found.'); redirect(Auth::home($u)); }
$items = Orders::items((int)$o['id']);
$upto = (float)val('SELECT SUM(amount) FROM payments WHERE order_id=? AND id<=?', [$o['id'], $p['id']]);
$bal = max(0, (float)$o['total'] - $upto);
$r = fn($a, $b, $c = '') => '<div class="r ' . $c . '"><span>' . $a . '</span><span>' . $b . '</span></div>';
page_header('Receipt ' . $p['receipt_no'], ['admin' => Auth::isStaff(), 'active' => 'payments']);
?>
<div class="receipt">
  <?php if (Settings::get('logo')): ?><div class="text-center mb-2"><img src="<?= e(url('uploads/' . basename(Settings::get('logo')))) ?>" alt="" style="max-height:60px;max-width:200px"></div><?php endif; ?>
  <h2><?= e(Settings::get('restaurant_name')) ?></h2>
  <div class="text-center small"><?= Settings::get('restaurant_address') ? e(Settings::get('restaurant_address')) . '<br>' : '' ?><?= Settings::get('restaurant_phone') ? e(Settings::get('restaurant_phone')) . '<br>' : '' ?>Payment receipt</div><hr>
  <?= $r('Receipt', e($p['receipt_no'])) . $r('Date', e(fmt_dt($p['paid_at'], 'j M Y, g:i A'))) . $r('Order', e($o['order_no'])) . $r('Customer', e($o['customer_name'])) . $r('Type', e(type_label($o['type']))) ?>
  <?php if ($p['method'] === 'cash'): ?><?= $r('Payment method', 'Cash') . $r('Received by', e((string)val('SELECT name FROM users WHERE id=?', [$p['received_by']]) ?: 'Staff')) . ($p['note'] ? $r('Note', e($p['note'])) : '') ?>
  <?php else: ?><?= $r('Payment method', 'M-Pesa') . $r('M-Pesa code', e($p['mpesa_receipt'] ?: 'Pending confirmation')) . $r('Paid from', '+' . e(mask_phone($p['phone']))) . $r(Settings::payType(), e(Settings::payNumber() ?: '-')) . ($p['method'] === 'mpesa_manual' ? $r('Note', 'Confirmed by staff') : '') ?><?php endif; ?><hr>
  <?php foreach ($items as $i) echo $r((int)$i['qty'] . ' x ' . e($i['name']), money($i['qty'] * $i['unit_price'])); ?>
  <?= $r('Subtotal', money($o['subtotal'])) . ($o['delivery_fee'] > 0 ? $r('Delivery fee', money($o['delivery_fee'])) : '') . ($o['loyalty_discount'] > 0 ? $r('Loyalty discount (' . number_format((int)$o['loyalty_points']) . ' points)', '- ' . money($o['loyalty_discount'])) : '') . $r('Order total', money($o['total']), 't') ?><hr>
  <?php $pc = (float)$o['total'] > 0 ? rtrim(rtrim(number_format((float)$p['amount'] / (float)$o['total'] * 100, 1), '0'), '.') : '0'; $pcTo = (float)$o['total'] > 0 ? rtrim(rtrim(number_format($upto / (float)$o['total'] * 100, 1), '0'), '.') : '0'; ?>
  <?= $r('Paid now (' . ($p['kind'] === 'deposit' ? 'deposit' : 'balance') . ')', money($p['amount']), 't') . $r('Share of order total', $pc . '%') . $r('Paid to date', money($upto) . ' (' . $pcTo . '%)') . $r('Balance remaining', money($bal), 't') ?><hr>
  <div class="text-center">Thank you for choosing <?= e(Settings::get('restaurant_name')) ?>.</div>
</div>
<div class="text-center mt-3 no-print"><button class="btn btn-primary" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print or save as PDF</button>
  <a class="btn btn-outline-primary" href="<?= e(url('order_receipt.php?order=' . $o['id'])) ?>"><i class="bi bi-files me-1"></i>Combined receipt for this order</a>
  <a class="btn btn-outline-secondary" href="<?= e(url(Auth::isStaff() ? 'admin/order.php?id=' . $o['id'] : 'order.php?id=' . $o['id'])) ?>">Back to order</a></div>
<?php page_footer(['admin' => Auth::isStaff()]); ?>
