<?php
define('ADMIN_ONLY', true);
require __DIR__ . '/_guard.php';
$id = (int)get('id');
$i = $id ? row('SELECT * FROM menu_items WHERE id=?', [$id]) : null;
if ($id && !$i) { flash('danger', 'Dish not found.'); redirect('/admin/menu.php'); }
$cats = rows('SELECT * FROM categories ORDER BY sort_order, name');
if (!$cats) { flash('warning', 'Add a category first.'); redirect('/admin/menu.php'); }
if (is_post()) {
    csrf_check();
    $price = round((float)str_replace(',', '', post('price')));
    $d = ['category_id' => (int)post('category_id'), 'name' => mb_substr(post('name'), 0, 120), 'description' => mb_substr(post('description'), 0, 400), 'price' => $price, 'emoji' => mb_substr(post('emoji'), 0, 8),
          'is_available' => isset($_POST['is_available']) ? 1 : 0, 'offer_percent' => max(0, min(90, (int)post('offer_percent'))), 'offer_label' => mb_substr(post('offer_label'), 0, 60), 'offer_ends' => preg_match('/^\d{4}-\d{2}-\d{2}$/', post('offer_ends')) ? post('offer_ends') : null];
    $err = '';
    if ($d['name'] === '' || $price < 1) $err = 'Enter a name and a price above zero.';
    $image = $i['image'] ?? null;
    if (!$err && !empty($_FILES['image']['name']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $f = $_FILES['image'];
        $mime = $f['error'] === UPLOAD_ERR_OK ? (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']) : '';
        $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
        if (!$ext || $f['size'] > 2 * 1024 * 1024) $err = 'Upload a JPG, PNG or WebP photo under 2 MB.';
        else {
            $name = bin2hex(random_bytes(10)) . '.' . $ext;
            if (!move_uploaded_file($f['tmp_name'], PUBLIC_PATH . '/uploads/' . $name)) $err = 'Could not save the photo. Check that public/uploads is writable.';
            else { if ($image && is_file(PUBLIC_PATH . '/uploads/' . basename($image))) @unlink(PUBLIC_PATH . '/uploads/' . basename($image)); $image = $name; }
        }
    }
    if (!$err && isset($_POST['remove_image']) && $image) { @unlink(PUBLIC_PATH . '/uploads/' . basename($image)); $image = null; }
    if (!$err) {
        $d['image'] = $image;
        if ($id) {
            $changes = []; foreach ($d as $k => $v) if ($k !== 'image' && (string)($i[$k] ?? '') !== (string)$v) $changes[$k] = ['from' => $i[$k] ?? null, 'to' => $v];
            if (($i['image'] ?? null) !== $image) $changes['image'] = ['from' => $i['image'] ?? null, 'to' => $image];
            $set = implode(',', array_map(fn($k) => "$k=?", array_keys($d))); q("UPDATE menu_items SET $set WHERE id=?", [...array_values($d), $id]);
            if ($changes) Audit::log('menu.item_updated', 'Updated ' . $d['name'] . ': ' . implode(', ', array_map(fn($k, $c) => $k . ($k === 'price' || $k === 'offer_percent' ? ' ' . (float)$c['from'] . ' to ' . (float)$c['to'] : ' changed'), array_keys($changes), $changes)), 'menu_item', $id, $changes);
        } else {
            q('INSERT INTO menu_items (' . implode(',', array_keys($d)) . ') VALUES (' . implode(',', array_fill(0, count($d), '?')) . ')', array_values($d));
            Audit::log('menu.item_created', 'Added menu item ' . $d['name'] . ' at ' . money($d['price']), 'menu_item', (int)db()->lastInsertId(), ['price' => $d['price'], 'offer_percent' => $d['offer_percent']]);
        }
        flash('success', 'Dish saved.'); redirect('/admin/menu.php');
    }
    flash('danger', $err); $i = array_merge($i ?? [], $d);
}
$i = $i ?? ['category_id' => $cats[0]['id'], 'name' => '', 'description' => '', 'price' => '', 'emoji' => '', 'image' => null, 'is_available' => 1, 'offer_percent' => 0, 'offer_label' => '', 'offer_ends' => ''];
page_header($id ? 'Edit dish' : 'Add dish', ['admin' => true, 'active' => 'menu']);
?>
<form method="post" enctype="multipart/form-data" class="card" style="max-width:46rem"><div class="card-body"><?= csrf_field() ?>
 <div class="row g-3">
  <div class="col-md-8"><label class="form-label" for="n">Name</label><input class="form-control" id="n" name="name" value="<?= e($i['name']) ?>" required></div>
  <div class="col-md-4"><label class="form-label" for="c">Category</label><select class="form-select" id="c" name="category_id"><?php foreach ($cats as $c) echo '<option value="' . (int)$c['id'] . '"' . ((int)$i['category_id'] === (int)$c['id'] ? ' selected' : '') . '>' . e($c['name']) . '</option>'; ?></select></div>
  <div class="col-12"><label class="form-label" for="d">Description</label><textarea class="form-control" id="d" name="description" rows="2"><?= e($i['description']) ?></textarea></div>
  <div class="col-md-4"><label class="form-label" for="p">Price (KES)</label><input class="form-control" id="p" type="number" min="1" step="1" name="price" value="<?= e($i['price'] !== '' ? (int)$i['price'] : '') ?>" required></div>
  <div class="col-md-3"><label class="form-label" for="em">Emoji</label><input class="form-control" id="em" name="emoji" value="<?= e($i['emoji']) ?>" maxlength="8" placeholder="🍛"><div class="form-text">Shown when there is no photo.</div></div>
  <div class="col-md-5"><label class="form-label" for="im">Photo (JPG, PNG, WebP, max 2 MB)</label><input class="form-control" id="im" type="file" name="image" accept="image/jpeg,image/png,image/webp">
   <?php if (!empty($i['image'])): ?><div class="form-check mt-1"><input class="form-check-input" type="checkbox" name="remove_image" id="ri"><label class="form-check-label small" for="ri">Remove current photo</label></div><?php endif; ?></div>
 </div>
 <hr><h2 class="h6">Offer (optional)</h2>
 <div class="row g-3"><div class="col-md-3"><label class="form-label" for="op">Discount (%)</label><input class="form-control" id="op" type="number" min="0" max="90" name="offer_percent" value="<?= (int)$i['offer_percent'] ?>"></div>
  <div class="col-md-5"><label class="form-label" for="ol">Offer name</label><input class="form-control" id="ol" name="offer_label" value="<?= e($i['offer_label']) ?>" placeholder="Happy hour"></div>
  <div class="col-md-4"><label class="form-label" for="oe">Ends on</label><input class="form-control" id="oe" type="date" name="offer_ends" value="<?= e($i['offer_ends'] ?? '') ?>"><div class="form-text">Leave empty for no end date.</div></div></div>
 <div class="form-check form-switch mt-4"><input class="form-check-input" type="checkbox" role="switch" id="av" name="is_available" <?= $i['is_available'] ? 'checked' : '' ?>><label class="form-check-label" for="av">Available to order</label></div>
 <div class="d-flex gap-2 mt-4"><button class="btn btn-primary">Save dish</button><a class="btn btn-outline-secondary" href="menu.php">Cancel</a></div>
</div></form>
<?php page_footer(['admin' => true]); ?>
