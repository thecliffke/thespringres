<?php
/** "My rewards": points balance, progress towards redeeming, how it works, and the history. */
require __DIR__ . '/../app/bootstrap.php';
$u = Auth::require('customer');
if (!Loyalty::enabled()) { flash('info', 'The rewards programme is not running right now.'); redirect('/'); }
$s = Loyalty::summary((int)$u['id']); $hist = Loyalty::history((int)$u['id'], 40);
$typeLabel = ['earn' => 'Earned', 'redeem' => 'Used', 'restore' => 'Returned', 'reverse' => 'Taken back', 'adjust' => 'Adjustment'];
page_header('My rewards', ['active' => 'rewards']);
?>
<div class="row justify-content-center"><div class="col-lg-7">
<h1 class="h3 sp-display mb-3">My rewards</h1>
<div class="card reward-card mb-3"><div class="card-body p-4">
  <div class="d-flex justify-content-between align-items-end flex-wrap gap-2">
    <div><div class="small text-uppercase opacity-75">Your points</div><div class="reward-num"><?= number_format($s['balance']) ?></div></div>
    <div class="text-end"><div class="small text-uppercase opacity-75">Worth</div><div class="fs-3 fw-bold"><?= money($s['kes']) ?></div></div></div>
  <div class="progress mt-3" role="progressbar" aria-valuenow="<?= (int)$s['progress'] ?>" aria-valuemin="0" aria-valuemax="100" style="height:.9rem"><div class="progress-bar bg-warning" style="width:<?= (int)$s['progress'] ?>%"></div></div>
  <div class="small mt-2"><?= $s['unlocked'] ? '<i class="bi bi-unlock-fill me-1"></i>You can use your points at checkout.' : '<i class="bi bi-lock-fill me-1"></i>' . number_format($s['to_go']) . ' more points to unlock rewards (you need ' . number_format($s['min']) . ').' ?></div>
</div></div>
<div class="card mb-3"><div class="card-body"><h2 class="h5 sp-display">How it works</h2>
  <ul class="mb-0">
    <?php if ($s['rate'] > 0): ?><li>Earn <b><?= (int)$s['rate'] ?> point<?= $s['rate'] === 1 ? '' : 's' ?></b> for every <b>KES 100</b> you spend on food. Points are added when your order is completed.</li><?php endif; ?>
    <li>Each point takes <b><?= money($s['value']) ?></b> off your next order.</li>
    <li>Once you have <b><?= number_format($s['min']) ?> points</b> you can use them at checkout, to pay up to <b><?= (int)$s['pct'] ?>%</b> of the food bill.</li>
    <li>If you cancel an order, the points you used on it come back.</li></ul>
  <a class="btn btn-primary mt-3" href="<?= e(url('/')) ?>">Order now</a></div></div>
<div class="card"><div class="card-body"><h2 class="h5 sp-display">History</h2>
  <?php if (!$hist): ?><p class="text-body-secondary mb-0">No activity yet. Complete an order to earn your first points.</p><?php endif; ?>
  <?php foreach ($hist as $h): ?><div class="d-flex justify-content-between align-items-center py-2 border-top small"><span><b><?= e($typeLabel[$h['type']] ?? $h['type']) ?></b><?= $h['order_no'] ? ' <a href="' . e(url('order.php?id=' . $h['order_id'])) . '">' . e($h['order_no']) . '</a>' : '' ?><span class="d-block text-body-secondary"><?= e($h['note']) ?> &middot; <?= e(fmt_dt($h['created_at'], 'j M Y, g:i A')) ?></span></span>
    <b class="<?= $h['points'] > 0 ? 'text-success' : 'text-danger' ?>"><?= $h['points'] > 0 ? '+' : '' ?><?= number_format($h['points']) ?></b></div><?php endforeach; ?></div></div>
</div></div>
<?php page_footer(); ?>
