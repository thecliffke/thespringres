<?php
require __DIR__ . '/../app/bootstrap.php';
if (Auth::user()) redirect(Auth::home());
if (!Google::enabled()) { flash('warning', 'Google sign-in is not available right now. Use your email and password.'); redirect('/login.php'); }
redirect(Google::beginUrl(get('mode') === 'signup' ? 'signup' : 'signin'));
