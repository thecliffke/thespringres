<?php
declare(strict_types=1);

class Auth {
    private static ?array $user = null;
    public static function user(): ?array {
        if (self::$user === null && !empty($_SESSION['uid'])) {
            self::$user = row('SELECT id,name,email,phone,role,is_active,google_id,password_set FROM users WHERE id=?', [(int)$_SESSION['uid']]);
            if (!self::$user || !self::$user['is_active']) { self::$user = null; unset($_SESSION['uid']); }
        }
        return self::$user;
    }
    public static function id(): int { $u = self::user(); return $u ? (int)$u['id'] : 0; }
    public static function isStaff(): bool { $u = self::user(); return $u && in_array($u['role'], ['admin', 'waiter'], true); }
    public static function isAdmin(): bool { $u = self::user(); return $u && $u['role'] === 'admin'; }
    public static function home(?array $u = null): string {
        $u = $u ?? self::user();
        if (!$u) return '/';
        return $u['role'] === 'admin' ? '/admin/' : ($u['role'] === 'waiter' ? '/admin/orders.php' : '/');
    }
    public static function maxAttempts(): int { return max(3, min(50, (int)Settings::get('login_max_attempts'))); }
    public static function lockoutMinutes(): int { return max(1, min(1440, (int)Settings::get('login_lockout_minutes'))); }
    /** Minutes left before this IP may try again (0 = not locked). */
    public static function lockRemaining(string $ip): int {
        $mins = self::lockoutMinutes(); $max = self::maxAttempts();
        $t = array_column(rows('SELECT created_at FROM login_attempts WHERE ip=? AND created_at > (NOW() - INTERVAL ' . $mins . ' MINUTE) ORDER BY created_at ASC', [$ip]), 'created_at');
        if (count($t) < $max) return 0;
        $frees = strtotime($t[count($t) - $max]) + $mins * 60;
        return max(1, (int)ceil(($frees - time()) / 60));
    }
    /** Currently locked-out addresses (for the admin Security tab). */
    public static function lockedList(): array {
        $out = [];
        foreach (rows('SELECT ip, COUNT(*) n, MAX(created_at) last_at, GROUP_CONCAT(DISTINCT email SEPARATOR ", ") emails FROM login_attempts WHERE created_at > (NOW() - INTERVAL ' . self::lockoutMinutes() . ' MINUTE) GROUP BY ip HAVING n >= ' . self::maxAttempts() . ' ORDER BY last_at DESC') as $r) {
            $r['remaining'] = self::lockRemaining($r['ip']); $out[] = $r;
        }
        return $out;
    }
    /** Admin override: clear the lockout for one address, or for everyone when $ip is null. */
    public static function unlock(?string $ip = null): void {
        if ($ip === null) q('DELETE FROM login_attempts'); else q('DELETE FROM login_attempts WHERE ip=?', [$ip]);
        Audit::log('auth.unlocked', $ip === null ? 'Cleared every sign-in lockout' : 'Cleared the sign-in lockout for ' . $ip, 'ip', $ip ?? 'all');
    }
    /** Returns error message or null on success. */
    public static function attempt(string $email, string $pw): ?string {
        $ip = client_ip();
        q('DELETE FROM login_attempts WHERE created_at < (NOW() - INTERVAL 2 DAY)');
        if (($left = self::lockRemaining($ip)) > 0) {
            if (!val("SELECT COUNT(*) FROM audit_log WHERE action='auth.locked' AND ip=? AND created_at > (NOW() - INTERVAL 5 MINUTE)", [$ip])) Audit::log('auth.locked', 'Sign-in blocked: too many failed attempts from ' . $ip, 'ip', $ip, ['email' => strtolower($email)], []);
            return 'Too many failed attempts. Try again in ' . $left . ' minute' . ($left === 1 ? '' : 's') . ', or ask an admin to unlock your sign-in.';
        }
        $u = row('SELECT * FROM users WHERE email=?', [strtolower($email)]);
        if (!$u || !password_verify($pw, $u['password_hash'])) {
            q('INSERT INTO login_attempts (ip,email) VALUES (?,?)', [$ip, strtolower($email)]);
            Audit::log('auth.login_failed', 'Failed sign-in for ' . strtolower($email), $u ? 'user' : null, $u['id'] ?? null, ['email' => strtolower($email), 'account_exists' => (bool)$u], []);
            return 'Wrong email or password. Check your details and try again.';
        }
        if (!$u['is_active']) { Audit::log('auth.login_blocked', 'Sign-in refused: account is deactivated (' . $u['email'] . ')', 'user', $u['id'], [], []); return 'This account is deactivated. Contact the restaurant.'; }
        q('DELETE FROM login_attempts WHERE ip=?', [$ip]);
        self::start($u);
        Audit::log('auth.login', 'Signed in', 'user', $u['id'], [], $u);
        return null;
    }
    /** Starts the session for an already-verified account (password or Google). */
    public static function start(array $u): void {
        session_regenerate_id(true);
        $_SESSION['uid'] = (int)$u['id'];
        q('UPDATE users SET last_login=NOW() WHERE id=?', [$u['id']]);
        self::$user = null;
    }
    /** Where to send someone right after signing in: the page they were heading to, else their home page. */
    public static function afterLogin(): never { redirect(self::nextUrl()); }
    /** The app-relative address to open after signing in (used by redirects and by the JSON sign-in of passkeys). */
    public static function nextUrl(): string {
        $next = $_SESSION['next'] ?? ''; unset($_SESSION['next']);
        $u = self::user();
        if ($next && str_starts_with($next, '/') && !str_starts_with($next, '//') && ($u['role'] === 'customer' || str_contains($next, '/admin/'))) return $next;
        return self::home($u);
    }
    public static function logout(): void {
        $_SESSION = [];
        if (session_status() === PHP_SESSION_ACTIVE) session_regenerate_id(true);
        self::$user = null;
    }
    public static function require(string ...$roles): array {
        $u = self::user();
        if (!$u) {
            // Remember where the person was going, relative to the app (url() adds the folder prefix again, so strip it here).
            $uri = (string)($_SERVER['REQUEST_URI'] ?? '/'); $bp = base_path();
            if ($bp !== '' && str_starts_with($uri, $bp . '/')) $uri = substr($uri, strlen($bp));
            if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET' && !str_contains($uri, '/api/') && !str_starts_with($uri, '//')) $_SESSION['next'] = $uri; else unset($_SESSION['next']);
            flash('warning', 'Please sign in to continue.'); redirect('/login.php');
        }
        if ($roles && !in_array($u['role'], $roles, true)) { http_response_code(403); flash('danger', 'You do not have access to that page.'); redirect(self::home($u)); }
        return $u;
    }
}
