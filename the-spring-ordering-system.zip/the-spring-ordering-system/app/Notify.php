<?php
declare(strict_types=1);

class Notify {
    public static function user(int $uid, string $title, string $body = '', string $link = ''): void {
        q('INSERT INTO notifications (user_id,title,body,link) VALUES (?,?,?,?)', [$uid, mb_substr($title, 0, 160), mb_substr($body, 0, 400), $link]);
        Push::queue($uid, $title, $body, $link);   // also delivered to the person's phone or desktop when the app is closed
    }
    public static function admins(string $title, string $body = '', string $link = ''): void {
        foreach (rows("SELECT id FROM users WHERE role='admin' AND is_active=1") as $r) self::user((int)$r['id'], $title, $body, $link);
    }
    public static function staff(string $title, string $body = '', string $link = ''): void {
        foreach (rows("SELECT id FROM users WHERE role IN ('admin','waiter') AND is_active=1") as $r) self::user((int)$r['id'], $title, $body, $link);
    }
}
