/* Fingerprint / face / screen-lock sign-in (passkeys, WebAuthn). Works with the markup rendered by login.php, profile.php and Passkey::promptHtml(). */
(function () {
  'use strict';
  var SP = window.SP || {};
  function b64d(s) { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; var b = atob(s), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a.buffer; }
  function b64e(buf) { var a = new Uint8Array(buf), s = ''; for (var i = 0; i < a.length; i++) s += String.fromCharCode(a[i]); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function api(action, data) {
    return fetch((SP.base || '') + '/api/passkey.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-Token': SP.csrf },
      body: JSON.stringify(Object.assign({ action: action }, data || {})) })
      .then(function (r) { return r.json().catch(function () { return { ok: false, message: 'The server sent an unexpected reply. Please try again.' }; }); });
  }
  function friendly(e) {
    var n = e && e.name;
    if (n === 'NotAllowedError' || n === 'AbortError') return 'Cancelled, or the fingerprint was not recognised. Please try again.';
    if (n === 'InvalidStateError') return 'This device is already set up for fingerprint sign-in.';
    if (n === 'NotSupportedError' || n === 'SecurityError') return 'Fingerprint sign-in is not available here. It needs a secure (https) connection and a phone or computer with a screen lock.';
    return (e && e.message) || 'Something went wrong. Please try again.';
  }
  function supported() {
    if (!window.PublicKeyCredential || !navigator.credentials || !navigator.credentials.create) return Promise.resolve(false);
    if (!PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable) return Promise.resolve(false);
    return PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable().catch(function () { return false; });
  }
  function say(el, text, kind) { if (!el) return; el.textContent = text || ''; el.className = (el.className.replace(/\b(text-danger|text-success|text-body-secondary)\b/g, '') + ' ' + (kind || 'text-body-secondary')).trim(); el.classList.toggle('d-none', !text); }
  function busy(btn, on) { if (!btn) return; btn.disabled = on; btn.classList.toggle('disabled', on); }

  function register(btn, msg) {
    busy(btn, true); say(msg, 'Check your phone: confirm with your fingerprint, face or screen lock.');
    api('create_options').then(function (r) {
      if (!r.ok) throw new Error(r.message);
      var o = r.options; o.challenge = b64d(o.challenge); o.user.id = b64d(o.user.id);
      o.excludeCredentials = (o.excludeCredentials || []).map(function (c) { c.id = b64d(c.id); return c; });
      return navigator.credentials.create({ publicKey: o });
    }).then(function (cred) {
      return api('create', { credential: { id: cred.id, transports: cred.response.getTransports ? cred.response.getTransports() : [],
        response: { clientDataJSON: b64e(cred.response.clientDataJSON), attestationObject: b64e(cred.response.attestationObject) } } });
    }).then(function (r) {
      if (!r.ok) throw new Error(r.message);
      say(msg, r.message, 'text-success'); try { localStorage.setItem('sp_pk_done', '1'); } catch (e) {}
      setTimeout(function () { location.reload(); }, 700);
    }).catch(function (e) { busy(btn, false); say(msg, friendly(e), 'text-danger'); });
  }

  function login(btn, msg) {
    busy(btn, true); say(msg, 'Check your phone: confirm with your fingerprint, face or screen lock.');
    api('login_options').then(function (r) {
      if (!r.ok) throw new Error(r.message);
      var o = r.options; o.challenge = b64d(o.challenge);
      return navigator.credentials.get({ publicKey: o });
    }).then(function (cred) {
      var x = cred.response;
      return api('login', { credential: { id: cred.id, response: { clientDataJSON: b64e(x.clientDataJSON), authenticatorData: b64e(x.authenticatorData), signature: b64e(x.signature), userHandle: x.userHandle ? b64e(x.userHandle) : '' } } });
    }).then(function (r) {
      if (!r.ok) throw new Error(r.message);
      say(msg, 'Signed in. Taking you in...', 'text-success'); location.href = r.redirect || (SP.base || '') + '/';
    }).catch(function (e) { busy(btn, false); say(msg, friendly(e), 'text-danger'); });
  }

  document.addEventListener('DOMContentLoaded', function () {
    var q = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };
    var msg = document.querySelector('[data-passkey-msg]');
    q('[data-passkey-remove]').forEach(function (b) {
      b.addEventListener('click', function () {
        if (!confirm('Remove fingerprint sign-in for this device?')) return;
        busy(b, true); api('remove', { id: parseInt(b.getAttribute('data-passkey-remove'), 10) }).then(function (r) { if (r.ok) location.reload(); else { busy(b, false); say(msg, r.message, 'text-danger'); } });
      });
    });
    supported().then(function (ok) {
      q('[data-passkey-unsupported]').forEach(function (el) { el.classList.toggle('d-none', ok); });
      if (!ok) return;
      q('[data-passkey-login]').forEach(function (b) { b.classList.remove('d-none'); b.addEventListener('click', function () { login(b, msg); }); });
      q('[data-passkey-add]').forEach(function (b) { b.classList.remove('d-none'); b.addEventListener('click', function () { register(b, msg); }); });
      q('[data-passkey-prompt]').forEach(function (box) {
        var gone = false; try { gone = localStorage.getItem('sp_pk_dismiss') === '1'; } catch (e) {}
        if (gone) return; box.classList.remove('d-none');
        var d = box.querySelector('[data-passkey-dismiss]'); if (d) d.addEventListener('click', function () { try { localStorage.setItem('sp_pk_dismiss', '1'); } catch (e) {} box.classList.add('d-none'); });
        var a = box.querySelector('[data-passkey-prompt-add]'); var m = box.querySelector('[data-passkey-prompt-msg]'); if (a) a.addEventListener('click', function () { register(a, m); });
      });
    });
  });
})();
