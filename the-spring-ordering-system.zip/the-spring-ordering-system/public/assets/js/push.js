/* Push notifications: registers the service worker, asks for permission, stores the device subscription. */
(function () {
  'use strict';
  var SP = window.SP;
  if (!SP || !SP.uid || !SP.push || !SP.push.key) return;
  var supported = 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
  var ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
  var standalone = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || navigator.standalone;
  var DISMISS = 'sp_push_dismissed';

  function keyBytes(b64) {
    var s = (b64 + '='.repeat((4 - b64.length % 4) % 4)).replace(/-/g, '+').replace(/_/g, '/'), r = atob(s), a = new Uint8Array(r.length);
    for (var i = 0; i < r.length; i++) a[i] = r.charCodeAt(i);
    return a;
  }
  function api(body) {
    return fetch(SP.base + '/api/push_subscribe.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': SP.csrf, 'Accept': 'application/json' }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().catch(function () { return {}; }); });
  }
  function registration() { return navigator.serviceWorker.register(SP.base + '/sw.js').then(function () { return navigator.serviceWorker.ready; }); }
  function currentSub(reg) { return reg.pushManager.getSubscription(); }
  function subscribe(reg) {
    return currentSub(reg).then(function (s) {
      return s || reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: keyBytes(SP.push.key) });
    }).then(function (s) { return api({ action: 'subscribe', subscription: s.toJSON() }).then(function (j) { return { sub: s, res: j }; }); });
  }
  function toast(t, b) { if (SP.toast) SP.toast(t, b); }

  var P = {
    supported: supported,
    state: function () {
      if (!supported) return Promise.resolve(ios && !standalone ? 'ios-install' : 'unsupported');
      if (Notification.permission === 'denied') return Promise.resolve('denied');
      if (Notification.permission !== 'granted') return Promise.resolve(ios && !standalone ? 'ios-install' : 'off');
      return registration().then(currentSub).then(function (s) { return s ? 'on' : 'off'; }).catch(function () { return 'off'; });
    },
    enable: function () {
      if (!supported) return Promise.resolve(false);
      return Notification.requestPermission().then(function (p) {
        if (p !== 'granted') { toast('Notifications blocked', 'Allow notifications for this site in your browser settings to turn them on.'); return false; }
        return registration().then(subscribe).then(function (r) {
          if (!r.res.ok) { toast('Could not turn on notifications', r.res.message || 'Please try again.'); return false; }
          toast('Notifications are on', 'You will get order updates and reminders on this device, even when the app is closed.'); return true;
        });
      }).catch(function (e) { toast('Could not turn on notifications', (e && e.message) || 'Your browser refused the request.'); return false; });
    },
    disable: function () {
      return registration().then(currentSub).then(function (s) {
        if (!s) return true;
        var ep = s.endpoint; return s.unsubscribe().then(function () { return api({ action: 'unsubscribe', endpoint: ep }); });
      }).then(function () { toast('Notifications are off on this device'); return true; });
    },
    test: function () { return api({ action: 'test' }).then(function (j) { toast(j.ok ? 'Test sent' : 'Test failed', j.message || ''); return j; }); }
  };
  window.SPPush = P;

  /* keep this device's subscription attached to whoever is signed in */
  if (supported) {
    registration().then(function (reg) {
      if (Notification.permission === 'granted') return subscribe(reg);
    }).catch(function () {});
  }

  /* on sign-out, tell the server which device to forget so alerts stop on a shared phone */
  document.addEventListener('submit', function (e) {
    var f = e.target;
    var act = f && f.getAttribute ? f.getAttribute('action') : ''; /* getAttribute: a control named "action" would shadow form.action */
    if (!supported || !f || !act || act.indexOf('logout.php') < 0 || f.dataset.pushDone) return;
    e.preventDefault();
    var go = function () { f.dataset.pushDone = '1'; f.submit(); };
    var forget = navigator.serviceWorker.getRegistration(SP.base + '/sw.js').then(function (r) { return r ? r.pushManager.getSubscription() : null; })
      .then(function (s) { return s ? api({ action: 'unsubscribe', endpoint: s.endpoint }) : null; });
    Promise.race([forget, new Promise(function (r) { setTimeout(r, 1500); })]).then(go, go);
  });

  /* prompt banner */
  function banner(state) {
    if (document.getElementById('push-banner')) return;
    var main = document.getElementById('main'); if (!main) return;
    var d = document.createElement('div'); d.id = 'push-banner'; d.className = 'alert alert-info d-flex flex-wrap align-items-center gap-2 push-banner'; d.setAttribute('role', 'region');
    var msg = document.createElement('div'); msg.className = 'flex-grow-1';
    if (state === 'ios-install') {
      msg.innerHTML = '<i class="bi bi-bell me-1"></i><b>Get order alerts on your iPhone.</b> Tap <b>Share</b>, then <b>Add to Home Screen</b>, and open the app from your home screen to turn on notifications.';
    } else {
      msg.innerHTML = SP.role === 'customer'
        ? '<i class="bi bi-bell me-1"></i><b>Never miss an update.</b> Turn on notifications to hear when your order is ready, and to get your order reminders, even when the app is closed.'
        : '<i class="bi bi-bell me-1"></i><b>Never miss an order.</b> Turn on notifications to hear about new orders, payments and refunds that need attention, even when the app is closed.';
    }
    d.appendChild(msg);
    if (state === 'off') {
      var on = document.createElement('button'); on.className = 'btn btn-primary btn-sm'; on.textContent = 'Turn on';
      on.onclick = function () { on.disabled = true; P.enable().then(function (ok) { if (ok) d.remove(); else on.disabled = false; }); };
      d.appendChild(on);
    }
    var no = document.createElement('button'); no.className = 'btn btn-outline-secondary btn-sm'; no.textContent = 'Not now';
    no.onclick = function () { try { localStorage.setItem(DISMISS, String(Date.now())); } catch (e) {} d.remove(); };
    d.appendChild(no);
    main.insertBefore(d, main.firstChild);
  }
  function dismissedRecently() { try { return Date.now() - Number(localStorage.getItem(DISMISS) || 0) < 7 * 864e5; } catch (e) { return false; } }

  /* control panel on the notifications page */
  function panel(state) {
    var el = document.getElementById('push-panel'); if (!el) return;
    var h = '';
    if (state === 'on') h = '<span class="badge text-bg-success me-2">On for this device</span><button class="btn btn-outline-primary btn-sm me-1" data-push="test">Send a test</button><button class="btn btn-outline-secondary btn-sm" data-push="off">Turn off</button>';
    else if (state === 'off') h = '<span class="badge text-bg-secondary me-2">Off</span><button class="btn btn-primary btn-sm" data-push="on">Turn on notifications</button>';
    else if (state === 'denied') h = '<span class="badge text-bg-danger me-2">Blocked</span><span class="small">Notifications are blocked for this site. Allow them in your browser or phone settings, then reload.</span>';
    else if (state === 'ios-install') h = '<span class="small">On iPhone: tap <b>Share</b>, then <b>Add to Home Screen</b>, open the app from your home screen, then come back here to turn notifications on.</span>';
    else h = '<span class="small text-body-secondary">This browser does not support push notifications.</span>';
    el.innerHTML = h;
    el.onclick = function (e) {
      var b = e.target.closest('[data-push]'); if (!b) return;
      b.disabled = true;
      var a = b.dataset.push, run = a === 'on' ? P.enable() : a === 'off' ? P.disable() : P.test();
      run.then(function () { P.state().then(panel); });
    };
  }

  P.state().then(function (s) {
    panel(s);
    if ((s === 'off' || s === 'ios-install') && !dismissedRecently() && !document.getElementById('push-panel')) banner(s);
  });
})();
