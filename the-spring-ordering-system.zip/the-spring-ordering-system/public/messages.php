<?php
require __DIR__ . '/../app/bootstrap.php';
$u = Auth::require('customer');
if (is_post()) {
    csrf_check();
    $oid = (int)post('order_id') ?: null;
    $r = Messages::start($u, (int)$u['id'], post('subject'), post('body'), $oid);
    if ($r['ok']) { flash('success', 'Message sent. We will reply here.'); redirect('/thread.php?id=' . $r['id']); }
    flash('danger', $r['message']);
}
$threads = rows('SELECT t.*, o.order_no, (SELECT body FROM messages m WHERE m.thread_id=t.id ORDER BY m.id DESC LIMIT 1) last_body FROM message_threads t LEFT JOIN orders o ON o.id=t.order_id WHERE t.customer_id=? ORDER BY t.last_message_at DESC LIMIT 100', [$u['id']]);
$orders = rows('SELECT id, order_no, created_at FROM orders WHERE customer_id=? ORDER BY id DESC LIMIT 15', [$u['id']]);
$preOrder = (int)get('order'); $showNew = get('new') === '1' || !$threads;
page_header('Messages', ['active' => 'messages']);
?>
<div class="d-flex justify-content-between align-items-center mb-3"><h1 class="h3 sp-display mb-0">Messages</h1>
  <?php if (!$showNew): ?><a class="btn btn-primary btn-sm" href="?new=1"><i class="bi bi-pencil-square me-1"></i>New message</a><?php endif; ?></div>
<?php if ($showNew): ?>
<div class="card mb-4" id="new"><div class="card-body"><h2 class="h5 sp-display">Message the restaurant</h2>
  <p class="small text-body-secondary">Ask about an order, a payment or anything else. We reply here, and you will get a notification.</p>
  <form method="post"><?= csrf_field() ?>
    <div class="row g-2"><div class="col-md-7"><label class="form-label small mb-1" for="sub">Subject (optional)</label><input class="form-control" id="sub" name="subject" maxlength="160" placeholder="e.g. Paid but order not showing"></div>
    <div class="col-md-5"><label class="form-label small mb-1" for="ord">About an order?</label><select class="form-select" id="ord" name="order_id"><option value="">No, a general question</option><?php foreach ($orders as $o) echo '<option value="' . (int)$o['id'] . '"' . ($preOrder === (int)$o['id'] ? ' selected' : '') . '>' . e($o['order_no']) . ' (' . e(fmt_dt($o['created_at'], 'j M')) . ')</option>'; ?></select></div></div>
    <label class="form-label small mt-2 mb-1" for="body">Your message</label><textarea class="form-control" id="body" name="body" rows="4" maxlength="<?= Messages::MAX_LEN ?>" required <?= $showNew && get('new') === '1' ? 'autofocus' : '' ?> placeholder="If you paid but see an error, include the M-Pesa code from your SMS."></textarea>
    <button class="btn btn-primary mt-3"><i class="bi bi-send me-1"></i>Send message</button></form></div></div>
<?php endif; ?>
<?php if ($threads): ?><div class="card"><div class="list-group list-group-flush">
<?php foreach ($threads as $t): ?>
  <a class="list-group-item list-group-item-action d-flex gap-3 align-items-start <?= $t['customer_unread'] ? 'fw-semibold' : '' ?>" href="<?= e(url('thread.php?id=' . $t['id'])) ?>">
    <span class="mt-2 rounded-circle" style="width:10px;height:10px;flex:none;background:<?= $t['customer_unread'] ? 'var(--sp-yellow)' : 'transparent' ?>"></span>
    <span class="flex-grow-1 text-truncate"><?= e($t['subject']) ?> <?= $t['status'] === 'closed' ? '<span class="badge text-bg-secondary">Closed</span>' : '' ?><?= $t['order_no'] ? ' <span class="badge text-bg-light border">' . e($t['order_no']) . '</span>' : '' ?>
      <br><span class="fw-normal small text-body-secondary"><?= $t['last_sender'] === 'customer' ? 'You: ' : '' ?><?= e(mb_substr((string)$t['last_body'], 0, 90)) ?></span></span>
    <small class="text-body-secondary text-nowrap"><?= e(fmt_dt($t['last_message_at'], 'j M, g:i A')) ?></small></a>
<?php endforeach; ?></div></div><?php endif; ?>
<?php page_footer(); ?>
