<?php
declare(strict_types=1);

/**
 * Safaricom Daraja: M-Pesa Express (STK Push) for Paybill.
 * Credentials are entered in Admin > Settings > M-Pesa. Environments:
 *   simulate   - no network calls; payments auto-succeed after a few seconds (for testing the app)
 *   sandbox    - https://sandbox.safaricom.co.ke
 *   production - https://api.safaricom.co.ke
 */
class Mpesa {
    public static function env(): string { $e = Settings::get('mpesa_env'); return in_array($e, ['sandbox', 'production'], true) ? $e : 'simulate'; }
    public static function base(): string { if ($o = cfg('mpesa_base_url')) return rtrim((string)$o, '/'); return self::env() === 'production' ? 'https://api.safaricom.co.ke' : 'https://sandbox.safaricom.co.ke'; }
    public static function configured(): bool {
        return Settings::has('mpesa_consumer_key') && Settings::has('mpesa_consumer_secret') && Settings::has('mpesa_shortcode') && Settings::has('mpesa_passkey');
    }
    public static function callbackUrl(): string {
        $custom = trim(Settings::get('mpesa_callback_url'));
        $base = $custom !== '' ? $custom : abs_url('api/mpesa_callback.php');
        return $base . (str_contains($base, '?') ? '&' : '?') . 'token=' . Settings::callbackToken();
    }

    /** $fresh = ignore the saved token and ask Safaricom for a new one. */
    public static function token(bool $fresh = false): string {
        $file = ROOT . '/storage/mpesa_token_' . self::env() . '.json';
        if ($fresh) @unlink($file);
        if (is_file($file)) { $c = json_decode((string)file_get_contents($file), true); if (($c['exp'] ?? 0) > time() + 30 && ($c['key'] ?? '') === md5(Settings::get('mpesa_consumer_key'))) return $c['token']; }
        $auth = base64_encode(Settings::get('mpesa_consumer_key') . ':' . Settings::get('mpesa_consumer_secret'));
        $r = http_request('GET', self::base() . '/oauth/v1/generate?grant_type=client_credentials', ['Authorization: Basic ' . $auth, 'Accept: application/json']);
        $j = json_decode($r['body'], true);
        if (empty($j['access_token'])) throw new RuntimeException('Could not get an M-Pesa access token. Check the consumer key and secret and the environment. (' . ($r['error'] ?: 'HTTP ' . $r['code']) . ')');
        @file_put_contents($file, json_encode(['token' => $j['access_token'], 'exp' => time() + (int)($j['expires_in'] ?? 3500), 'key' => md5(Settings::get('mpesa_consumer_key'))]));
        return $j['access_token'];
    }
    public static function testConnection(): array {
        if (self::env() === 'simulate') return ['ok' => true, 'message' => 'Simulation mode is on. No Safaricom connection is used.'];
        if (!self::configured()) return ['ok' => false, 'message' => 'Fill in the consumer key, consumer secret, Paybill number and passkey first.'];
        @unlink(ROOT . '/storage/mpesa_token_' . self::env() . '.json');
        try { self::token(); return ['ok' => true, 'message' => 'Connected to Daraja (' . self::env() . '). Credentials look valid.']; }
        catch (Throwable $e) { return ['ok' => false, 'message' => $e->getMessage()]; }
    }

    /** Daraja answers 404.001.03 "Invalid Access Token" for an expired or revoked token, and also when the app is not allowed to use that API. */
    public static function isTokenError($j): bool {
        return is_array($j) && (($j['errorCode'] ?? '') === '404.001.03' || stripos((string)($j['errorMessage'] ?? ''), 'invalid access token') !== false);
    }
    private static function post(string $path, array $payload): array {
        for ($fresh = false; ; $fresh = true) {
            $r = http_request('POST', self::base() . $path, ['Authorization: Bearer ' . self::token($fresh), 'Content-Type: application/json'], json_encode($payload));
            $j = json_decode($r['body'], true);
            if (!$fresh && self::isTokenError($j)) continue;   // the saved token was stale: get a brand-new one and try once more
            break;
        }
        return is_array($j) ? $j : ['errorMessage' => $r['error'] ?: 'Unexpected response from Safaricom (HTTP ' . $r['code'] . ').'];
    }
    private static function password(string $ts): string { return base64_encode(Settings::get('mpesa_shortcode') . Settings::get('mpesa_passkey') . $ts); }

    /** Start an STK push for an order. Returns ['ok','message','request_id']. */
    /** $requested = amount the customer chose. Deposits: anywhere from the minimum deposit up to the full order total. Balances: up to the balance. */
    public static function initiate(int $orderId, string $kind, string $phone, ?int $userId, bool $byStaff, ?float $requested = null): array {
        $o = Orders::find($orderId);
        if (!$o) return ['ok' => false, 'message' => 'Order not found.'];
        $ph = norm_phone($phone);
        if (!$ph) return ['ok' => false, 'message' => 'Enter a valid Safaricom number, for example 0712 345 678.'];
        $recovered = false;
        if (self::env() !== 'simulate' && self::configured()) {   // before charging again, find out whether an earlier attempt actually went through
            try { if (self::reconcileOrder($orderId)) { $o = Orders::find($orderId); $recovered = true; } } catch (Throwable $e) { error_log('reconcile: ' . $e->getMessage()); }
        }
        $owed = max(0.0, (float)$o['total'] - (float)$o['amount_paid']);
        if ($kind === 'deposit') {
            if ($o['status'] !== 'awaiting_deposit') return ['ok' => false, 'message' => $recovered ? 'Good news: your earlier payment did go through, so the deposit is already paid. You have not been charged twice.' : 'The deposit for this order is already paid.'];
            $min = ceil(max(0.0, (float)$o['deposit_due'] - (float)$o['amount_paid']));
            $amount = $requested === null ? $min : (float)ceil($requested);
            if ($amount < $min) return ['ok' => false, 'message' => 'The deposit must be at least ' . money($min) . ' (' . (int)$o['deposit_pct'] . '% of the order).'];
            if ($amount > ceil($owed)) return ['ok' => false, 'message' => 'That is more than the order total. The most you can pay is ' . money(ceil($owed)) . '.'];
        } elseif ($kind === 'balance') {
            if (in_array($o['status'], ['awaiting_deposit', 'cancelled'], true)) return ['ok' => false, 'message' => 'A balance cannot be requested for this order.'];
            if (!$byStaff && !in_array($o['status'], ['ready', 'dispatched'], true)) return ['ok' => false, 'message' => 'You can pay the balance once your order is ready.'];
            $amount = $requested === null ? Orders::balance($o) : (float)ceil($requested);
            if ($amount > ceil(Orders::balance($o))) return ['ok' => false, 'message' => 'That is more than the balance of ' . money(Orders::balance($o)) . '.'];
        } else return ['ok' => false, 'message' => 'Unknown payment type.'];
        $amount = (float)ceil($amount);
        if ($amount < 1) return ['ok' => false, 'message' => 'Nothing is due on this order.'];

        $dup = row("SELECT id FROM mpesa_requests WHERE order_id=? AND kind=? AND phone=? AND amount=? AND status='pending' AND created_at > (NOW() - INTERVAL 90 SECOND) ORDER BY id DESC LIMIT 1", [$orderId, $kind, $ph, $amount]);
        if ($dup) return ['ok' => true, 'message' => 'A payment request was already sent. Check your phone.', 'request_id' => (int)$dup['id']];

        $ref = $o['order_no'];
        if (self::env() === 'simulate') {
            $id = exec_id('INSERT INTO mpesa_requests (order_id,kind,phone,amount,account_ref,merchant_request_id,checkout_request_id,status,requested_by) VALUES (?,?,?,?,?,?,?,?,?)',
                [$orderId, $kind, $ph, $amount, $ref, 'SIM-M' . random_int(10000, 99999), 'SIM-' . bin2hex(random_bytes(8)), 'pending', $userId]);
            Audit::log('payment.stk_requested', 'Payment request of ' . money($amount) . ' (' . $kind . ') sent to ' . mask_phone($ph) . ' for ' . $o['order_no'] . ' [simulation]', 'order', $orderId, ['kind' => $kind, 'amount' => $amount, 'mode' => 'simulate']);
            return ['ok' => true, 'message' => 'Simulated payment request sent.', 'request_id' => $id];
        }
        if (!self::configured()) return ['ok' => false, 'message' => 'M-Pesa is not set up yet. Ask the admin to add the Daraja credentials in Settings.'];
        $ts = date('YmdHis');
        try {
            $res = self::post('/mpesa/stkpush/v1/processrequest', [
                'BusinessShortCode' => (int)Settings::get('mpesa_shortcode'), 'Password' => self::password($ts), 'Timestamp' => $ts,
                'TransactionType' => Settings::get('mpesa_transaction_type') ?: 'CustomerPayBillOnline',
                'Amount' => (int)$amount, 'PartyA' => (int)$ph, 'PartyB' => (int)(Settings::get('mpesa_party_b') ?: Settings::get('mpesa_shortcode')), 'PhoneNumber' => (int)$ph,
                'CallBackURL' => self::callbackUrl(), 'AccountReference' => substr($ref, 0, 12), 'TransactionDesc' => substr(($kind === 'deposit' ? 'Deposit ' : 'Balance ') . $ref, 0, 20),
            ]);
        } catch (Throwable $e) { return ['ok' => false, 'message' => $e->getMessage()]; }
        if ((string)($res['ResponseCode'] ?? '') !== '0') {
            $why = (string)($res['errorMessage'] ?? $res['ResponseDescription'] ?? 'Safaricom rejected the request.');
            exec_id('INSERT INTO mpesa_requests (order_id,kind,phone,amount,account_ref,status,result_desc,requested_by) VALUES (?,?,?,?,?,?,?,?)', [$orderId, $kind, $ph, $amount, $ref, 'failed', mb_substr($why, 0, 250), $userId]);
            Audit::log('payment.stk_rejected', 'Safaricom rejected the payment request for ' . $o['order_no'] . ': ' . mb_substr($why, 0, 120), 'order', $orderId, ['kind' => $kind, 'amount' => $amount]);
            return ['ok' => false, 'message' => 'Could not start the payment: ' . $why];
        }
        $id = exec_id('INSERT INTO mpesa_requests (order_id,kind,phone,amount,account_ref,merchant_request_id,checkout_request_id,status,requested_by) VALUES (?,?,?,?,?,?,?,?,?)',
            [$orderId, $kind, $ph, $amount, $ref, $res['MerchantRequestID'] ?? null, $res['CheckoutRequestID'] ?? null, 'pending', $userId]);
        Audit::log('payment.stk_requested', 'Payment request of ' . money($amount) . ' (' . $kind . ') sent to ' . mask_phone($ph) . ' for ' . $o['order_no'], 'order', $orderId, ['kind' => $kind, 'amount' => $amount, 'mode' => self::env()]);
        return ['ok' => true, 'message' => 'Payment request sent. Enter your M-Pesa PIN on your phone.', 'request_id' => $id];
    }

    /** Apply a result (from callback, status query or simulator). Safe to call more than once. */
    public static function applyResult(int $reqId, int $code, string $desc, array $meta = [], string $raw = ''): void {
        db()->beginTransaction();
        try {
            $r = row('SELECT * FROM mpesa_requests WHERE id=? FOR UPDATE', [$reqId]);
            if (!$r) { db()->rollBack(); return; }
            $receipt = $meta['receipt'] ?? null;
            if ($code === 0) {
                if ($r['status'] === 'success') {
                    // Already recorded (maybe via status query); fill in the real receipt number when the callback arrives.
                    if ($receipt) {
                        q('UPDATE mpesa_requests SET mpesa_receipt=?, raw_callback=COALESCE(NULLIF(?,\'\'),raw_callback) WHERE id=?', [$receipt, $raw, $reqId]);
                        q('UPDATE payments SET mpesa_receipt=? WHERE mpesa_request_id=? AND mpesa_receipt IS NULL', [$receipt, $reqId]);
                    }
                    db()->commit(); return;
                }
                $amount = isset($meta['amount']) ? (float)$meta['amount'] : (float)$r['amount'];
                $phone = !empty($meta['phone']) ? (string)$meta['phone'] : $r['phone'];
                Orders::recordPayment((int)$r['order_id'], $r['kind'], $amount, $phone, $receipt, $reqId);
                q("UPDATE mpesa_requests SET status='success', result_code=0, result_desc=?, mpesa_receipt=?, raw_callback=? WHERE id=?", [mb_substr($desc, 0, 250), $receipt, $raw ?: null, $reqId]);
            } elseif ($r['status'] === 'pending') {
                $st = $code === 1032 ? 'cancelled' : ($code === 1037 ? 'timeout' : 'failed');
                q('UPDATE mpesa_requests SET status=?, result_code=?, result_desc=?, raw_callback=? WHERE id=?', [$st, $code, mb_substr($desc, 0, 250), $raw ?: null, $reqId]);
                Audit::log('payment.not_completed', 'Payment of ' . money($r['amount']) . ' for ' . self::orderNo((int)$r['order_id']) . ' was ' . $st . ': ' . mb_substr($desc, 0, 100), 'order', $r['order_id'], ['request_id' => $reqId, 'status' => $st, 'code' => $code], []);
            }
            db()->commit();
        } catch (Throwable $e) { if (db()->inTransaction()) db()->rollBack(); throw $e; }
        // success follow-ups for a late success after timeout are handled by the same path above
    }

    public static function handleCallback(array $json): void {
        $cb = $json['Body']['stkCallback'] ?? null;
        if (!$cb || empty($cb['CheckoutRequestID'])) return;
        $r = row('SELECT id FROM mpesa_requests WHERE checkout_request_id=?', [(string)$cb['CheckoutRequestID']]);
        if (!$r) return;
        $meta = [];
        foreach ($cb['CallbackMetadata']['Item'] ?? [] as $it) {
            $n = $it['Name'] ?? '';
            if ($n === 'Amount') $meta['amount'] = $it['Value'];
            elseif ($n === 'MpesaReceiptNumber') $meta['receipt'] = (string)$it['Value'];
            elseif ($n === 'PhoneNumber') $meta['phone'] = (string)$it['Value'];
        }
        self::applyResult((int)$r['id'], (int)($cb['ResultCode'] ?? 1), (string)($cb['ResultDesc'] ?? ''), $meta, json_encode($json));
    }

    /** Called by the browser while it waits. Reconciles with Safaricom if the callback has not arrived. */
    public static function poll(int $reqId): array {
        $r = row('SELECT * FROM mpesa_requests WHERE id=?', [$reqId]);
        if (!$r) return [];
        if ($r['status'] === 'pending') {
            $age = time() - strtotime($r['created_at']);
            if (self::env() === 'simulate') {
                if ($age >= 4) {
                    $bad = str_ends_with($r['phone'], '0000');
                    self::applyResult($reqId, $bad ? 1 : 0, $bad ? 'Simulated: request cancelled by user' : 'The service request is processed successfully.',
                        $bad ? [] : ['receipt' => 'SIM' . strtoupper(bin2hex(random_bytes(4))), 'amount' => $r['amount'], 'phone' => $r['phone']]);
                }
            } elseif ($age >= 15 && (!$r['last_query_at'] || time() - strtotime($r['last_query_at']) >= 6)) {
                q('UPDATE mpesa_requests SET last_query_at=NOW() WHERE id=?', [$reqId]);
                try {
                    $ts = date('YmdHis');
                    $res = self::post('/mpesa/stkpushquery/v1/query', ['BusinessShortCode' => (int)Settings::get('mpesa_shortcode'), 'Password' => self::password($ts), 'Timestamp' => $ts, 'CheckoutRequestID' => $r['checkout_request_id']]);
                    if (isset($res['ResultCode'])) self::applyResult($reqId, (int)$res['ResultCode'], (string)($res['ResultDesc'] ?? ''), ['amount' => $r['amount'], 'phone' => $r['phone']], json_encode($res));
                } catch (Throwable $e) { /* try again on next poll */ }
            }
            $r = row('SELECT * FROM mpesa_requests WHERE id=?', [$reqId]);
            if ($r['status'] === 'pending' && time() - strtotime($r['created_at']) > 180) {
                q("UPDATE mpesa_requests SET status='timeout', result_desc='No response from the customer within 3 minutes' WHERE id=? AND status='pending'", [$reqId]);
                $r = row('SELECT * FROM mpesa_requests WHERE id=?', [$reqId]);
            }
        }
        return $r;
    }

    /* ---------- reversal support (refunds) ---------- */
    private static function orderNo(int $id): string { return (string)val('SELECT order_no FROM orders WHERE id=?', [$id]); }
    public static function certPath(): string { return ROOT . '/storage/mpesa_cert_' . (self::env() === 'production' ? 'production' : 'sandbox') . '.pem'; }
    public static function hasCert(?string $env = null): bool { return is_file(ROOT . '/storage/mpesa_cert_' . ($env ?: (self::env() === 'production' ? 'production' : 'sandbox')) . '.pem'); }
    /** Saves the Safaricom public certificate (.cer DER or PEM) for an environment. Returns an error message or null. */
    public static function saveCertificate(string $tmpFile, string $env): ?string {
        $raw = (string)file_get_contents($tmpFile);
        if ($raw === '' || strlen($raw) > 20000) return 'That does not look like a certificate file.';
        $pem = str_contains($raw, 'BEGIN CERTIFICATE') ? $raw : "-----BEGIN CERTIFICATE-----\n" . chunk_split(base64_encode($raw), 64, "\n") . "-----END CERTIFICATE-----\n";
        if (!openssl_pkey_get_public($pem)) return 'Could not read the certificate. Upload the .cer file downloaded from the Daraja portal.';
        file_put_contents(ROOT . '/storage/mpesa_cert_' . ($env === 'production' ? 'production' : 'sandbox') . '.pem', $pem);
        return null;
    }
    /** Initiator password encrypted with Safaricom's public certificate (RSA, PKCS#1 v1.5), base64. */
    public static function securityCredential(): string {
        $pub = openssl_pkey_get_public((string)@file_get_contents(self::certPath()));
        if (!$pub || !openssl_public_encrypt(Settings::get('mpesa_initiator_pass'), $enc, $pub, OPENSSL_PKCS1_PADDING)) throw new RuntimeException('Could not build the security credential. Upload the Safaricom certificate in Settings, M-Pesa.');
        return base64_encode($enc);
    }
    public static function reversalReady(): bool { return Settings::has('mpesa_initiator') && Settings::has('mpesa_initiator_pass') && self::hasCert(); }
    public static function resultUrl(string $name): string { return abs_url('api/' . $name . '.php') . '?token=' . Settings::callbackToken(); }
    /** Sends a Transaction Reversal request. Returns Daraja's JSON as an array. */
    public static function reverse(string $originalReceipt, float $amount, string $remarks): array {
        $receiver = Settings::get('mpesa_reversal_receiver') ?: Settings::payNumber();
        return self::post('/mpesa/reversal/v1/request', [
            'Initiator' => Settings::get('mpesa_initiator'), 'SecurityCredential' => self::securityCredential(), 'CommandID' => 'TransactionReversal',
            'TransactionID' => $originalReceipt, 'Amount' => (int)ceil($amount), 'ReceiverParty' => $receiver,
            'RecieverIdentifierType' => Settings::get('mpesa_reversal_idtype') ?: '11',
            'ResultURL' => self::resultUrl('mpesa_reversal_result'), 'QueueTimeOutURL' => self::resultUrl('mpesa_reversal_timeout'),
            'Remarks' => mb_substr($remarks, 0, 100), 'Occasion' => 'Deposit refund',
        ]);
    }

    /* ---------- plain-language results, recovery and manual confirmation ---------- */
    /** What to tell the customer for a Daraja result code. */
    public static function describe(?int $code, string $desc = ''): string {
        return [
            1032 => 'You cancelled the request on your phone. No money was taken.',
            1037 => 'The M-Pesa prompt did not reach your phone in time, or you replied too late. If M-Pesa already took money, do not pay again: we check with Safaricom and confirm it automatically, or you can message us the M-Pesa code.',
            1 => 'Your M-Pesa balance was too low for this payment.',
            2001 => 'The M-Pesa PIN was wrong. No money was taken.',
            1001 => 'Another M-Pesa transaction is in progress on this number. Wait a minute and try again.',
            1019 => 'The request expired. Please try again.',
            1025 => 'M-Pesa could not send the prompt to your phone. Please try again.',
            9999 => 'M-Pesa could not send the prompt to your phone. Please try again.',
        ][(int)$code] ?? ($desc !== '' ? $desc : 'The payment was not completed.');
    }
    /** Results where Safaricom is definite that no money moved. */
    const DEFINITE_FAILURE = [1, 2001, 1032];

    /** Asks Safaricom for the real outcome of an STK request. @return ?array Daraja's answer, or null while still processing */
    public static function queryStatus(array $r): ?array {
        if (empty($r['checkout_request_id']) || str_starts_with((string)$r['checkout_request_id'], 'SIM-') || self::env() === 'simulate') return null;
        $ts = date('YmdHis');
        $res = self::post('/mpesa/stkpushquery/v1/query', ['BusinessShortCode' => (int)Settings::get('mpesa_shortcode'), 'Password' => self::password($ts), 'Timestamp' => $ts, 'CheckoutRequestID' => $r['checkout_request_id']]);
        return isset($res['ResultCode']) ? $res : null;
    }
    /** Re-checks one request with Safaricom. Records the payment if it actually succeeded. @return bool true when a payment was recovered */
    public static function reconcileRequest(array $r): bool {
        q('UPDATE mpesa_requests SET last_query_at=NOW() WHERE id=?', [$r['id']]);
        $res = self::queryStatus($r);
        if (!$res) return false;
        $code = (int)$res['ResultCode'];
        if ($code === 0 && $r['status'] !== 'success') {
            self::applyResult((int)$r['id'], 0, (string)($res['ResultDesc'] ?? ''), ['amount' => $r['amount'], 'phone' => $r['phone']], json_encode($res));
            if (val('SELECT status FROM mpesa_requests WHERE id=?', [$r['id']]) === 'success') {
                Audit::log('payment.recovered', 'Payment of ' . money($r['amount']) . ' for ' . self::orderNo((int)$r['order_id']) . ' was found successful when re-checking with Safaricom after it had been marked ' . $r['status'], 'order', $r['order_id'], ['request_id' => (int)$r['id'], 'was' => $r['status']], []);
                return true;
            }
        } elseif ($code !== 0 && $r['status'] === 'pending') {
            self::applyResult((int)$r['id'], $code, (string)($res['ResultDesc'] ?? ''), [], json_encode($res));
        }
        return false;
    }
    /** Requests worth re-checking: still waiting, timed out, or failed for a reason that does not prove no money moved. */
    private static function recheckable(string $extra, array $params, int $limit): array {
        return rows("SELECT * FROM mpesa_requests WHERE checkout_request_id IS NOT NULL AND checkout_request_id NOT LIKE 'SIM-%' AND (status IN ('pending','timeout') OR (status='failed' AND (result_code IS NULL OR result_code NOT IN (1,2001,1032)))) $extra ORDER BY id DESC LIMIT " . (int)$limit, $params);
    }
    /** Before retrying a payment: did an earlier attempt for this order actually go through? */
    public static function reconcileOrder(int $orderId): bool {
        $any = false;
        foreach (self::recheckable("AND order_id=? AND created_at > (NOW() - INTERVAL 1 HOUR) AND created_at < (NOW() - INTERVAL 90 SECOND)", [$orderId], 5) as $r) $any = self::reconcileRequest($r) || $any;
        return $any;
    }
    /** Background sweep (cron and busy pages): finds money that moved after the app had already marked a payment failed. */
    public static function reconcileStale(int $limit = 15): int {
        $n = 0;
        foreach (self::recheckable("AND created_at > (NOW() - INTERVAL 2 HOUR) AND created_at < (NOW() - INTERVAL 1 MINUTE) AND (last_query_at IS NULL OR last_query_at < (NOW() - INTERVAL 5 MINUTE))", [], $limit) as $r) {
            try { if (self::reconcileRequest($r)) $n++; } catch (Throwable $e) { error_log('reconcile: ' . $e->getMessage()); }
        }
        return $n;
    }
    /**
     * Last resort for an admin: the customer's money moved (the M-Pesa statement shows the code) but the app never captured it.
     * @return array{ok:bool,message:string}
     */
    public static function confirmManually(int $orderId, ?int $requestId, string $receipt, float $amount, string $phone, int $adminId, string $note = ''): array {
        $o = Orders::find($orderId);
        if (!$o) return ['ok' => false, 'message' => 'Order not found.'];
        $code = strtoupper(trim($receipt));
        if (!preg_match('/^[A-Z0-9]{8,12}$/', $code)) return ['ok' => false, 'message' => 'That does not look like an M-Pesa code. It is 10 letters and numbers, for example QJK7ABCD12. Copy it from the M-Pesa statement or the customer\'s SMS.'];
        if ($ex = row('SELECT p.receipt_no, o.order_no FROM payments p JOIN orders o ON o.id=p.order_id WHERE p.mpesa_receipt=?', [$code])) return ['ok' => false, 'message' => 'The M-Pesa code ' . $code . ' is already recorded on receipt ' . $ex['receipt_no'] . ' (order ' . $ex['order_no'] . ').'];
        $amount = round($amount); $owed = max(0.0, (float)$o['total'] - (float)$o['amount_paid']);
        $ph = norm_phone($phone) ?: $o['phone'];
        if ($amount < 1) return ['ok' => false, 'message' => 'Enter the amount that was paid.'];
        if ($amount > $owed) return ['ok' => false, 'message' => 'That is more than the ' . money($owed) . ' still owed on this order. Enter exactly what the M-Pesa statement shows, or fix the order first.'];
        $req = null;
        if ($requestId) { $req = row('SELECT * FROM mpesa_requests WHERE id=? AND order_id=?', [$requestId, $orderId]); if (!$req) return ['ok' => false, 'message' => 'That payment request does not belong to this order.']; if ($req['status'] === 'success') return ['ok' => false, 'message' => 'That request is already confirmed.']; }
        else $req = row("SELECT * FROM mpesa_requests WHERE order_id=? AND status IN ('pending','timeout','failed','cancelled') AND created_at > (NOW() - INTERVAL 1 DAY) ORDER BY id DESC LIMIT 1", [$orderId]);
        $kind = $o['status'] === 'awaiting_deposit' ? 'deposit' : 'balance';
        $pid = Orders::recordPayment($orderId, $kind, $amount, $ph, $code, $req ? (int)$req['id'] : null, ['method' => 'mpesa_manual', 'received_by' => $adminId, 'note' => trim($note) !== '' ? trim($note) : 'Confirmed manually from the M-Pesa statement', 'by_user' => true]);
        if ($req) q("UPDATE mpesa_requests SET status='success', result_code=0, result_desc='Confirmed manually by an admin', mpesa_receipt=? WHERE id=?", [$code, $req['id']]);
        return ['ok' => true, 'message' => 'Recorded ' . money($amount) . ' (' . $code . ') as ' . ($kind === 'deposit' ? 'the deposit, and the order is now placed' : 'a balance payment') . '.', 'payment_id' => $pid];
    }
}
