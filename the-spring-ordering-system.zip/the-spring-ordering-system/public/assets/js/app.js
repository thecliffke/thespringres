(function(){
'use strict';
const SP=window.SP;
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
SP.post=async function(path,data){
  const fd=data instanceof FormData?data:new URLSearchParams(data);
  const r=await fetch(SP.base+'/'+path.replace(/^\//,''),{method:'POST',body:fd,headers:{'X-CSRF-Token':SP.csrf,'Accept':'application/json'},credentials:'same-origin'});
  let j={};try{j=await r.json()}catch(e){}
  if(!r.ok&&!j.message)j.message='Something went wrong ('+r.status+').';
  return j;
};
SP.get=async function(path){const r=await fetch(SP.base+'/'+path.replace(/^\//,''),{headers:{'Accept':'application/json'},credentials:'same-origin'});try{return await r.json()}catch(e){return {}}};
SP.toast=function(title,body,link){
  const c=$('#toasts');if(!c)return;
  const el=document.createElement('div');el.className='toast align-items-start';el.setAttribute('role','alert');
  el.innerHTML='<div class="toast-header"><strong class="me-auto"></strong><button type="button" class="btn-close" data-bs-dismiss="toast"></button></div><div class="toast-body"></div>';
  el.querySelector('strong').textContent=title;
  const b=el.querySelector('.toast-body');
  if(link){const a=document.createElement('a');a.href=SP.base+link;a.textContent=body||'Open';b.appendChild(a)}else b.textContent=body||'';
  c.appendChild(el);const t=new bootstrap.Toast(el,{delay:7000});t.show();el.addEventListener('hidden.bs.toast',()=>el.remove());
};
const money=n=>'KES '+Math.round(n).toLocaleString('en-US');

/* ---- cart ---- */
function ctlHtml(id,q){
  return q?'<div class="qty"><button type="button" data-cart="dec" data-id="'+id+'" aria-label="Remove one">&minus;</button><b>'+q+'</b><button type="button" data-cart="inc" data-id="'+id+'" aria-label="Add one">+</button></div>'
          :'<button type="button" class="btn btn-primary btn-sm" data-cart="inc" data-id="'+id+'">Add</button>';
}
document.addEventListener('click',async e=>{
  const b=e.target.closest('[data-cart]');if(!b)return;
  const id=b.dataset.id,box=b.closest('[data-qty]'),cur=box?+box.dataset.qty:0;
  const qty=b.dataset.cart==='remove'?0:Math.max(0,cur+(b.dataset.cart==='inc'?1:-1));
  b.disabled=true;
  const j=await SP.post('api/cart.php',{action:'set',id:id,qty:qty});
  b.disabled=false;
  if(!j.ok){SP.toast('Cart',j.message||'Could not update your cart.');return}
  if(b.closest('[data-reload]')){location.reload();return}
  if(box){
    const same=document.querySelectorAll('[data-qty][data-item="'+id+'"]');
    (same.length?same:[box]).forEach(x=>{x.dataset.qty=j.qty;x.innerHTML=ctlHtml(id,j.qty)});
  }
  $$('.cart-badge').forEach(x=>{x.textContent=j.count;x.classList.toggle('d-none',!j.count)});
  let bar=$('.cartbar');
  if(j.count){
    if(!bar){bar=document.createElement('a');bar.className='cartbar';bar.href=SP.base+'/checkout.php';document.body.appendChild(bar)}
    bar.innerHTML='<span>'+j.count+' item'+(j.count>1?'s':'')+' in your order</span><span class="go">View order '+money(j.total)+'</span>';
  }else if(bar)bar.remove();
});

/* ---- live menu filter ---- */
const ms=$('#menuSearch');
if(ms){ms.addEventListener('input',()=>{
  const q=ms.value.trim().toLowerCase();
  $$('.menu-item').forEach(c=>{c.classList.toggle('d-none',!!q&&!c.dataset.text.includes(q))});
  $$('.menu-cat').forEach(s=>{s.classList.toggle('d-none',!$$('.menu-item:not(.d-none)',s).length)});
})}

/* ---- notifications polling ---- */
let last=+(localStorage.getItem('sp_last_n_'+SP.uid)||0),first=true;
async function poll(){
  if(!SP.uid||document.hidden)return;
  const j=await SP.get('api/poll.php?since='+last);
  if(!j||j.unread===undefined)return;
  $$('.bell-badge').forEach(x=>{x.textContent=j.unread;x.classList.toggle('d-none',!j.unread)});
  const initial=first&&last===0;   // a brand-new browser: start from now instead of replaying old alerts
  (j.items||[]).slice(-3).forEach(n=>{if(!initial)SP.toast(n.title,n.body,n.link)});
  (j.items||[]).forEach(n=>{last=Math.max(last,n.id)});
  if(initial&&j.max)last=j.max;
  localStorage.setItem('sp_last_n_'+SP.uid,last);first=false;
}
if(SP.uid){poll();setInterval(poll,20000)}

/* ---- order page auto-refresh ---- */
const w=$('[data-order-watch]');
if(w){let st=w.dataset.status;setInterval(async()=>{
  if(document.hidden)return;
  const j=await SP.get('api/order_status.php?id='+w.dataset.orderWatch);
  if(j&&j.status&&(j.status!==st||j.paid!==w.dataset.paid))location.reload();
},10000)}

/* ---- confirm buttons ---- */
document.addEventListener('submit',e=>{const m=e.target.dataset.confirm;if(m&&!confirm(m))e.preventDefault()});
})();
