<?php
require __DIR__ . '/../app/bootstrap.php';
if (Auth::user()) redirect(Auth::home());
if (!Google::enabled()) { flash('warning', 'Google sign-in is not available right now.'); redirect('/login.php'); }
if (get('error') !== '') {   // the person closed the Google window or declined
    unset($_SESSION['google']);
    flash('warning', get('error') === 'access_denied' ? 'Google sign-in was cancelled.' : 'Google could not sign you in. Please try again.');
    redirect('/login.php');
}
$g = Google::finish(get('code'), get('state'));
if (!$g['ok']) { flash('danger', $g['message']); redirect('/login.php'); }

$u = row('SELECT * FROM users WHERE google_id=?', [$g['sub']]);
if (!$u) {
    $u = row('SELECT * FROM users WHERE email=?', [$g['email']]);
    if ($u && $u['google_id'] && $u['google_id'] !== $g['sub']) { flash('danger', 'This email is already linked to a different Google account.'); redirect('/login.php'); }
    if ($u) {   // existing email-and-password account: Google has verified the same address, so link it
        q('UPDATE users SET google_id=? WHERE id=?', [$g['sub'], $u['id']]);
        Audit::log('auth.google_linked', 'Google account linked to ' . $u['email'], 'user', $u['id'], [], $u);
    }
}
if ($u) {
    if (!$u['is_active']) { Audit::log('auth.login_blocked', 'Google sign-in refused: account is deactivated (' . $u['email'] . ')', 'user', $u['id'], [], []); flash('danger', 'This account is deactivated. Contact the restaurant.'); redirect('/login.php'); }
    Auth::start($u);
    Audit::log('auth.login', 'Signed in with Google', 'user', $u['id'], ['method' => 'google'], $u);
    Auth::afterLogin();
}
// No account yet: create it straight away (no phone number needed; it is asked for at checkout, and can be added in My profile).
try {
    $newId = exec_id("INSERT INTO users (name,email,phone,password_hash,google_id,password_set,role) VALUES (?,?,'',?,?,0,'customer')",
        [$g['name'], $g['email'], password_hash(bin2hex(random_bytes(24)), PASSWORD_DEFAULT), $g['sub']]);   // random password nobody knows; they can set one in My profile
} catch (PDOException $e) {   // a parallel request created the same account a moment ago
    $again = row('SELECT * FROM users WHERE google_id=? OR email=?', [$g['sub'], $g['email']]);
    if (!$again || !$again['is_active']) { flash('danger', 'We could not create your account. Please try again.'); redirect('/login.php'); }
    Auth::start($again); Auth::afterLogin();
}
Audit::log('auth.register', 'New customer account created with Google: ' . $g['email'], 'user', $newId, ['method' => 'google'], ['id' => $newId, 'name' => $g['name'], 'role' => 'customer']);
Auth::start(row('SELECT * FROM users WHERE id=?', [$newId]));
flash('success', 'Welcome to ' . Settings::get('restaurant_name') . '. Your account is ready.');
Auth::afterLogin();
