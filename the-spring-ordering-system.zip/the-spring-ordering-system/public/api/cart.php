<?php
require __DIR__ . '/../../app/bootstrap.php';
if (!is_post()) json_out(['ok' => false], 405);
csrf_check();
$u = Auth::user();
if ($u && $u['role'] !== 'customer') json_out(['ok' => false, 'message' => 'Staff accounts cannot place orders.']);
$id = (int)($_POST['id'] ?? 0); $qty = max(0, min(20, (int)($_POST['qty'] ?? 0)));
$item = row('SELECT * FROM menu_items WHERE id=? AND is_available=1', [$id]);
if (!$item) json_out(['ok' => false, 'message' => 'That item is not available right now.']);
if ($qty > 0) $_SESSION['cart'][$id] = $qty; else unset($_SESSION['cart'][$id]);
$total = 0.0;
$cart = $_SESSION['cart'] ?? [];
if ($cart) foreach (rows('SELECT * FROM menu_items WHERE id IN (' . implode(',', array_map('intval', array_keys($cart))) . ')') as $i) $total += Orders::priceOf($i) * $cart[$i['id']];
json_out(['ok' => true, 'qty' => $qty, 'count' => array_sum($cart), 'total' => $total]);
