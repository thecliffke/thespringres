<?php
require __DIR__ . '/../app/bootstrap.php';
$u = Auth::user();
if ($u && $u['role'] !== 'customer') { flash('info', 'Staff accounts cannot place orders. Use a customer account.'); redirect(Auth::home($u)); }
$cart = $_SESSION['cart'] ?? [];
$lines = []; $sub = 0.0;
if ($cart) {
    foreach (rows('SELECT * FROM menu_items WHERE id IN (' . implode(',', array_map('intval', array_keys($cart))) . ')') as $i) {
        if (!$i['is_available']) { unset($_SESSION['cart'][$i['id']]); continue; }
        $i['qty'] = (int)$cart[$i['id']]; $i['unit'] = Orders::priceOf($i); $lines[] = $i; $sub += $i['unit'] * $i['qty'];
    }
    $cart = $_SESSION['cart'];
}
$pct = Settings::depositPct(); $fee = (float)Settings::get('delivery_fee');
$slotMap = Orders::slotMap();
$lead = (int)Settings::get('lead_delivery');
$asapOk = Orders::isOpenNow() && strtotime(date('Y-m-d') . ' ' . Settings::get('close_time')) >= time() + $lead * 60;
$pre = $_SESSION['checkout_prefill'] ?? [];   // set by "Order this again"
$addrs = $u ? Addresses::forUser((int)$u['id']) : [];
$def = $addrs ? Addresses::defaultFor((int)$u['id']) : null;
$f = ['type' => post('type', $pre['type'] ?? 'dine_in'), 'day' => post('day', '0'), 'time' => post('time'), 'party_size' => post('party_size', $pre['party_size'] ?? '2'),
      'address' => post('address', ($pre['address'] ?? '') ?: ($def['address'] ?? '')), 'landmark' => post('landmark', !empty($pre['address']) ? ($pre['landmark'] ?? '') : ($def['landmark'] ?? '')),
      'lat' => post('lat', !empty($pre['address']) ? (string)($pre['lat'] ?? '') : (string)($def['lat'] ?? '')), 'lng' => post('lng', !empty($pre['address']) ? (string)($pre['lng'] ?? '') : (string)($def['lng'] ?? '')),
      'notes' => post('notes', $pre['notes'] ?? ''), 'phone' => post('phone', local_phone($u['phone'] ?? ''))];
$selAddr = 0; foreach ($addrs as $a) if (mb_strtolower(trim($f['address'])) === mb_strtolower($a['address'])) $selAddr = (int)$a['id'];
$loyal = $u && Loyalty::enabled(); $lbal = $loyal ? Loyalty::balance((int)$u['id']) : 0;
$maxPts = $loyal ? Loyalty::maxUsable((int)$u['id'], $sub, $lbal) : 0; $ptVal = Loyalty::pointValue();
$err = '';
if (is_post() && $cart) {
    csrf_check();
    if (!$u) { redirect('/login.php'); }
    $type = $f['type'] === 'delivery' ? 'delivery' : 'dine_in';
    $ph = norm_phone($f['phone']); $when = null; $asap = false;
    if ($f['time'] === 'asap' && $type === 'delivery' && $asapOk) { $when = date('Y-m-d H:i:s', time() + $lead * 60); $asap = true; }
    else { foreach ([0, 1] as $d) foreach ($slotMap[$type][$d] as $s) if ($s['value'] === $f['time']) $when = $s['value']; }
    if (!$when) $err = $type === 'delivery' ? 'Choose when you want your delivery.' : 'Choose the time you will arrive.';
    elseif ($type === 'delivery' && mb_strlen($f['address']) < 3) $err = 'Enter your delivery location.';
    elseif (!$ph) $err = 'Enter a valid M-Pesa phone number, for example 0712 345 678.';
    else {
        try {
            $id = Orders::create($u, ['type' => $type, 'scheduled_at' => $when, 'asap' => $asap, 'party_size' => $type === 'dine_in' ? max(1, min(30, (int)$f['party_size'])) : 0,
                'address' => mb_substr($f['address'], 0, 255), 'landmark' => mb_substr($f['landmark'], 0, 160), 'lat' => $f['lat'], 'lng' => $f['lng'],
                'use_points' => post('use_points') === '1', 'notes' => mb_substr($f['notes'], 0, 500), 'phone' => $ph], $cart);
            if ($type === 'delivery' && post('save_address') === '1') { $se = Addresses::save((int)$u['id'], post('addr_label'), $f['address'], $f['landmark'], $f['lat'], $f['lng']); if ($se) flash('warning', 'Your order is placed, but the address was not saved: ' . $se); else flash('success', 'Address saved for next time.'); }
            unset($_SESSION['cart'], $_SESSION['checkout_prefill']);
            redirect('/pay.php?order=' . $id);
        } catch (RuntimeException $e) { $err = $e->getMessage(); }
    }
}
page_header('Your order', ['active' => 'checkout']);
if (!$lines): ?>
<div class="card card-body text-center py-5"><h1 class="h4 sp-display">Your order is empty</h1><p class="text-body-secondary">Add dishes from the menu to get started.</p><div><a class="btn btn-primary" href="<?= e(url('/')) ?>">Browse the menu</a></div></div>
<?php page_footer(); exit; endif; ?>
<h1 class="h3 sp-display mb-3">Your order</h1>
<?php if ($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
<form method="post" id="checkout-form" novalidate><?= csrf_field() ?>
<div class="row g-4">
 <div class="col-lg-7">
  <div class="card mb-3"><div class="card-body" data-reload>
    <?php foreach ($lines as $l): ?>
    <div class="d-flex align-items-center justify-content-between gap-3 py-2 border-bottom">
      <div><b><?= e($l['name']) ?></b><div class="small text-body-secondary"><?= money($l['unit']) ?><?php if ($l['unit'] < $l['price']): ?> <s><?= money($l['price']) ?></s><?php endif; ?> each</div></div>
      <div class="d-flex align-items-center gap-2"><span data-qty="<?= $l['qty'] ?>"><div class="qty"><button type="button" data-cart="dec" data-id="<?= (int)$l['id'] ?>" aria-label="Remove one">&minus;</button><b><?= $l['qty'] ?></b><button type="button" data-cart="inc" data-id="<?= (int)$l['id'] ?>" aria-label="Add one">+</button></div></span><button type="button" class="btn-remove" data-cart="remove" data-id="<?= (int)$l['id'] ?>" aria-label="Remove <?= e($l['name']) ?> from your order" title="Remove"><i class="bi bi-x-lg"></i></button></div>
    </div>
    <?php endforeach; ?>
    <a class="btn btn-outline-primary btn-sm mt-3" href="<?= e(url('/')) ?>">Add more dishes</a>
  </div></div>
  <div class="card mb-3"><div class="card-body">
    <h2 class="h5 sp-display">How would you like it?</h2>
    <div class="btn-group seg-radio w-100 mb-3" role="group">
      <input type="radio" class="btn-check" name="type" id="t1" value="dine_in" <?= $f['type'] !== 'delivery' ? 'checked' : '' ?>><label class="btn btn-outline-primary" for="t1"><i class="bi bi-cup-hot me-1"></i>Eat at the restaurant</label>
      <input type="radio" class="btn-check" name="type" id="t2" value="delivery" <?= $f['type'] === 'delivery' ? 'checked' : '' ?>><label class="btn btn-outline-primary" for="t2"><i class="bi bi-bicycle me-1"></i>Delivery</label>
    </div>
    <div class="row g-3">
      <div class="col-sm-6"><label class="form-label" for="day"><span class="only-dine">Day you will come</span><span class="only-delivery d-none">Delivery day</span></label>
        <select class="form-select" id="day" name="day"><option value="0" <?= $f['day'] === '0' ? 'selected' : '' ?>>Today</option><option value="1" <?= $f['day'] === '1' ? 'selected' : '' ?>>Tomorrow</option></select></div>
      <div class="col-sm-6"><label class="form-label" for="time"><span class="only-dine">Arrival time</span><span class="only-delivery d-none">Delivery time</span></label>
        <select class="form-select" id="time" name="time" data-keep="<?= e($f['time']) ?>"></select></div>
      <div class="col-12 d-none" id="no-slots"><div class="alert alert-warning mb-0">No time slots left for this day. Pick another day.</div></div>
      <div class="col-sm-6 only-dine"><label class="form-label" for="ps">Number of people</label><select class="form-select" id="ps" name="party_size"><?php for ($i = 1; $i <= 12; $i++) echo '<option' . ((int)$f['party_size'] === $i ? ' selected' : '') . '>' . $i . '</option>'; ?></select></div>
      <?php if ($addrs): ?><div class="col-12 only-delivery d-none"><div class="form-label">Deliver to</div><div class="vstack gap-2" id="saved-addr">
        <?php foreach ($addrs as $a): ?><label class="addr-opt"><input type="radio" class="form-check-input" name="saved_addr" value="<?= (int)$a['id'] ?>" <?= $selAddr === (int)$a['id'] ? 'checked' : '' ?> data-address="<?= e($a['address']) ?>" data-landmark="<?= e($a['landmark']) ?>" data-lat="<?= e((string)$a['lat']) ?>" data-lng="<?= e((string)$a['lng']) ?>">
          <span><b><?= e($a['label']) ?></b><?= $a['lat'] !== null ? ' <i class="bi bi-geo-alt-fill text-success" title="Has a map pin"></i>' : '' ?><span class="d-block small text-body-secondary"><?= e($a['address']) ?><?= $a['landmark'] !== '' ? ', ' . e($a['landmark']) : '' ?></span></span></label><?php endforeach; ?>
        <label class="addr-opt"><input type="radio" class="form-check-input" name="saved_addr" value="0" <?= $selAddr === 0 ? 'checked' : '' ?>><span><b>Another address</b></span></label></div></div><?php endif; ?>
      <div class="col-12 only-delivery d-none"><label class="form-label" for="ad">Delivery location</label><input class="form-control" id="ad" name="address" value="<?= e($f['address']) ?>" placeholder="Street, building, house number"></div>
      <div class="col-12 only-delivery d-none"><label class="form-label" for="lm">Landmark (optional)</label><input class="form-control" id="lm" name="landmark" value="<?= e($f['landmark']) ?>" placeholder="Near the blue gate">
        <input type="hidden" name="lat" value="<?= e($f['lat']) ?>"><input type="hidden" name="lng" value="<?= e($f['lng']) ?>">
        <div class="d-flex flex-wrap align-items-center gap-2 mt-2"><button type="button" class="btn btn-outline-secondary btn-sm d-none" data-geo><i class="bi bi-geo-alt me-1"></i>Pin my current location</button>
          <span class="small" data-geo-status role="status" aria-live="polite"><?= Addresses::pin($f['lat'], $f['lng'])[0] !== null ? '<i class="bi bi-geo-alt-fill text-success me-1"></i>Map pin added' : '' ?></span><button type="button" class="btn btn-link btn-sm p-0 <?= Addresses::pin($f['lat'], $f['lng'])[0] !== null ? '' : 'd-none' ?>" data-geo-clear>Remove pin</button></div>
        <div class="form-text">A map pin helps the rider find you. It is only used for this delivery.</div></div>
      <?php if (count($addrs) < Addresses::MAX): ?><div class="col-12 only-delivery d-none" id="save-addr-row"<?= $selAddr ? ' style="display:none"' : '' ?>><div class="form-check"><input class="form-check-input" type="checkbox" name="save_address" id="sa" value="1"><label class="form-check-label" for="sa">Save this address for next time</label></div>
        <input class="form-control form-control-sm mt-2 d-none" name="addr_label" maxlength="40" placeholder="Label, for example Home or Office" id="sa-label"></div><?php endif; ?>
      <div class="col-12"><label class="form-label" for="nt">Notes for the kitchen (optional)</label><textarea class="form-control" id="nt" name="notes" rows="2" placeholder="Allergies, spice level, anything we should know"><?= e($f['notes']) ?></textarea></div>
      <div class="col-12"><label class="form-label" for="ph">M-Pesa phone number</label><input class="form-control" id="ph" name="phone" inputmode="tel" value="<?= e($f['phone']) ?>" placeholder="0712 345 678"><div class="form-text">We send the payment prompt to this number.</div></div>
    </div>
  </div></div>
 </div>
 <div class="col-lg-5"><div class="card sticky-side"><div class="card-body">
  <h2 class="h5 sp-display">Summary</h2>
  <div class="d-flex justify-content-between"><span>Food</span><span><?= money($sub) ?></span></div>
  <div class="d-flex justify-content-between d-none" id="sum-fee-row"><span>Delivery fee</span><span><?= money($fee) ?></span></div>
  <div class="d-flex justify-content-between text-success d-none" id="sum-disc-row"><span>Loyalty discount</span><span id="sum-disc"></span></div>
  <div class="d-flex justify-content-between fw-bold fs-5 border-top mt-2 pt-2 mb-3"><span>Total</span><span id="sum-total"></span></div>
  <?php if ($loyal && $u): ?><div class="points-box mb-3">
    <?php if ($maxPts > 0): ?><div class="form-check"><input class="form-check-input" type="checkbox" name="use_points" id="use-points" value="1"><label class="form-check-label" for="use-points"><i class="bi bi-star-fill text-warning me-1"></i>Use <b><?= number_format($maxPts) ?> points</b> for <b><?= money($maxPts * $ptVal) ?> off</b></label></div>
      <div class="form-text">You have <?= number_format($lbal) ?> points. Up to <?= Loyalty::maxPct() ?>% of the food bill can be paid with points.</div>
    <?php elseif ($lbal > 0): ?><div class="small"><i class="bi bi-star me-1 text-warning"></i>You have <b><?= number_format($lbal) ?></b> points. Reach <?= number_format(Loyalty::minRedeem()) ?> to start using them (<?= number_format(max(0, Loyalty::minRedeem() - $lbal)) ?> to go).</div>
    <?php else: ?><div class="small"><i class="bi bi-star me-1 text-warning"></i>Earn points on every completed order and use them as a discount.</div><?php endif; ?>
    <?php if (Loyalty::earnRate() > 0): ?><div class="small text-body-secondary mt-1">You will earn about <b id="sum-earn">0</b> points when this order is completed.</div><?php endif; ?></div><?php endif; ?>
  <div class="split mb-3"><div class="now"><span>Minimum deposit (<?= $pct ?>%)</span><span id="sum-now"></span></div><div class="later"><span id="sum-later-label">Pay after eating</span><span id="sum-later"></span></div></div>
  <?php if ($u): ?><button class="btn btn-primary btn-lg w-100">Continue to pay <span id="pay-btn-amt"></span></button>
  <?php else: ?><a class="btn btn-primary btn-lg w-100" href="<?= e(url('login.php')) ?>" onclick="return true">Sign in to place your order</a><span id="pay-btn-amt" class="d-none"></span><?php $_SESSION['next'] = '/checkout.php'; endif; ?>
  <p class="form-text mt-2 mb-0">Your order is confirmed once the deposit goes through. On the next step you can pay more than the minimum, even the full amount. The balance can be paid by M-Pesa or in cash.</p>
 </div></div></div>
</div></form>
<script type="application/json" id="slot-data"><?= json_encode(['dine_in' => $slotMap['dine_in'], 'delivery' => $slotMap['delivery'], 'asap' => $asapOk, 'fee' => $fee, 'sub' => $sub, 'pct' => $pct, 'disc' => $maxPts * $ptVal, 'earn' => Loyalty::enabled() ? Loyalty::earnRate() : 0]) ?></script>
<?php page_footer(['scripts' => ['checkout.js', 'addresses.js']]); ?>
