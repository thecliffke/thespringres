<?php
/** "Order this again": puts the dishes of a past order back in the cart (at today's prices) and opens checkout with the same delivery details. */
require __DIR__ . '/../app/bootstrap.php';
$u = Auth::require('customer');
if (!is_post()) redirect('/orders.php');
csrf_check();
$o = Orders::find((int)post('id'));
if (!$o || (int)$o['customer_id'] !== (int)$u['id']) { flash('danger', 'Order not found.'); redirect('/orders.php'); }
$added = 0; $missing = [];
foreach (Orders::items((int)$o['id']) as $i) {
    $m = $i['menu_item_id'] ? row('SELECT id FROM menu_items WHERE id=? AND is_available=1', [$i['menu_item_id']]) : null;
    if (!$m) { $missing[] = $i['name']; continue; }
    $_SESSION['cart'][(int)$m['id']] = max((int)($_SESSION['cart'][(int)$m['id']] ?? 0), min(20, (int)$i['qty']));   // never lowers what is already in the cart
    $added++;
}
if (!$added) { flash('warning', 'None of the dishes in ' . $o['order_no'] . ' are available right now.'); redirect('/order.php?id=' . $o['id']); }
$_SESSION['checkout_prefill'] = ['type' => $o['type'], 'party_size' => (string)max(1, (int)$o['party_size']), 'address' => $o['address'], 'landmark' => $o['landmark'], 'lat' => $o['lat'] !== null ? (string)$o['lat'] : '', 'lng' => $o['lng'] !== null ? (string)$o['lng'] : '', 'notes' => $o['notes']];
flash('success', 'Added the dishes from ' . $o['order_no'] . ' to your order. Check the time and details, then continue.' . ($missing ? ' Not available right now: ' . implode(', ', $missing) . '.' : ''));
redirect('/checkout.php');
