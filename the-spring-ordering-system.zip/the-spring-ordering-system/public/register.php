<?php
require __DIR__ . '/../app/bootstrap.php';
if (Auth::user()) redirect(Auth::home());
$err = '';
if (is_post()) {
    csrf_check();
    $name = post('name'); $email = strtolower(post('email')); $ph = post('phone') === '' ? '' : norm_phone(post('phone')); $pw = (string)($_POST['password'] ?? '');
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $err = 'Enter your name and a valid email.';
    elseif ($ph === null) $err = 'That phone number does not look right. Use a number like 0712 345 678, or leave it empty.';
    elseif (strlen($pw) < 6) $err = 'Use a password with at least 6 characters.';
    elseif (row('SELECT id FROM users WHERE email=?', [$email])) $err = 'An account with this email already exists. Sign in instead.';
    else {
        $newId = exec_id("INSERT INTO users (name,email,phone,password_hash,role) VALUES (?,?,?,?, 'customer')", [$name, $email, $ph, password_hash($pw, PASSWORD_DEFAULT)]);
        Audit::log('auth.register', 'New customer account created: ' . $email, 'user', $newId, ['phone' => mask_phone($ph)], ['id' => $newId, 'name' => $name, 'role' => 'customer']);
        Auth::attempt($email, $pw);
        flash('success', 'Welcome to ' . Settings::get('restaurant_name') . '. Your account is ready.');
        redirect('/');
    }
}
page_header('Create account');
?>
<div class="row justify-content-center"><div class="col-md-6 col-lg-5">
<div class="card shadow-sm"><div class="card-body p-4">
  <h1 class="h3 sp-display mb-3">Create your account</h1>
  <?php if ($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
  <?php if (Google::enabled()): ?><?= Google::button('signup') ?><p class="form-text text-center mt-2 mb-0">By continuing with Google you agree to our <a href="<?= e(url('terms.php')) ?>">Terms of Service</a> and <a href="<?= e(url('privacy.php')) ?>">Privacy Policy</a>.</p><div class="or-divider"><span>or sign up with email</span></div><?php endif; ?>
  <form method="post" novalidate><?= csrf_field() ?>
    <label class="form-label" for="n">Full name</label><input class="form-control mb-3" id="n" name="name" value="<?= e(post('name')) ?>" required autocomplete="name">
    <label class="form-label" for="e">Email</label><input class="form-control mb-3" id="e" type="email" name="email" value="<?= e(post('email')) ?>" required autocomplete="email">
    <label class="form-label" for="p">Phone number (optional)</label><input class="form-control mb-3" id="p" name="phone" inputmode="tel" value="<?= e(post('phone')) ?>" placeholder="0712 345 678" autocomplete="tel">
    <label class="form-label" for="w">Password</label><input class="form-control" id="w" type="password" name="password" minlength="6" required autocomplete="new-password"><div class="form-text mb-3">At least 6 characters.</div>
    <button class="btn btn-primary w-100 btn-lg">Create account</button>
    <p class="form-text text-center mt-2 mb-0">By creating an account you agree to our <a href="<?= e(url('terms.php')) ?>">Terms of Service</a> and <a href="<?= e(url('privacy.php')) ?>">Privacy Policy</a>.</p>
  </form>
  <p class="text-center mt-3 mb-0">Already registered? <a href="<?= e(url('login.php')) ?>">Sign in</a></p>
</div></div></div></div>
<?php page_footer(); ?>
