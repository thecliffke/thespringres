<?php
/** Safaricom posts the STK Push result here. The URL carries a secret token set in Admin > Settings > M-Pesa. */
define('NO_SESSION', true);
require __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: application/json');
$raw = file_get_contents('php://input') ?: '';
@file_put_contents(ROOT . '/storage/logs/mpesa_callback.log', '[' . date('c') . '] ' . ($_SERVER['REMOTE_ADDR'] ?? '') . ' ' . $raw . "\n", FILE_APPEND);
$token = (string)($_GET['token'] ?? '');
if ($token === '' || !hash_equals(Settings::callbackToken(), $token)) { http_response_code(403); echo json_encode(['ResultCode' => 1, 'ResultDesc' => 'Forbidden']); exit; }
$json = json_decode($raw, true);
if (is_array($json)) { try { Mpesa::handleCallback($json); } catch (Throwable $e) { error_log('mpesa callback: ' . $e->getMessage()); } }
echo json_encode(['ResultCode' => 0, 'ResultDesc' => 'Accepted']);
