<?php
define('ADMIN_ONLY', true);
require __DIR__ . '/_guard.php';
if (is_post()) {
    csrf_check();
    $uid = (int)post('user_id'); $pts = (int)post('points'); $note = mb_substr(post('note'), 0, 140);
    $cu = row("SELECT id,name FROM users WHERE id=? AND role='customer'", [$uid]);
    if (!$cu) flash('danger', 'Customer not found.');
    elseif ($pts === 0 || abs($pts) > 100000) flash('danger', 'Enter a number of points other than zero (use a minus sign to remove points).');
    elseif ($note === '') flash('danger', 'Add a short reason so the customer and the audit trail can see why.');
    elseif ($pts < 0 && Loyalty::balance($uid) + $pts < 0) flash('danger', $cu['name'] . ' only has ' . number_format(Loyalty::balance($uid)) . ' points, so you cannot remove ' . number_format(-$pts) . '.');
    else { Loyalty::adjust($uid, $pts, $note, (int)$ME['id']); flash('success', ($pts > 0 ? 'Added ' : 'Removed ') . number_format(abs($pts)) . ' points for ' . $cu['name'] . '.'); }
    redirect('/admin/loyalty.php' . (post('q') !== '' ? '?q=' . rawurlencode(post('q')) : ''));
}
$qv = get('q'); $per = 25; $pg = page_num();
$where = ["u.role='customer'"]; $p = [];
if ($qv !== '') { $where[] = '(u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)'; array_push($p, "%$qv%", "%$qv%", phone_term($qv)); }
$W = implode(' AND ', $where);
$total = (int)val("SELECT COUNT(*) FROM users u WHERE $W", $p);
$list = rows("SELECT u.id,u.name,u.email,COALESCE((SELECT SUM(points) FROM loyalty_ledger l WHERE l.user_id=u.id),0) pts,
              (SELECT COUNT(*) FROM orders o WHERE o.customer_id=u.id AND o.status='completed') done FROM users u WHERE $W ORDER BY pts DESC, u.name LIMIT $per OFFSET " . (($pg - 1) * $per), $p);
$recent = rows('SELECT l.*, u.name, o.order_no FROM loyalty_ledger l JOIN users u ON u.id=l.user_id LEFT JOIN orders o ON o.id=l.order_id ORDER BY l.id DESC LIMIT 15');
$tl = ['earn' => 'Earned', 'redeem' => 'Used', 'restore' => 'Returned', 'reverse' => 'Taken back', 'adjust' => 'Adjusted'];
page_header('Loyalty points', ['admin' => true, 'active' => 'loyalty']);
?>
<?php if (!Loyalty::enabled()): ?><div class="alert alert-warning">The loyalty programme is switched off, so nobody is earning or using points. Turn it on under <a href="<?= e(url('admin/settings.php?tab=loyalty')) ?>">Settings, Loyalty</a>. Balances below are kept.</div><?php endif; ?>
<div class="row g-3"><div class="col-xl-8">
 <form class="row g-2 mb-3" method="get"><div class="col"><input class="form-control" type="search" name="q" value="<?= e($qv) ?>" placeholder="Search customer name, email or phone"></div><div class="col-auto"><button class="btn btn-outline-primary">Search</button></div></form>
 <div class="card"><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Customer</th><th class="text-end">Completed orders</th><th class="text-end">Points</th><th>Adjust</th></tr></thead><tbody>
 <?php if (!$list) echo '<tr><td colspan="4" class="text-body-secondary text-center py-4">No customers found.</td></tr>'; foreach ($list as $c): ?>
  <tr><td><b><?= e($c['name']) ?></b><div class="small text-body-secondary"><?= e($c['email']) ?></div></td><td class="text-end"><?= (int)$c['done'] ?></td>
   <td class="text-end fw-bold"><?= number_format((int)$c['pts']) ?><div class="small fw-normal text-body-secondary"><?= money(max(0, (int)$c['pts']) * Loyalty::pointValue()) ?></div></td>
   <td><form method="post" class="d-flex flex-wrap gap-1"><?= csrf_field() ?><input type="hidden" name="user_id" value="<?= (int)$c['id'] ?>"><input type="hidden" name="q" value="<?= e($qv) ?>">
     <input class="form-control form-control-sm" style="width:5.5rem" type="number" name="points" placeholder="+/- pts" required><input class="form-control form-control-sm" style="width:9rem" name="note" maxlength="140" placeholder="Reason" required><button class="btn btn-outline-primary btn-sm">Apply</button></form></td></tr>
 <?php endforeach; ?></tbody></table></div></div>
 <div class="mt-3"><?= pager($total, $pg, $per) ?></div></div>
<div class="col-xl-4"><div class="card"><div class="card-body"><h2 class="h5 sp-display">Latest activity</h2>
 <?php if (!$recent) echo '<p class="text-body-secondary mb-0">Nothing yet.</p>'; foreach ($recent as $h): ?>
  <div class="d-flex justify-content-between gap-2 py-2 border-top small"><span><b><?= e($h['name']) ?></b><span class="d-block text-body-secondary"><?= e($tl[$h['type']] ?? $h['type']) ?><?= $h['order_no'] ? ', ' . e($h['order_no']) : '' ?> &middot; <?= e(fmt_dt($h['created_at'], 'j M, g:i A')) ?></span></span>
   <b class="<?= $h['points'] > 0 ? 'text-success' : 'text-danger' ?>"><?= $h['points'] > 0 ? '+' : '' ?><?= number_format($h['points']) ?></b></div><?php endforeach; ?></div></div></div></div>
<?php page_footer(['admin' => true]); ?>
