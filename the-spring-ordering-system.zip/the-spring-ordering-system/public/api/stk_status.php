<?php
require __DIR__ . '/../../app/bootstrap.php';
$u = Auth::user();
if (!$u) json_out(['status' => 'error', 'message' => 'Please sign in again.'], 401);
$r = row('SELECT mr.*, o.customer_id FROM mpesa_requests mr JOIN orders o ON o.id=mr.order_id WHERE mr.id=?', [(int)($_GET['id'] ?? 0)]);
if (!$r || (!Auth::isStaff() && (int)$r['customer_id'] !== (int)$u['id'])) json_out(['status' => 'error', 'message' => 'Not found.'], 404);
try { $r = Mpesa::poll((int)$r['id']) ?: $r; } catch (Throwable $e) { error_log($e->getMessage()); }
$msg = in_array($r['status'], ['cancelled', 'timeout', 'failed'], true) ? ($r['result_code'] !== null ? Mpesa::describe((int)$r['result_code'], (string)$r['result_desc']) : ($r['status'] === 'timeout' ? Mpesa::describe(1037) : ((string)$r['result_desc'] ?: 'The payment was not completed.'))) : '';
json_out(['status' => $r['status'], 'receipt' => $r['mpesa_receipt'], 'message' => $msg]);
