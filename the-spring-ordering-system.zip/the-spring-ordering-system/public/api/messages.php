<?php
require __DIR__ . '/../../app/bootstrap.php';
$u = Auth::user();
if (!$u) json_out(['ok' => false], 401);
$t = Messages::thread((int)($_GET['thread'] ?? 0));
$asAdmin = $u['role'] === 'admin';
if (!$t || (!$asAdmin && !($u['role'] === 'customer' && (int)$t['customer_id'] === (int)$u['id']))) json_out(['ok' => false], 404);
session_write_close();
$new = Messages::after((int)$t['id'], (int)($_GET['after'] ?? 0));
if ($new) Messages::markRead((int)$t['id'], $asAdmin);
$out = [];
foreach ($new as $m) {
    $mine = $asAdmin ? $m['sender_role'] === 'admin' : $m['sender_role'] === 'customer';
    $out[] = ['id' => (int)$m['id'], 'mine' => $mine, 'name' => $mine ? 'You' : Messages::senderName($m, $t), 'body' => $m['body'], 'time' => fmt_dt($m['created_at'], 'j M, g:i A')];
}
json_out(['ok' => true, 'messages' => $out, 'status' => $t['status']]);
