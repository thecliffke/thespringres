<?php
define('ADMIN_ONLY', true);
require __DIR__ . '/_guard.php';
$qv = get('q'); $st = get('status'); $per = 30; $pg = page_num();
$where = ['1=1']; $p = [];
if ($qv !== '') { $where[] = '(phone LIKE ? OR message LIKE ? OR event LIKE ? OR provider_status LIKE ?)'; array_push($p, phone_term($qv), "%$qv%", "%$qv%", "%$qv%"); }
if (in_array($st, ['sent', 'failed', 'skipped'], true)) { $where[] = 'status=?'; $p[] = $st; }
$W = implode(' AND ', $where);
$total = (int)val("SELECT COUNT(*) FROM sms_log WHERE $W", $p);
$list = rows("SELECT * FROM sms_log WHERE $W ORDER BY id DESC LIMIT $per OFFSET " . (($pg - 1) * $per), $p);
page_header('SMS log', ['admin' => true, 'active' => 'sms']);
?>
<form class="row g-2 mb-3" method="get"><div class="col-12 col-md"><input class="form-control" type="search" name="q" value="<?= e($qv) ?>" placeholder="Search phone, message or event"></div>
<div class="col-6 col-md-2"><select class="form-select" name="status"><option value="">Any status</option><?php foreach (['sent', 'failed', 'skipped'] as $s) echo '<option ' . ($st === $s ? 'selected' : '') . '>' . $s . '</option>'; ?></select></div>
<div class="col-6 col-md-auto"><button class="btn btn-primary w-100">Search</button></div></form>
<div class="card"><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>When</th><th>Phone</th><th>Event</th><th>Message</th><th>Status</th><th>Cost</th></tr></thead><tbody>
<?php if (!$list) echo '<tr><td colspan="6" class="text-center text-body-secondary py-4">No SMS yet.</td></tr>'; foreach ($list as $r): ?>
<tr><td class="text-nowrap"><?= e(fmt_dt($r['created_at'], 'j M, g:i A')) ?></td><td><?= e($r['phone']) ?></td><td><?= e($r['event'] ?: '-') ?></td><td class="small" style="min-width:16rem"><?= e($r['message']) ?></td>
<td><span class="badge text-bg-<?= ['sent' => 'success', 'failed' => 'danger', 'skipped' => 'secondary'][$r['status']] ?? 'secondary' ?>"><?= e($r['status']) ?></span><div class="small text-body-secondary"><?= e($r['provider_status']) ?></div></td><td class="small"><?= e($r['cost']) ?></td></tr><?php endforeach; ?></tbody></table></div></div>
<div class="mt-3"><?= pager($total, $pg, $per) ?></div>
<?php page_footer(['admin' => true]); ?>
