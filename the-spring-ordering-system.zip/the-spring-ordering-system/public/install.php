<?php
/**
 * One-time web installer. Creates the tables and the first admin account.
 * It locks itself afterwards (storage/installed.lock). Delete this file once you are done.
 */
declare(strict_types=1);
define('ROOT', dirname(__DIR__));
define('PUBLIC_PATH', __DIR__);
$lock = ROOT . '/storage/installed.lock';
$cfgFile = ROOT . '/config/config.php';
function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
$msg = ''; $ok = false;
if (is_file($lock)) { http_response_code(403); exit('Already installed. For safety, delete public/install.php from the server.'); }
if (!is_file($cfgFile)) exit('Copy config/config.sample.php to config/config.php and enter your database details first, then reload this page.');
$cfg = require $cfgFile;
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    try {
        $c = $cfg['db'];
        $pdo = new PDO("mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset=utf8mb4", $c['user'], $c['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $name = trim($_POST['name'] ?? ''); $email = strtolower(trim($_POST['email'] ?? '')); $phone = preg_replace('/\D/', '', $_POST['phone'] ?? ''); $pw = (string)($_POST['password'] ?? '');
        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($phone) < 9 || strlen($pw) < 8) throw new Exception('Fill in every field. The password needs at least 8 characters.');
        if (strlen($phone) === 10 && $phone[0] === '0') $phone = '254' . substr($phone, 1);
        if (strlen($phone) === 9) $phone = '254' . $phone;
        $has = $pdo->query("SHOW TABLES LIKE 'users'")->fetchColumn();
        if (!$has) {
            $sql = (string)file_get_contents(ROOT . '/database/schema.sql');
            $sql = preg_replace('/^--.*$/m', '', $sql);
            foreach (array_filter(array_map('trim', explode(";\n", $sql))) as $stmt) $pdo->exec($stmt);
        }
        if ((int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn() > 0) throw new Exception('An admin account already exists.');
        $st = $pdo->prepare("INSERT INTO users (name,email,phone,password_hash,role) VALUES (?,?,?,?, 'admin')");
        $st->execute([$name, $email, $phone, password_hash($pw, PASSWORD_DEFAULT)]);
        if (($cfg['app_key'] ?? '') === 'CHANGE_ME_TO_A_LONG_RANDOM_STRING') $msg = 'Installed. WARNING: change app_key in config/config.php before saving any API credentials.'; else $msg = 'Installed.';
        file_put_contents($lock, date('c'));
        $ok = true;
    } catch (Throwable $e) { $msg = 'Install failed: ' . $e->getMessage(); }
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Install The Spring</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light"><div class="container py-5" style="max-width:520px">
<h1 class="h3 mb-1">Install The Spring</h1><p class="text-secondary">Creates the database tables and your first admin account.</p>
<?php if ($msg): ?><div class="alert alert-<?= $ok ? 'success' : 'danger' ?>"><?= h($msg) ?></div><?php endif; ?>
<?php if ($ok): ?><p><a class="btn btn-success" href="login.php">Sign in</a></p><p class="text-secondary small">Then delete <code>public/install.php</code> from the server.</p>
<?php else: ?><form method="post" class="card card-body gap-2">
<label>Your name<input class="form-control" name="name" required></label>
<label>Admin email<input class="form-control" type="email" name="email" required></label>
<label>Phone (07xx xxx xxx)<input class="form-control" name="phone" required></label>
<label>Password (min. 8 characters)<input class="form-control" type="password" name="password" minlength="8" required></label>
<button class="btn btn-success mt-2">Install</button></form><?php endif; ?>
</div></body></html>
