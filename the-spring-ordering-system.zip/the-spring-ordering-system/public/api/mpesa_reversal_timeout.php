<?php
define('NO_SESSION', true);
require __DIR__ . '/../../app/bootstrap.php';
header('Content-Type: application/json');
$raw = file_get_contents('php://input') ?: '';
@file_put_contents(ROOT . '/storage/logs/mpesa_reversal.log', '[' . date('c') . '] TIMEOUT ' . $raw . "\n", FILE_APPEND);
if (!hash_equals(Settings::callbackToken(), (string)($_GET['token'] ?? ''))) { http_response_code(403); echo json_encode(['ResultCode' => 1]); exit; }
$j = json_decode($raw, true);
if (is_array($j)) { try { Refunds::handleTimeout($j); } catch (Throwable $e) { error_log('reversal timeout: ' . $e->getMessage()); } }
echo json_encode(['ResultCode' => 0, 'ResultDesc' => 'Accepted']);
