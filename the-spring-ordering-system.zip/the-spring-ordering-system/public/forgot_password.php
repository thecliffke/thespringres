<?php
require __DIR__ . '/../app/bootstrap.php';
if (Auth::user()) redirect(Auth::home());
$sent = false;
if (is_post()) {
    csrf_check();
    $email = strtolower(post('email')); $ip = client_ip();
    q('DELETE FROM password_resets WHERE expires_at < (NOW() - INTERVAL 1 DAY)');
    $recent = (int)val('SELECT COUNT(*) FROM password_resets WHERE ip=? AND created_at > (NOW() - INTERVAL 1 HOUR)', [$ip]);
    $u = filter_var($email, FILTER_VALIDATE_EMAIL) ? row('SELECT id,name,email FROM users WHERE email=? AND is_active=1', [$email]) : null;
    if ($u && $recent < 5) {
        $raw = bin2hex(random_bytes(32));
        q('UPDATE password_resets SET used_at=NOW() WHERE user_id=? AND used_at IS NULL', [$u['id']]);
        q('INSERT INTO password_resets (user_id, token_hash, ip, expires_at) VALUES (?,?,?, (NOW() + INTERVAL 60 MINUTE))', [$u['id'], hash('sha256', $raw), $ip]);
        $link = abs_url('reset_password.php?token=' . $raw); $name = Settings::get('restaurant_name');
        $html = '<p>Hi ' . e(explode(' ', $u['name'])[0]) . ',</p><p>We received a request to reset your ' . e($name) . ' password. This link works for 60 minutes:</p><p><a href="' . e($link) . '">Reset my password</a></p><p>Or copy this address into your browser:<br>' . e($link) . '</p><p>If you did not ask for this, you can ignore this email. Your password stays the same.</p>';
        $r = Mailer::send($u['email'], 'Reset your ' . $name . ' password', $html);
        if (!$r['ok']) error_log('password reset email: ' . $r['message']);
    } elseif ($u) { error_log('password reset rate limit hit for ' . $ip); }
    Audit::log('auth.password_reset_requested', 'Password reset link requested for ' . $email, $u ? 'user' : null, $u['id'] ?? null, ['account_found' => (bool)$u, 'rate_limited' => $u && $recent >= 5], []);
    $sent = true;   // same answer whether or not the email exists
}
page_header('Forgot password');
?>
<div class="row justify-content-center"><div class="col-md-6 col-lg-5"><div class="card shadow-sm"><div class="card-body p-4">
<h1 class="h3 sp-display mb-1">Forgot your password?</h1>
<?php if ($sent): ?>
  <div class="alert alert-success mt-3">If that email belongs to an account, we have sent a reset link. It is valid for 60 minutes. Check your spam folder too.</div>
  <a class="btn btn-primary w-100" href="<?= e(url('login.php')) ?>">Back to sign in</a>
<?php else: ?>
  <p class="text-body-secondary">Enter your account email and we will send you a link to choose a new password.</p>
  <form method="post" novalidate><?= csrf_field() ?>
    <label class="form-label" for="e">Email</label><input class="form-control mb-3" id="e" type="email" name="email" required autocomplete="email" autofocus>
    <button class="btn btn-primary w-100 btn-lg">Send reset link</button></form>
  <p class="text-center mt-3 mb-0"><a href="<?= e(url('login.php')) ?>">Back to sign in</a></p>
<?php endif; ?>
</div></div></div></div>
<?php page_footer(); ?>
