<?php
require __DIR__ . '/../app/bootstrap.php';
$u = Auth::require();
if (is_post()) { csrf_check(); q('UPDATE notifications SET is_read=1 WHERE user_id=?', [$u['id']]); redirect('/notifications.php'); }
if ($id = (int)get('go')) {
    $n = row('SELECT * FROM notifications WHERE id=? AND user_id=?', [$id, $u['id']]);
    if ($n) { q('UPDATE notifications SET is_read=1 WHERE id=?', [$id]); if ($n['link'] && str_starts_with($n['link'], '/')) redirect($n['link']); }
    redirect('/notifications.php');
}
$list = rows('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 100', [$u['id']]);
$staff = Auth::isStaff();
page_header('Notifications', ['admin' => $staff, 'active' => '']);
?>
<?php if (!$staff): ?><h1 class="h3 sp-display mb-3">Notifications</h1><?php endif; ?>
<?php if (Push::enabled()): ?><div class="card card-body mb-3"><div class="fw-semibold mb-1"><i class="bi bi-bell me-1"></i>Phone and desktop notifications</div><p class="small text-body-secondary mb-2">Get order updates and reminders even when the app is closed. This setting is per device.</p><div id="push-panel"><span class="small text-body-secondary">Checking&hellip;</span></div></div><?php endif; ?>
<form method="post" class="mb-3"><?= csrf_field() ?><button class="btn btn-outline-primary btn-sm">Mark all as read</button></form>
<div class="card"><div class="list-group list-group-flush">
<?php if (!$list) echo '<div class="list-group-item text-body-secondary py-4">Nothing here yet. Order updates and reminders will show up in this list.</div>'; ?>
<?php foreach ($list as $n): ?><a class="list-group-item list-group-item-action d-flex gap-3 <?= $n['is_read'] ? '' : 'fw-semibold' ?>" href="?go=<?= (int)$n['id'] ?>">
  <span class="mt-2 rounded-circle flex-none" style="width:10px;height:10px;flex:none;background:<?= $n['is_read'] ? 'transparent' : '#FFB627' ?>"></span>
  <span class="flex-grow-1"><?= e($n['title']) ?><br><span class="fw-normal text-body-secondary small"><?= e($n['body']) ?></span></span><small class="text-body-secondary text-nowrap"><?= e(fmt_dt($n['created_at'], 'j M, g:i A')) ?></small></a><?php endforeach; ?>
</div></div>
<?php page_footer(['admin' => $staff]); ?>
