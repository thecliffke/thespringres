<?php
declare(strict_types=1);

/**
 * Audit trail: who did what, when and from where. Append-only and tamper-evident: every row stores an HMAC
 * (keyed with config app_key) of its content chained to the previous row, so edited or deleted rows are detected.
 * Writing to the trail never breaks the action being recorded.
 */
class Audit {
    const CATEGORIES = ['auth' => 'Sign-in and accounts', 'order' => 'Orders', 'payment' => 'Payments', 'refund' => 'Refunds', 'message' => 'Messages', 'menu' => 'Menu and offers',
        'user' => 'Team and customers', 'settings' => 'Settings', 'reminder' => 'Reminders', 'loyalty' => 'Loyalty points', 'push' => 'Notifications', 'export' => 'Data exports', 'system' => 'System'];

    /** Internal bookkeeping settings that are not worth recording. */
    const QUIET_SETTINGS = ['reminders_last_run', 'cron_last_run', 'reconcile_last_run', 'schema_version', 'vapid_public', 'vapid_private', 'mpesa_callback_token'];

    private static function chainData(array $r): string {
        return implode('|', [$r['created_at'], $r['user_id'] ?? '', $r['user_name'], $r['user_role'], $r['action'], $r['summary'], $r['entity_type'] ?? '', $r['entity_id'] ?? '', $r['details'] ?? '', $r['ip'], $r['prev_hash']]);
    }
    private static function mac(array $r): string { return hash_hmac('sha256', self::chainData($r), (string)cfg('app_key', 'change-me')); }

    /** @param array|null $actor  who did it (null = the signed-in user, or "System" when nobody is signed in) */
    public static function log(string $action, string $summary, ?string $entityType = null, $entityId = null, array $details = [], ?array $actor = null): void {
        try {
            $a = $actor === [] ? null : ($actor ?? Auth::user());   // [] = the system itself
            $row = ['created_at' => date('Y-m-d H:i:s'), 'user_id' => $a ? (int)$a['id'] : null, 'user_name' => $a ? mb_substr((string)$a['name'], 0, 120) : 'System', 'user_role' => $a ? (string)$a['role'] : 'system',
                'action' => mb_substr($action, 0, 60), 'summary' => mb_substr($summary, 0, 400), 'entity_type' => $entityType, 'entity_id' => $entityId === null ? null : mb_substr((string)$entityId, 0, 40),
                'details' => $details ? mb_substr(json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), 0, 4000) : null,
                'ip' => mb_substr(client_ip(), 0, 45), 'user_agent' => mb_substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 200)];
            $locked = (int)val("SELECT GET_LOCK('sp_audit_chain', 5)") === 1;
            try {
                $row['prev_hash'] = (string)(val('SELECT row_hash FROM audit_log ORDER BY id DESC LIMIT 1') ?: str_repeat('0', 64));
                $row['row_hash'] = self::mac($row);
                q('INSERT INTO audit_log (created_at,user_id,user_name,user_role,action,summary,entity_type,entity_id,details,ip,user_agent,prev_hash,row_hash) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    array_values($row));
            } finally { if ($locked) q("SELECT RELEASE_LOCK('sp_audit_chain')"); }
        } catch (Throwable $e) { error_log('audit: ' . $e->getMessage()); }
    }

    /** Walks the whole chain. @return array{ok:bool,checked:int,bad_id:?int,reason:string} */
    public static function verify(): array {
        $prev = str_repeat('0', 64); $n = 0; $last = 0;
        $st = db()->query('SELECT * FROM audit_log ORDER BY id ASC');
        while ($r = $st->fetch()) {
            $n++;
            if ($r['prev_hash'] !== $prev) return ['ok' => false, 'checked' => $n, 'bad_id' => (int)$r['id'], 'reason' => 'A record before this one was removed or changed.'];
            if (!hash_equals(self::mac($r), $r['row_hash'])) return ['ok' => false, 'checked' => $n, 'bad_id' => (int)$r['id'], 'reason' => 'This record was edited after it was written.'];
            $prev = $r['row_hash']; $last = (int)$r['id'];
        }
        return ['ok' => true, 'checked' => $n, 'bad_id' => null, 'reason' => ''];
    }
}
