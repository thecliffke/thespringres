<?php
declare(strict_types=1);

class Orders {
    const FLOW_DINE = ['placed', 'preparing', 'ready', 'completed'];
    const FLOW_DELIVERY = ['placed', 'preparing', 'ready', 'dispatched', 'completed'];

    public static function flow(array $o): array { return $o['type'] === 'delivery' ? self::FLOW_DELIVERY : self::FLOW_DINE; }
    public static function next(array $o): ?string {
        $f = self::flow($o); $i = array_search($o['status'], $f, true);
        return ($i !== false && $i < count($f) - 1) ? $f[$i + 1] : null;
    }
    public static function nextLabel(array $o, string $n): string {
        return ['preparing' => 'Start preparing', 'ready' => 'Mark ready', 'dispatched' => 'Dispatch order',
                'completed' => $o['type'] === 'delivery' ? 'Mark delivered' : 'Close order'][$n] ?? $n;
    }
    public static function balance(array $o): float { return max(0.0, (float)$o['total'] - (float)$o['amount_paid']); }
    public static function find(int $id): ?array { return row('SELECT * FROM orders WHERE id=?', [$id]); }
    public static function items(int $id): array { return rows('SELECT * FROM order_items WHERE order_id=? ORDER BY id', [$id]); }

    /* ----- pricing ----- */
    public static function offerActive(array $i): bool {
        return (int)$i['offer_percent'] > 0 && (empty($i['offer_ends']) || $i['offer_ends'] >= date('Y-m-d'));
    }
    public static function priceOf(array $i): float {
        return self::offerActive($i) ? round((float)$i['price'] * (1 - (int)$i['offer_percent'] / 100)) : (float)$i['price'];
    }

    /* ----- time slots ----- */
    public static function isOpenNow(): bool { $n = date('H:i'); return $n >= Settings::get('open_time') && $n <= Settings::get('close_time'); }
    /** @return array<int,array{value:string,label:string}> */
    public static function slots(string $type, int $dayOffset): array {
        $lead = (int)Settings::get($type === 'delivery' ? 'lead_delivery' : 'lead_dine_in');
        $step = max(10, (int)Settings::get('slot_minutes')) * 60;
        $day = date('Y-m-d', strtotime("+$dayOffset day"));
        $t = strtotime($day . ' ' . Settings::get('open_time'));
        $end = strtotime($day . ' ' . Settings::get('close_time'));
        $min = time() + $lead * 60;
        $out = [];
        for (; $t <= $end; $t += $step) if ($t >= $min) $out[] = ['value' => date('Y-m-d H:i:s', $t), 'label' => date('g:i A', $t)];
        return $out;
    }
    public static function slotMap(): array {
        $m = [];
        foreach (['dine_in', 'delivery'] as $t) foreach ([0, 1] as $d) $m[$t][$d] = self::slots($t, $d);
        return $m;
    }

    /* ----- create ----- */
    /** @param array<int,int> $cart item_id => qty */
    public static function create(array $user, array $d, array $cart): int {
        if (!$cart) throw new RuntimeException('Your cart is empty.');
        $in = implode(',', array_fill(0, count($cart), '?'));
        $items = rows("SELECT * FROM menu_items WHERE is_available=1 AND id IN ($in)", array_map('intval', array_keys($cart)));
        if (count($items) !== count($cart)) throw new RuntimeException('Some items in your cart are no longer available. Review your cart.');
        $sub = 0.0;
        foreach ($items as $i) $sub += self::priceOf($i) * (int)$cart[$i['id']];
        $fee = $d['type'] === 'delivery' ? (float)Settings::get('delivery_fee') : 0.0;
        $total = $sub + $fee;
        $pct = Settings::depositPct();
        $deposit = ceil($total * $pct / 100);
        db()->beginTransaction();
        try {
            // Loyalty points used as a discount on the food bill: checked against the balance under a row lock so two orders cannot spend the same points.
            $pts = 0; $disc = 0.0;
            if (!empty($d['use_points']) && Loyalty::enabled()) {
                q('SELECT id FROM users WHERE id=? FOR UPDATE', [$user['id']]);
                $pts = Loyalty::maxUsable((int)$user['id'], $sub);
                $disc = (float)($pts * Loyalty::pointValue());
            }
            $total = $sub + $fee - $disc;
            $deposit = ceil($total * $pct / 100);
            [$lat, $lng] = $d['type'] === 'delivery' ? Addresses::pin($d['lat'] ?? null, $d['lng'] ?? null) : [null, null];
            $id = exec_id('INSERT INTO orders (order_no,customer_id,customer_name,phone,type,scheduled_at,asap,party_size,address,landmark,lat,lng,notes,subtotal,delivery_fee,loyalty_points,loyalty_discount,total,deposit_pct,deposit_due,status)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                ['TMP' . bin2hex(random_bytes(6)), $user['id'], $user['name'], $d['phone'], $d['type'], $d['scheduled_at'], $d['asap'] ? 1 : 0, (int)$d['party_size'],
                 $d['address'], $d['landmark'], $lat, $lng, $d['notes'], $sub, $fee, $pts, $disc, $total, $pct, $deposit, 'awaiting_deposit']);
            q('UPDATE orders SET order_no=? WHERE id=?', ['SP-' . (1000 + $id), $id]);
            if ($pts > 0) Loyalty::record((int)$user['id'], -$pts, 'redeem', $id, 'Used on SP-' . (1000 + $id), 'redeem:' . $id);
            foreach ($items as $i) q('INSERT INTO order_items (order_id,menu_item_id,name,unit_price,qty) VALUES (?,?,?,?,?)', [$id, $i['id'], $i['name'], self::priceOf($i), (int)$cart[$i['id']]]);
            q('INSERT INTO order_events (order_id,status,user_id) VALUES (?,?,?)', [$id, 'awaiting_deposit', $user['id']]);
            db()->commit();
        } catch (Throwable $e) { db()->rollBack(); throw $e; }
        Audit::log('order.created', 'Order SP-' . (1000 + $id) . ' created (' . type_label($d['type']) . ', ' . money($total) . ', deposit ' . money($deposit) . ' due)', 'order', $id, ['items' => count($cart), 'type' => $d['type'], 'total' => $total, 'deposit_due' => $deposit, 'loyalty_points' => $pts, 'loyalty_discount' => $disc], $user);
        return $id;
    }

    /* ----- payments ----- */
    /** Idempotent on $mpesaReceipt. Returns payment id. */
    /**
     * Records a payment against an order. Idempotent on $mpesaReceipt.
     * $opts: method ('mpesa' default | 'cash' | 'mpesa_manual'), received_by (staff id), note, by_user (true = attribute the audit entry to the signed-in person).
     * Each payment stores what share of the order total it covered and the balance left afterwards.
     */
    public static function recordPayment(int $orderId, string $kind, float $amount, string $phone, ?string $mpesaReceipt, ?int $requestId, array $opts = []): int {
        if ($mpesaReceipt) {
            $ex = val('SELECT id FROM payments WHERE mpesa_receipt=?', [$mpesaReceipt]);
            if ($ex) return (int)$ex;
        }
        $method = in_array($opts['method'] ?? 'mpesa', ['cash', 'mpesa_manual'], true) ? $opts['method'] : 'mpesa';
        $own = !db()->inTransaction();
        if ($own) db()->beginTransaction();
        try {
            $pid = exec_id('INSERT INTO payments (receipt_no,order_id,kind,amount,phone,mpesa_receipt,mpesa_request_id,method,received_by,note) VALUES (?,?,?,?,?,?,?,?,?,?)',
                ['TMP' . bin2hex(random_bytes(6)), $orderId, $kind, $amount, $phone, $mpesaReceipt, $requestId, $method, $opts['received_by'] ?? null, isset($opts['note']) ? mb_substr((string)$opts['note'], 0, 255) : null]);
            q('UPDATE payments SET receipt_no=? WHERE id=?', [sprintf('RCT-%06d', $pid), $pid]);
            q('UPDATE orders SET amount_paid = amount_paid + ? WHERE id=?', [$amount, $orderId]);
            $o = self::find($orderId);
            q('UPDATE payments SET pct_of_total=?, balance_after=? WHERE id=?', [(float)$o['total'] > 0 ? round($amount / (float)$o['total'] * 100, 2) : null, max(0, (float)$o['total'] - (float)$o['amount_paid']), $pid]);
            if ($kind === 'deposit' && $o['status'] === 'awaiting_deposit') {
                q("UPDATE orders SET status='placed' WHERE id=?", [$orderId]);
                q('INSERT INTO order_events (order_id,status) VALUES (?,?)', [$orderId, 'placed']);
            }
            if ($own) db()->commit();
        } catch (Throwable $e) { if ($own && db()->inTransaction()) db()->rollBack(); throw $e; }

        $o = self::find($orderId);
        $pct = (float)$o['total'] > 0 ? round($amount / (float)$o['total'] * 100, 1) : 0;
        $how = $method === 'cash' ? 'in cash' : 'by M-Pesa' . ($mpesaReceipt ? ' (' . $mpesaReceipt . ')' : '') . ($method === 'mpesa_manual' ? ', confirmed manually' : '');
        Audit::log($method === 'cash' ? 'payment.cash' : ($method === 'mpesa_manual' ? 'payment.confirmed_manually' : 'payment.received'),
            money($amount) . ' (' . $pct . '% of the order) ' . $kind . ' received for ' . $o['order_no'] . ' ' . $how, 'order', $orderId,
            ['kind' => $kind, 'method' => $method, 'amount' => $amount, 'pct_of_total' => $pct, 'phone' => mask_phone($phone), 'mpesa_code' => $mpesaReceipt, 'receipt_no' => sprintf('RCT-%06d', $pid), 'note' => $opts['note'] ?? null],
            empty($opts['by_user']) ? [] : null);
        if ((float)$o['amount_paid'] - (float)$o['total'] >= 1) {   // e.g. a retry paid after the first attempt's money arrived late
            $over = (float)$o['amount_paid'] - (float)$o['total'];
            Notify::staff('Overpayment on ' . $o['order_no'], money($over) . ' more than the order total has been paid. Refund the difference to the customer.', '/admin/order.php?id=' . $orderId . '#payments');
            Audit::log('payment.overpaid', $o['order_no'] . ' is overpaid by ' . money($over) . ' and the difference needs refunding', 'order', $orderId, ['over' => $over], []);
        }
        if ($o['status'] === 'cancelled') {   // money arrived after the order was cancelled: staff must refund it
            Notify::staff('Payment on a cancelled order', money($amount) . ' was received for ' . $o['order_no'] . ', which was cancelled. Refund it to the customer.', '/admin/order.php?id=' . $orderId . '#refund');
            Notify::user((int)$o['customer_id'], 'Payment received for a cancelled order', 'We received ' . money($amount) . ' for ' . $o['order_no'] . ', which you cancelled. The restaurant will refund it.', '/order.php?id=' . $orderId);
            Audit::log('payment.on_cancelled_order', 'Payment of ' . money($amount) . ' arrived for cancelled order ' . $o['order_no'] . ' and needs a refund', 'order', $orderId, ['amount' => $amount], []);
            return $pid;
        }
        if ($kind === 'deposit') {
            Notify::user((int)$o['customer_id'], 'Order confirmed', $o['order_no'] . ' is placed. ' . ($pct >= 99.5 ? 'Paid in full: ' : 'Deposit of ') . money($amount) . ' received' . ($method === 'cash' ? ' in cash.' : '.'), '/order.php?id=' . $orderId);
            Notify::staff('New order ' . $o['order_no'], type_label($o['type']) . ' for ' . $o['customer_name'] . ', ' . money($o['total']) . ' (' . $pct . '% paid).', '/admin/order.php?id=' . $orderId);
            Sms::orderEvent('placed', $o);
        } else {
            Notify::user((int)$o['customer_id'], 'Payment received', 'We received ' . money($amount) . ($method === 'cash' ? ' in cash' : '') . ' for ' . $o['order_no'] . '. Your receipt is ready.', '/order.php?id=' . $orderId);
            if ($method !== 'cash') Notify::staff('Balance paid', $o['order_no'] . ' paid ' . money($amount) . ' by M-Pesa.', '/admin/order.php?id=' . $orderId);
        }
        return $pid;
    }

    /**
     * Staff records money taken in cash. While the deposit is unpaid it counts as the deposit (at least the minimum, up to the full total);
     * afterwards it counts against the balance.
     * @return array{ok:bool,message:string,payment_id?:int}
     */
    public static function recordCash(int $orderId, float $amount, int $staffId, string $note = ''): array {
        $o = self::find($orderId);
        if (!$o) return ['ok' => false, 'message' => 'Order not found.'];
        if ($o['status'] === 'cancelled') return ['ok' => false, 'message' => 'This order is cancelled.'];
        $amount = round($amount);
        $owed = max(0.0, (float)$o['total'] - (float)$o['amount_paid']);
        if ($owed < 1) return ['ok' => false, 'message' => 'Nothing is owed on this order.'];
        if ($amount < 1) return ['ok' => false, 'message' => 'Enter the amount received.'];
        if ($amount > $owed) return ['ok' => false, 'message' => 'That is more than the ' . money($owed) . ' still owed. Enter the amount to put against the bill (give change separately).'];
        $kind = 'balance';
        if ($o['status'] === 'awaiting_deposit') {
            $kind = 'deposit';
            $min = max(0.0, (float)$o['deposit_due'] - (float)$o['amount_paid']);
            if ($amount < $min) return ['ok' => false, 'message' => 'The deposit must be at least ' . money($min) . ' (' . (int)$o['deposit_pct'] . '% of the order) before it can be placed.'];
        }
        $pid = self::recordPayment($orderId, $kind, $amount, $o['phone'], null, null, ['method' => 'cash', 'received_by' => $staffId, 'note' => $note, 'by_user' => true]);
        return ['ok' => true, 'message' => money($amount) . ' cash recorded as ' . ($kind === 'deposit' ? 'the deposit' : 'a balance payment') . '.', 'payment_id' => $pid];
    }

    /** Reminds a customer to pay the deposit on an unpaid order (in-app notice always, SMS when enabled). Max one SMS per order per 10 minutes. */
    public static function remindDeposit(array $o): array {
        if ($o['status'] !== 'awaiting_deposit') return ['ok' => false, 'message' => 'The deposit for this order is already paid or the order is closed.'];
        $due = max(0.0, (float)$o['deposit_due'] - (float)$o['amount_paid']);
        if ((int)val("SELECT COUNT(*) FROM sms_log WHERE event='deposit' AND status='sent' AND message LIKE ? AND created_at > (NOW() - INTERVAL 10 MINUTE)", ['%' . $o['order_no'] . '%']) > 0)
            return ['ok' => false, 'message' => 'A reminder for this order was sent less than 10 minutes ago.'];
        $link = abs_url('pay.php?order=' . (int)$o['id']);
        Notify::user((int)$o['customer_id'], 'Complete your deposit', $o['order_no'] . ' is waiting for its deposit of ' . money($due) . '.', '/pay.php?order=' . (int)$o['id']);
        Audit::log('order.deposit_reminder', 'Deposit reminder sent for ' . $o['order_no'] . ' (' . money($due) . ')', 'order', (int)$o['id']);
        if (!Sms::enabled()) return ['ok' => true, 'message' => 'In-app reminder sent. SMS is switched off in Settings, so no text message went out.'];
        $msg = Sms::render('sms_tpl_deposit', ['name' => explode(' ', trim($o['customer_name']))[0], 'order' => $o['order_no'], 'restaurant' => Settings::get('restaurant_name'), 'deposit' => money($due), 'link' => $link]);
        $r = Sms::send($o['phone'], $msg, 'deposit', (int)$o['customer_id']);
        return $r['ok'] ? ['ok' => true, 'message' => 'Reminder sent by SMS and in the app.'] : ['ok' => false, 'message' => 'In-app reminder sent, but the SMS failed: ' . $r['message']];
    }

    /** A customer cancels their own order, only while its deposit is unpaid. */
    public static function cancelByCustomer(int $orderId, int $userId): void {
        $o = self::find($orderId);
        if (!$o || (int)$o['customer_id'] !== $userId) throw new RuntimeException('Order not found.');
        if ($o['status'] === 'cancelled') throw new RuntimeException($o['order_no'] . ' is already cancelled.');
        if ($o['status'] !== 'awaiting_deposit' || (float)$o['amount_paid'] > 0) throw new RuntimeException($o['order_no'] . ' has already been paid for, so it cannot be cancelled here. Please contact the restaurant.');
        if ((int)val("SELECT COUNT(*) FROM mpesa_requests WHERE order_id=? AND status='pending' AND created_at > (NOW() - INTERVAL 3 MINUTE)", [$orderId]) > 0)
            throw new RuntimeException('A payment request is still in progress. If you approved it on your phone, wait a minute and refresh. Otherwise try again shortly.');
        self::setStatus($orderId, 'cancelled', $userId);
        Audit::log('order.cancelled_by_customer', $o['customer_name'] . ' cancelled ' . $o['order_no'] . ' before paying the deposit', 'order', $orderId, ['total' => (float)$o['total']]);
    }

    /* ----- status ----- */
    public static function setStatus(int $id, string $status, ?int $userId): void {
        $o = self::find($id);
        if (!$o) throw new RuntimeException('Order not found.');
        $old = $o['status'];
        if ($status === 'cancelled') {
            if (!in_array($o['status'], ['awaiting_deposit', 'placed', 'preparing'], true)) throw new RuntimeException('This order can no longer be cancelled.');
        } else {
            if (self::next($o) !== $status) throw new RuntimeException('That status change is not allowed.');
            if ($status === 'completed' && self::balance($o) > 0.009) throw new RuntimeException('Collect the balance of ' . money(self::balance($o)) . ' by M-Pesa before closing this order.');
        }
        q('UPDATE orders SET status=?, handled_by=COALESCE(?, handled_by) WHERE id=?', [$status, $userId, $id]);
        q('INSERT INTO order_events (order_id,status,user_id) VALUES (?,?,?)', [$id, $status, $userId]);
        $o = self::find($id);
        Audit::log($status === 'cancelled' ? 'order.cancelled' : 'order.status', $o['order_no'] . ': ' . status_label($old, $o['type']) . ' to ' . status_label($status, $o['type']), 'order', $id, ['from' => $old, 'to' => $status]);
        if ($status === 'completed') Loyalty::award($o);
        if ($status === 'cancelled') Loyalty::restore($o);
        $d = $o['type'] === 'delivery';
        $msgs = [
            'preparing' => ['Your order is being prepared', $o['order_no'] . ' is in the kitchen now.'],
            'ready' => ['Your order is ready', $d ? $o['order_no'] . ' is packed and about to go out.' : $o['order_no'] . ' is ready. Enjoy your meal.'],
            'dispatched' => ['Your order is on its way', 'Our rider is heading to you with ' . $o['order_no'] . '. Keep your phone close.'],
            'completed' => [$d ? 'Order delivered' : 'Order completed', 'Thank you for choosing ' . Settings::get('restaurant_name') . '.'],
            'cancelled' => ['Your order was cancelled', $o['order_no'] . ((float)$o['amount_paid'] > 0 ? ' was cancelled. We will contact you about your deposit.' : ' was cancelled. Nothing was charged.')],
        ][$status] ?? null;
        if ($msgs) Notify::user((int)$o['customer_id'], $msgs[0], $msgs[1], '/order.php?id=' . $id);
        if (in_array($status, ['ready', 'dispatched'], true)) Sms::orderEvent($status, $o);
    }

    public static function events(int $id): array {
        $r = [];
        foreach (rows('SELECT status, created_at FROM order_events WHERE order_id=? ORDER BY id', [$id]) as $e) $r[$e['status']] = $e['created_at'];
        return $r;
    }
}
