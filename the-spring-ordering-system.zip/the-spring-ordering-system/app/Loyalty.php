<?php
declare(strict_types=1);

/**
 * Loyalty points. Every change is a row in loyalty_ledger (the balance is the sum), so history is complete and nothing drifts.
 *  - Earn: when an order is completed (so it was paid in full), points = food total after any discount, per KES 100 spent.
 *  - Redeem: at checkout the customer can use points as a discount on the food bill (capped at a share of it); points are taken
 *    when the order is placed and given back if the order is cancelled.
 *  - Refunds taken off a completed order take back the matching points.
 * Switched on by the owner under Admin, Settings, Loyalty.
 */
class Loyalty {
    public static function enabled(): bool { return Settings::get('loyalty_enabled') === '1'; }
    public static function earnRate(): int { return max(0, min(100, (int)Settings::get('loyalty_earn_per_100'))); }   // points per KES 100
    public static function pointValue(): int { return max(1, min(100, (int)Settings::get('loyalty_point_value'))); }   // KES off per point
    public static function minRedeem(): int { return max(1, (int)Settings::get('loyalty_min_redeem')); }              // balance needed before points can be used
    public static function maxPct(): int { return max(1, min(50, (int)Settings::get('loyalty_max_pct'))); }          // max share of the food bill points can pay

    public static function balance(int $uid): int { return (int)val('SELECT COALESCE(SUM(points),0) FROM loyalty_ledger WHERE user_id=?', [$uid]); }

    /** Points that can be used on an order whose food total is $subtotal (0 when not allowed). */
    public static function maxUsable(int $uid, float $subtotal, ?int $balance = null): int {
        if (!self::enabled()) return 0;
        $bal = $balance ?? self::balance($uid);
        if ($bal < self::minRedeem()) return 0;
        $capKes = (int)floor($subtotal * self::maxPct() / 100);
        return max(0, min($bal, intdiv($capKes, self::pointValue())));
    }
    public static function pointsFor(float $kes): int { return self::enabled() ? intdiv((int)floor(max(0, $kes)) * self::earnRate(), 100) : 0; }

    /** Adds a ledger row. Returns false when a row with the same $uniq already exists (so retries never double count). */
    public static function record(int $uid, int $points, string $type, ?int $orderId, string $note, ?string $uniq = null, ?int $by = null): bool {
        if ($points === 0) return false;
        return q('INSERT IGNORE INTO loyalty_ledger (user_id,order_id,points,type,note,uniq,created_by) VALUES (?,?,?,?,?,?,?)', [$uid, $orderId, $points, $type, mb_substr($note, 0, 160), $uniq, $by])->rowCount() > 0;
    }

    /** Called when an order is completed. */
    public static function award(array $o): void {
        if (!self::enabled()) return;
        $refunded = (float)val('SELECT COALESCE(SUM(reversed_amount),0) FROM payments WHERE order_id=?', [$o['id']]);
        $base = (float)$o['total'] - (float)$o['delivery_fee'] - $refunded;
        $pts = self::pointsFor($base);
        if ($pts > 0 && self::record((int)$o['customer_id'], $pts, 'earn', (int)$o['id'], 'Earned on ' . $o['order_no'], 'earn:' . (int)$o['id']))
            Notify::user((int)$o['customer_id'], 'You earned ' . $pts . ' points', 'Thanks for ordering. Your balance is now ' . number_format(self::balance((int)$o['customer_id'])) . ' points.', '/loyalty.php');
    }
    /** Called when an order is cancelled: gives back any points it used (once). */
    public static function restore(array $o): void {
        if ((int)$o['loyalty_points'] > 0 && self::record((int)$o['customer_id'], (int)$o['loyalty_points'], 'restore', (int)$o['id'], 'Points returned: ' . $o['order_no'] . ' was cancelled', 'restore:' . (int)$o['id']))
            Notify::user((int)$o['customer_id'], 'Points returned', number_format((int)$o['loyalty_points']) . ' points from the cancelled order ' . $o['order_no'] . ' are back in your balance.', '/loyalty.php');
    }
    /** A refund on a completed order takes back the matching share of the points it earned. */
    public static function onRefund(array $o, float $amount): void {
        $earned = (int)val("SELECT COALESCE(SUM(points),0) FROM loyalty_ledger WHERE order_id=? AND type='earn'", [$o['id']]);
        if ($earned <= 0) return;
        $already = -(int)val("SELECT COALESCE(SUM(points),0) FROM loyalty_ledger WHERE order_id=? AND type='reverse'", [$o['id']]);
        $take = min(intdiv((int)floor($amount) * self::earnRate(), 100), $earned - $already, max(0, self::balance((int)$o['customer_id'])));
        if ($take > 0) self::record((int)$o['customer_id'], -$take, 'reverse', (int)$o['id'], 'Points taken back for a refund on ' . $o['order_no']);
    }
    public static function adjust(int $uid, int $points, string $note, int $by): bool {
        $ok = self::record($uid, $points, 'adjust', null, $note, null, $by);
        if ($ok) {
            Audit::log('loyalty.adjusted', ($points > 0 ? 'Added ' : 'Removed ') . abs($points) . ' loyalty points for ' . (string)val('SELECT email FROM users WHERE id=?', [$uid]) . ': ' . $note, 'user', $uid, ['points' => $points, 'note' => $note]);
            Notify::user($uid, $points > 0 ? 'Points added to your account' : 'Points adjusted', ($points > 0 ? '+' : '') . $points . ' points: ' . $note, '/loyalty.php');
        }
        return $ok;
    }
    public static function history(int $uid, int $limit = 30): array {
        return rows('SELECT l.*, o.order_no FROM loyalty_ledger l LEFT JOIN orders o ON o.id=l.order_id WHERE l.user_id=? ORDER BY l.id DESC LIMIT ' . (int)$limit, [$uid]);
    }
    /** What a customer sees on the rewards card. */
    public static function summary(int $uid): array {
        $bal = self::balance($uid); $min = self::minRedeem(); $v = self::pointValue();
        return ['balance' => $bal, 'kes' => $bal * $v, 'min' => $min, 'value' => $v, 'rate' => self::earnRate(), 'pct' => self::maxPct(), 'unlocked' => $bal >= $min,
                'progress' => $min > 0 ? min(100, (int)floor($bal / $min * 100)) : 100, 'to_go' => max(0, $min - $bal)];
    }
}
