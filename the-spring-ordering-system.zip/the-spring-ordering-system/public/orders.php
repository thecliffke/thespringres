<?php
require __DIR__ . '/../app/bootstrap.php';
$u = Auth::require('customer');
$list = rows('SELECT * FROM orders WHERE customer_id=? ORDER BY id DESC LIMIT 100', [$u['id']]);
page_header('My orders', ['active' => 'orders']);
?>
<h1 class="h3 sp-display mb-3">My orders</h1>
<?php if (!$list): ?><div class="card card-body text-center py-5"><h2 class="h5">No orders yet</h2><p class="text-body-secondary">Your orders and their live status show up here.</p><div><a class="btn btn-primary" href="<?= e(url('/')) ?>">Order something tasty</a></div></div><?php endif; ?>
<div class="vstack gap-3">
<?php foreach ($list as $o): $bal = Orders::balance($o); ?>
  <div class="card position-relative"><div class="card-body">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
      <div class="d-flex align-items-center gap-2"><a class="sp-display fs-5 fw-bold text-body text-decoration-none stretched-link" href="<?= e(url('order.php?id=' . $o['id'])) ?>"><?= e($o['order_no']) ?></a><?= status_badge($o) ?><span class="badge text-bg-light border"><?= e(type_label($o['type'])) ?></span></div>
      <span class="text-body-secondary"><?= $o['asap'] ? 'As soon as possible' : e(fmt_dt($o['scheduled_at'])) ?></span></div>
    <div class="mt-2 d-flex flex-wrap gap-2"><span class="badge rounded-pill text-bg-success-subtle text-success-emphasis">Total <?= money($o['total']) ?></span>
      <?php if ($o['status'] === 'awaiting_deposit'): ?><span class="badge rounded-pill text-bg-warning">Deposit not paid</span>
      <?php elseif ($bal > 0 && $o['status'] !== 'cancelled'): ?><span class="badge rounded-pill text-bg-warning">Balance <?= money($bal) ?></span>
      <?php else: ?><span class="badge rounded-pill text-bg-secondary">Paid in full</span><?php endif; ?></div>
    <form method="post" action="<?= e(url('reorder.php')) ?>" class="mt-3 position-relative" style="z-index:2"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$o['id'] ?>"><button class="btn btn-outline-primary btn-sm"><i class="bi bi-arrow-repeat me-1"></i>Order this again</button></form>
  </div></div>
<?php endforeach; ?></div>
<?php page_footer(); ?>
