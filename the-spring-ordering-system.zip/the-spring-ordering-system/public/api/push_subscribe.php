<?php
require __DIR__ . '/../../app/bootstrap.php';
if (!is_post()) json_out(['ok' => false], 405);
csrf_check();
$u = Auth::user();
if (!$u) json_out(['ok' => false, 'message' => 'Please sign in again.'], 401);
$j = json_decode(file_get_contents('php://input') ?: '', true) ?: [];
$action = (string)($j['action'] ?? 'subscribe');
$endpoint = (string)($j['endpoint'] ?? ($j['subscription']['endpoint'] ?? ''));
if ($action === 'unsubscribe') { if ($endpoint !== '') { Push::unsubscribe($endpoint); Audit::log('push.unsubscribed', 'Turned off notifications on a device'); } json_out(['ok' => true]); }
if ($action === 'test') {
    session_write_close();
    [$ok, $n] = Push::sendNow((int)$u['id'], 'Test notification', 'Push notifications are working on this device.', '/notifications.php');
    json_out(['ok' => $ok > 0, 'message' => $n === 0 ? 'No device is registered yet. Turn on notifications first.' : ($ok > 0 ? 'Sent to ' . $ok . ' of ' . $n . ' device(s).' : 'The push service did not accept the message. Try turning notifications off and on again.')]);
}
if (!Push::enabled()) json_out(['ok' => false, 'message' => 'Push notifications are switched off.']);
$sub = $j['subscription'] ?? $j;
$err = Push::subscribe((int)$u['id'], $endpoint, (string)($sub['keys']['p256dh'] ?? ''), (string)($sub['keys']['auth'] ?? ''), (string)($_SERVER['HTTP_USER_AGENT'] ?? ''));
if (!$err && !val('SELECT 1 FROM audit_log WHERE action=? AND user_id=? AND entity_id=? LIMIT 1', ['push.subscribed', $u['id'], substr(hash('sha256', $endpoint), 0, 16)])) Audit::log('push.subscribed', 'Turned on notifications on a device', 'device', substr(hash('sha256', $endpoint), 0, 16), ['browser' => mb_substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 80)]);
json_out($err ? ['ok' => false, 'message' => $err] : ['ok' => true]);
