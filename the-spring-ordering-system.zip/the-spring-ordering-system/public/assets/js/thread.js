/* Live conversation: new messages from the other side appear without reloading. */
(function () {
  'use strict';
  var chat = document.getElementById('chat'); if (!chat) return;
  var last = +chat.dataset.last || 0;
  function scrollEnd() { var e = document.getElementById('end'); if (e) e.scrollIntoView({ block: 'end' }); }
  function bubble(m) {
    var row = document.createElement('div'); row.className = 'bubble-row ' + (m.mine ? 'mine' : 'theirs'); row.dataset.id = m.id;
    var b = document.createElement('div'); b.className = 'bubble';
    [['who', m.name], ['txt', m.body], ['when', m.time]].forEach(function (p) { var d = document.createElement('div'); d.className = p[0]; d.textContent = p[1]; b.appendChild(d); });
    row.appendChild(b); return row;
  }
  function poll() {
    if (document.hidden) return;
    fetch(chat.dataset.api + '?thread=' + chat.dataset.thread + '&after=' + last, { credentials: 'same-origin', headers: { Accept: 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (!j || !j.ok || !j.messages.length) return;
        var nearEnd = (window.innerHeight + window.scrollY) >= document.body.scrollHeight - 160;
        j.messages.forEach(function (m) { if (!chat.querySelector('[data-id="' + m.id + '"]')) chat.appendChild(bubble(m)); last = Math.max(last, m.id); });
        if (nearEnd) scrollEnd();
      }).catch(function () {});
  }
  scrollEnd(); setInterval(poll, 6000);
})();
