<?php
define('ADMIN_ONLY', true);
require __DIR__ . '/_guard.php';
if (is_post()) {
    csrf_check();
    $a = post('action'); $id = (int)post('id');
    if ($a === 'add') {
        $email = strtolower(post('email')); $ph = norm_phone(post('phone')); $role = in_array(post('role'), ['admin', 'waiter'], true) ? post('role') : 'waiter';
        if (post('name') === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !$ph || strlen(post('password')) < 6) flash('danger', 'Fill in every field. The password needs at least 6 characters.');
        elseif (row('SELECT id FROM users WHERE email=?', [$email])) flash('danger', 'That email is already in use.');
        else { $nid = exec_id('INSERT INTO users (name,email,phone,password_hash,role) VALUES (?,?,?,?,?)', [post('name'), $email, $ph, password_hash(post('password'), PASSWORD_DEFAULT), $role]); Audit::log('user.created', 'Created ' . $role . ' account for ' . post('name') . ' (' . $email . ')', 'user', $nid, ['role' => $role]); flash('success', 'Staff member added.'); }
    } elseif ($a === 'toggle' && $id !== (int)$ME['id']) { q('UPDATE users SET is_active = 1 - is_active WHERE id=?', [$id]); $tu = row('SELECT name,email,is_active FROM users WHERE id=?', [$id]); Audit::log($tu && $tu['is_active'] ? 'user.activated' : 'user.deactivated', ($tu && $tu['is_active'] ? 'Reactivated ' : 'Deactivated ') . ($tu['name'] ?? '#' . $id) . ' (' . ($tu['email'] ?? '') . ')', 'user', $id); flash('success', 'Account updated.'); }
    elseif ($a === 'reset' && $id !== (int)$ME['id']) {
        $tmp = substr(bin2hex(random_bytes(5)), 0, 10); q('UPDATE users SET password_hash=? WHERE id=?', [password_hash($tmp, PASSWORD_DEFAULT), $id]); Audit::log('user.password_reset_by_admin', 'Reset the password for ' . (string)val('SELECT email FROM users WHERE id=?', [$id]), 'user', $id);
        flash('success', 'New temporary password: ' . $tmp . ' (shown once, share it with the user).');
    }
    redirect('/admin/users.php');
}
$role = get('role'); $qv = get('q'); $per = 25; $pg = page_num();
$where = ['1=1']; $p = [];
if (in_array($role, ['admin', 'waiter', 'customer'], true)) { $where[] = 'u.role=?'; $p[] = $role; }
if ($qv !== '') { $where[] = '(u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)'; array_push($p, "%$qv%", "%$qv%", phone_term($qv)); }
$W = implode(' AND ', $where);
$total = (int)val("SELECT COUNT(*) FROM users u WHERE $W", $p);
$list = rows("SELECT u.*, (SELECT COUNT(*) FROM orders o WHERE o.customer_id=u.id) orders FROM users u WHERE $W ORDER BY FIELD(u.role,'admin','waiter','customer'), u.name LIMIT $per OFFSET " . (($pg - 1) * $per), $p);
page_header('Team and customers', ['admin' => true, 'active' => 'users']);
?>
<div class="row g-3"><div class="col-xl-8">
 <form class="row g-2 mb-3" method="get"><div class="col"><input class="form-control" type="search" name="q" value="<?= e($qv) ?>" placeholder="Search name, email or phone"></div>
  <div class="col-4 col-md-3"><select class="form-select" name="role"><option value="">All roles</option><?php foreach (['admin' => 'Admins', 'waiter' => 'Waiters', 'customer' => 'Customers'] as $k => $l) echo '<option value="' . $k . '"' . ($role === $k ? ' selected' : '') . '>' . $l . '</option>'; ?></select></div><div class="col-auto"><button class="btn btn-primary">Search</button></div></form>
 <div class="card"><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Name</th><th>Role</th><th>Contact</th><th class="text-end">Orders</th><th></th></tr></thead><tbody>
 <?php foreach ($list as $u): ?><tr><td><b><?= e($u['name']) ?></b><?= $u['is_active'] ? '' : ' <span class="badge text-bg-danger">Deactivated</span>' ?></td><td><span class="badge text-bg-<?= ['admin' => 'warning', 'waiter' => 'info', 'customer' => 'secondary'][$u['role']] ?>"><?= e(['admin' => 'System admin', 'waiter' => 'Waiter', 'customer' => 'Customer'][$u['role']]) ?></span></td>
  <td class="small"><?= e($u['email']) ?><br><?= $u['phone'] !== '' ? '+' . e($u['phone']) : '<span class="text-body-secondary">no phone yet</span>' ?></td><td class="text-end"><?= (int)$u['orders'] ?></td>
  <td class="text-end text-nowrap"><?php if ((int)$u['id'] === (int)$ME['id']): ?><span class="text-body-secondary small">You</span><?php else: ?>
   <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><button class="btn btn-outline-secondary btn-sm" name="action" value="reset" onclick="return confirm('Reset this password?')">Reset password</button>
   <button class="btn btn-outline-<?= $u['is_active'] ? 'danger' : 'primary' ?> btn-sm" name="action" value="toggle"><?= $u['is_active'] ? 'Deactivate' : 'Reactivate' ?></button></form><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div></div>
 <div class="mt-3"><?= pager($total, $pg, $per) ?></div>
</div>
<div class="col-xl-4"><div class="card"><div class="card-body"><h2 class="h5 sp-display">Add staff member</h2>
 <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="add">
  <input class="form-control mb-2" name="name" placeholder="Full name" required><input class="form-control mb-2" type="email" name="email" placeholder="Email" required><input class="form-control mb-2" name="phone" placeholder="Phone 07xx xxx xxx" required>
  <select class="form-select mb-2" name="role"><option value="waiter">Waiter or waitress</option><option value="admin">System admin</option></select>
  <input class="form-control mb-3" name="password" placeholder="Temporary password (min 6)" minlength="6" required><button class="btn btn-primary w-100">Add staff member</button></form>
 <p class="form-text mt-2 mb-0">Waiters can manage orders, collect balances and search payments. Only admins can change the menu, settings and team.</p></div></div></div></div>
<?php page_footer(['admin' => true]); ?>
