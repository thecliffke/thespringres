<?php
require __DIR__ . '/../app/bootstrap.php';
$u = Auth::require('customer');
$o = Orders::find((int)get('order'));
if (!$o || (int)$o['customer_id'] !== (int)$u['id']) { flash('danger', 'Order not found.'); redirect('/orders.php'); }
$kind = get('kind') === 'balance' ? 'balance' : 'deposit';
if ($kind === 'deposit' && $o['status'] !== 'awaiting_deposit') redirect('/order.php?id=' . $o['id']);
if ($kind === 'balance' && (Orders::balance($o) < 1 || !in_array($o['status'], ['ready', 'dispatched'], true))) redirect('/order.php?id=' . $o['id']);
if (is_post() && post('action') === 'cancel') {
    csrf_check();
    try { Orders::cancelByCustomer((int)$o['id'], (int)$u['id']); flash('success', $o['order_no'] . ' was cancelled. Nothing was charged.'); redirect('/orders.php'); }
    catch (RuntimeException $e) { flash('danger', $e->getMessage()); redirect('/pay.php?order=' . $o['id']); }
}
$items = Orders::items((int)$o['id']);
page_header($kind === 'deposit' ? 'Pay deposit' : 'Pay balance');
?>
<div class="row justify-content-center"><div class="col-lg-6">
<div class="card"><div class="card-body p-4">
  <h1 class="h3 sp-display"><?= $kind === 'deposit' ? 'Pay your deposit' : 'Pay the balance' ?></h1>
  <p class="text-body-secondary"><?= e($o['order_no']) ?>, <?= e(type_label($o['type'])) ?>, <?= $o['asap'] ? 'as soon as possible' : e(fmt_dt($o['scheduled_at'])) ?></p>
  <ul class="list-unstyled border rounded-3 p-3 mb-3 small"><?php foreach ($items as $i) echo '<li class="d-flex justify-content-between"><span>' . (int)$i['qty'] . ' x ' . e($i['name']) . '</span><span>' . money($i['qty'] * $i['unit_price']) . '</span></li>'; ?>
    <?php if ($o['delivery_fee'] > 0): ?><li class="d-flex justify-content-between"><span>Delivery fee</span><span><?= money($o['delivery_fee']) ?></span></li><?php endif; ?>
    <?php if ($o['loyalty_discount'] > 0): ?><li class="d-flex justify-content-between text-success"><span>Loyalty discount (<?= number_format((int)$o['loyalty_points']) ?> points)</span><span>- <?= money($o['loyalty_discount']) ?></span></li><?php endif; ?>
    <li class="d-flex justify-content-between fw-bold border-top mt-2 pt-2"><span>Order total</span><span><?= money($o['total']) ?></span></li></ul>
  <?php if ($kind === 'deposit'): ?><p class="small text-body-secondary">The minimum is <b><?= money($o['deposit_due']) ?></b> (<?= (int)$o['deposit_pct'] ?>% of the order). You can pay more, or the whole amount, and owe less later.</p><?php endif; ?>
  <?= stk_widget($o, $kind, $u['phone'] ?: $o['phone'], url('order.php?id=' . $o['id']), '', $kind === 'deposit', url('messages.php?new=1&order=' . $o['id'])) ?>
  <?php if ($kind === 'deposit'): ?><p class="small text-body-secondary mt-3 mb-0">Your order is held until the deposit is paid. You can leave this page and finish later from <a href="<?= e(url('orders.php')) ?>">My orders</a>.</p><form method="post" class="mt-3" data-confirm="Cancel this order? Nothing has been charged."><?= csrf_field() ?><input type="hidden" name="action" value="cancel"><button class="btn btn-outline-danger btn-sm">Cancel this order</button></form><?php endif; ?>
</div></div></div></div>
<?php page_footer(['scripts' => ['stk.js']]); ?>
