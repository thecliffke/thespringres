<?php
require __DIR__ . '/../../app/bootstrap.php';
$u = Auth::user();
if (!$u) json_out([]);
session_write_close();
try { Reminders::runDue(); } catch (Throwable $e) { error_log($e->getMessage()); }
if (time() - (int)Settings::get('reconcile_last_run') > 90) { Settings::set('reconcile_last_run', (string)time()); try { Mpesa::reconcileStale(5); } catch (Throwable $e) { error_log($e->getMessage()); } }
$since = (int)($_GET['since'] ?? 0);
$items = rows('SELECT id,title,body,link FROM notifications WHERE user_id=? AND id>? ORDER BY id LIMIT 10', [$u['id'], $since]);
json_out(['unread' => (int)val('SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0', [$u['id']]), 'max' => (int)val('SELECT COALESCE(MAX(id),0) FROM notifications WHERE user_id=?', [$u['id']]), 'items' => $items]);
