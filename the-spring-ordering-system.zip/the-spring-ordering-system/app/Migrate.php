<?php
declare(strict_types=1);

/**
 * Brings an existing install up to date automatically (runs once, then records schema_version).
 * Fresh installs already have these tables from database/schema.sql.
 */
class Migrate {
    const VERSION = 8;
    public static function run(): void {
        try {
            if ((int)Settings::get('schema_version') >= self::VERSION) return;
            $sql = (string)file_get_contents(ROOT . '/database/schema.sql');
            $sql = preg_replace('/^--.*$/m', '', $sql);
            foreach (['passkeys', 'saved_addresses', 'loyalty_ledger', 'password_resets', 'refunds', 'push_subscriptions', 'audit_log', 'message_threads', 'messages'] as $t) {
                if (preg_match('/CREATE TABLE IF NOT EXISTS ' . $t . ' \(.*?\) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;/s', $sql, $m)) db()->exec($m[0]);
            }
            if (!val("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='payments' AND COLUMN_NAME='reversed_amount'")) {
                try { db()->exec('ALTER TABLE payments ADD COLUMN reversed_amount DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER mpesa_request_id'); } catch (Throwable $e) { /* another request got there first */ }
            }
            foreach (['method' => "ENUM('mpesa','cash','mpesa_manual') NOT NULL DEFAULT 'mpesa' AFTER mpesa_request_id", 'received_by' => 'INT UNSIGNED NULL AFTER method',
                      'pct_of_total' => 'DECIMAL(6,2) NULL AFTER received_by', 'balance_after' => 'DECIMAL(10,2) NULL AFTER pct_of_total', 'note' => 'VARCHAR(255) NULL AFTER balance_after'] as $col => $ddl) {
                if (!val("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='payments' AND COLUMN_NAME=?", [$col])) {
                    try { db()->exec("ALTER TABLE payments ADD COLUMN $col $ddl"); } catch (Throwable $e) { /* already added by a parallel request */ }
                }
            }
            // Delivery pins and loyalty discounts on orders.
            foreach (['lat' => 'DECIMAL(9,6) NULL AFTER landmark', 'lng' => 'DECIMAL(9,6) NULL AFTER lat', 'loyalty_points' => 'INT UNSIGNED NOT NULL DEFAULT 0 AFTER delivery_fee',
                      'loyalty_discount' => 'DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER loyalty_points'] as $col => $ddl) {
                if (!val("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME=?", [$col])) {
                    try { db()->exec("ALTER TABLE orders ADD COLUMN $col $ddl"); } catch (Throwable $e) { /* already added by a parallel request */ }
                }
            }
            // Google sign-in: link column on users (password_set = 0 for accounts created through Google).
            foreach (['google_id' => 'VARCHAR(40) NULL AFTER password_hash', 'password_set' => 'TINYINT(1) NOT NULL DEFAULT 1 AFTER google_id'] as $col => $ddl) {
                if (!val("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME=?", [$col])) {
                    try { db()->exec("ALTER TABLE users ADD COLUMN $col $ddl"); } catch (Throwable $e) { /* already added by a parallel request */ }
                }
            }
            if (!val("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND INDEX_NAME='uq_google'")) {
                try { db()->exec('ALTER TABLE users ADD UNIQUE KEY uq_google (google_id)'); } catch (Throwable $e) { /* already added */ }
            }
            db()->exec('UPDATE payments p JOIN orders o ON o.id=p.order_id SET p.pct_of_total = ROUND(p.amount / o.total * 100, 2) WHERE p.pct_of_total IS NULL AND o.total > 0');
            // Replace the old default balance SMS (which said "Paybill ... account ...") when it was never customised.
            q('UPDATE settings SET svalue=? WHERE skey=? AND svalue=?', [Settings::DEFAULTS['sms_tpl_balance'], 'sms_tpl_balance',
                'Hi {name}, a balance of {balance} is due on {restaurant} order {order}. Pay via M-Pesa Paybill {paybill}, account {order}. Thank you.']);
            Settings::set('schema_version', (string)self::VERSION);
            Audit::log('system.migrated', 'Database updated to version ' . self::VERSION, 'system', null, [], []);
        } catch (Throwable $e) { error_log('migrate: ' . $e->getMessage()); }
    }
}
