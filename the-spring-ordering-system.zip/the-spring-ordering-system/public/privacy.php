<?php
require __DIR__ . '/../app/bootstrap.php';
$name = Settings::get('restaurant_name'); $addr = Settings::get('restaurant_address'); $tel = Settings::get('restaurant_phone');
$mail = Settings::get('legal_email') ?: Settings::get('mail_from');
$updated = '19 October 2026';
$sms = Settings::get('sms_provider') === 'smsleopard' ? 'SMS Leopard' : "Africa's Talking";
page_header('Privacy Policy');
?>
<article class="legal">
<h1 class="sp-display">Privacy Policy</h1>
<p class="meta">Last updated: <?= e($updated) ?></p>
<p>This policy explains what personal information <?= e($name) ?> ("we", "us") collects when you use our online ordering website, why we collect it, who we share it with, and the choices you have. We handle personal data in line with the Kenya Data Protection Act, 2019.</p>

<h2>1. Who we are</h2>
<p><?= e($name) ?> is the data controller for the information described here.<?= $addr ? ' Our address is ' . e($addr) . '.' : '' ?><?= $tel ? ' You can call us on ' . e($tel) . '.' : '' ?><?= $mail ? ' Privacy requests can be sent to <a href="mailto:' . e($mail) . '">' . e($mail) . '</a>.' : ' You can also reach us through the Messages page after signing in.' ?></p>

<h2>2. What we collect</h2>
<ul>
 <li><b>Account details:</b> your name, email address, a password and, when you give it to us (at sign-up, at checkout or in My profile), your M-Pesa phone number (stored only as a one-way hash, so nobody at the restaurant can read it).</li>
 <li><b>Google sign-in:</b> if you choose "Sign in with Google" we receive your name, email address and a Google account identifier. We do not receive your Google password and we do not access your Gmail, contacts, calendar or any other Google data.</li>
 <li><b>Fingerprint sign-in (passkeys):</b> if you turn it on, we store a public key for your device, a device name such as "Chrome on Android", and when it was last used. Your fingerprint, face or screen-lock PIN stays on your device. We never receive or store it.</li>
 <li><b>Orders:</b> the items you order, whether it is dine-in or delivery, your chosen time, party size, delivery address and landmark, and any notes you add.</li>
 <li><b>Saved addresses and map pins:</b> if you save a delivery address, we store its label, address, landmark and, only if you tap the pin button, the coordinates your phone gives us at that moment. A pin on an order is shown to our staff and rider for that delivery. We do not track your location at any other time. You can edit or remove saved addresses under Delivery addresses.</li>
 <li><b>Loyalty points:</b> if the rewards programme is running, a record of the points you earn and use on each order.</li>
 <li><b>Payments:</b> the phone number you paid from, the M-Pesa transaction code, amounts, dates and status of each payment or refund. We never see your M-Pesa PIN or balance; you enter your PIN on your own phone.</li>
 <li><b>Messages:</b> what you write to us through the Messages page.</li>
 <li><b>Notifications:</b> in-app notifications, SMS delivery records and, if you turn them on, a push-notification token for your browser or device.</li>
 <li><b>Technical and security data:</b> your IP address, browser type, and records of sign-in attempts and of important actions on the system (an audit trail), used to keep accounts safe.</li>
</ul>

<h2>3. How we use it, and why</h2>
<ul>
 <li>To take, prepare, deliver and charge for your orders, and to issue receipts (this is needed to perform our agreement with you).</li>
 <li>To send you order updates, payment prompts, balance reminders and refunds by in-app notification, push notification and SMS.</li>
 <li>To remember your delivery addresses, let you reorder past orders, and run the rewards programme.</li>
 <li>To answer your messages and resolve problems with an order.</li>
 <li>To prevent fraud and misuse, secure accounts (for example by limiting repeated failed sign-ins) and keep accurate financial records, which we are legally required to do.</li>
 <li>To send reminders you have asked us to set. We do not send marketing messages unless you ask for them, and we do not sell your data.</li>
</ul>

<h2>4. Who we share it with</h2>
<p>We share information only where it is needed to serve you:</p>
<ul>
 <li><b>Safaricom (M-Pesa):</b> your phone number and the payment amount, to send the payment prompt and process refunds.</li>
 <li><b>SMS provider (<?= e($sms) ?>):</b> your phone number and the text of the message.</li>
 <li><b>Google:</b> only if you use Sign in with Google, to confirm who you are.</li>
 <li><b>Email provider:</b> your email address, to deliver password-reset emails.</li>
 <li><b>Our staff and delivery riders:</b> your name, phone number, order and (for delivery) address, so they can prepare and deliver your order.</li>
 <li><b>Hosting and technology providers</b> who run this website for us under confidentiality obligations. Our pages also load fonts and code libraries from Google Fonts and the jsDelivr network, which may see your IP address when your browser fetches them.</li>
 <li><b>Authorities</b>, where the law requires it or to protect our rights, for example in a fraud investigation.</li>
</ul>
<p>Some of these providers process data outside Kenya. Where that happens we rely on them to protect it to a standard comparable to Kenyan law.</p>

<h2>5. Cookies</h2>
<p>We use one essential cookie that keeps you signed in and protects forms from forgery. We do not use advertising or cross-site tracking cookies. If you turn on push notifications, your browser stores a small subscription record so we can reach you.</p>

<h2>6. How long we keep it</h2>
<ul>
 <li>Order and payment records are kept for as long as accounting, tax and legal rules require.</li>
 <li>Your account and messages are kept until you ask us to delete the account.</li>
 <li>Failed sign-in records are cleared automatically after two days, and password-reset links expire after 60 minutes.</li>
 <li>The security audit trail is kept so that changes can be traced and checked for tampering.</li>
</ul>

<h2>7. How we protect it</h2>
<p>The site is served over HTTPS, passwords are hashed, payment and messaging credentials are encrypted at rest, access is limited by role (customer, waiter, admin), and important actions are recorded in a tamper-evident log. No online system is perfectly secure, so please keep your password and your phone safe.</p>

<h2>8. Your rights</h2>
<p>Under the Data Protection Act you may ask us to tell you what we hold about you, correct it, delete it, stop or limit how we use it, or give you a copy. You can update your name and phone number yourself under <i>My profile</i>. To ask for anything else, including deleting your account, contact us using the details above. We may need to keep some records (such as payment records) where the law requires it. If you are unhappy with how we handle your data you can complain to the Office of the Data Protection Commissioner of Kenya (odpc.go.ke).</p>

<h2>9. Children</h2>
<p>This service is meant for adults. We do not knowingly collect personal data from anyone under 18 without a parent's or guardian's involvement.</p>

<h2>10. Changes to this policy</h2>
<p>If we change this policy we will update the date at the top. If a change is significant we will tell you in the app or by SMS or email.</p>

<h2>11. Contact</h2>
<p><?= $mail ? 'Email <a href="mailto:' . e($mail) . '">' . e($mail) . '</a>' : e($name) ?><?= $tel ? ($mail ? ' or call ' : ', phone ') . e($tel) : '' ?>.</p>
<p class="mt-4"><a href="<?= e(url('terms.php')) ?>">Read our Terms of Service</a></p>
</article>
<?php page_footer(); ?>
