<?php
/** The customer's address book: saved delivery addresses with a landmark and an optional map pin. */
require __DIR__ . '/../app/bootstrap.php';
$u = Auth::require('customer'); $uid = (int)$u['id'];
if (is_post()) {
    csrf_check();
    $a = post('action'); $id = (int)post('id'); $err = null;
    if ($a === 'add') $err = Addresses::save($uid, post('label'), post('address'), post('landmark'), post('lat'), post('lng'), post('is_default') === '1');
    elseif ($a === 'update') $err = Addresses::update($id, $uid, post('label'), post('address'), post('landmark'), post('lat'), post('lng'));
    elseif ($a === 'default') Addresses::setDefault($id, $uid);
    elseif ($a === 'delete') Addresses::delete($id, $uid);
    if ($err) flash('danger', $err); else flash('success', ['add' => 'Address saved.', 'update' => 'Address updated.', 'default' => 'Default address changed.', 'delete' => 'Address removed.'][$a] ?? 'Done.');
    redirect('/addresses.php');
}
$list = Addresses::forUser($uid);
$pin = fn($a) => Addresses::pin($a['lat'] ?? '', $a['lng'] ?? '')[0] !== null;
$geo = function (array $a = []) use ($pin): string {
    $has = $pin($a);
    return '<input type="hidden" name="lat" value="' . e((string)($a['lat'] ?? '')) . '"><input type="hidden" name="lng" value="' . e((string)($a['lng'] ?? '')) . '">'
        . '<div class="d-flex flex-wrap align-items-center gap-2 mt-2"><button type="button" class="btn btn-outline-secondary btn-sm d-none" data-geo><i class="bi bi-geo-alt me-1"></i>Pin my current location</button>'
        . '<span class="small" data-geo-status role="status" aria-live="polite">' . ($has ? '<i class="bi bi-geo-alt-fill text-success me-1"></i>Map pin added' : '') . '</span>'
        . '<button type="button" class="btn btn-link btn-sm p-0' . ($has ? '' : ' d-none') . '" data-geo-clear>Remove pin</button></div>';
};
page_header('Delivery addresses', ['active' => 'addresses']);
?>
<div class="row justify-content-center"><div class="col-lg-8">
<h1 class="h3 sp-display mb-1">Delivery addresses</h1>
<p class="text-body-secondary">Save the places you order to, so delivery checkout takes a few taps. Add a landmark and, if you are there now, a map pin so the rider finds you faster.</p>
<?php if (!$list): ?><div class="card card-body text-center py-4 mb-3"><i class="bi bi-geo-alt fs-2 text-body-secondary"></i><p class="mb-0 mt-2">You have no saved addresses yet.</p></div><?php endif; ?>
<div class="vstack gap-3 mb-4">
<?php foreach ($list as $a): ?>
  <div class="card"><div class="card-body">
    <div class="d-flex justify-content-between align-items-start gap-2">
      <div><b class="fs-5 sp-display"><?= e($a['label']) ?></b> <?= $a['is_default'] ? '<span class="badge text-bg-success">Default</span>' : '' ?> <?= $pin($a) ? '<span class="badge text-bg-light border"><i class="bi bi-geo-alt-fill text-success"></i> Pin saved</span>' : '' ?>
        <div><?= e($a['address']) ?></div><?php if ($a['landmark'] !== ''): ?><div class="small text-body-secondary">Landmark: <?= e($a['landmark']) ?></div><?php endif; ?>
        <?php if ($pin($a)): ?><a class="small" target="_blank" rel="noopener" href="<?= e(Addresses::mapLink($a['lat'], $a['lng'])) ?>">View pin on the map</a><?php endif; ?></div>
      <div class="d-flex flex-wrap gap-1 justify-content-end">
        <?php if (!$a['is_default']): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$a['id'] ?>"><button class="btn btn-outline-secondary btn-sm" name="action" value="default">Make default</button></form><?php endif; ?>
        <form method="post" data-confirm="Remove this address?"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$a['id'] ?>"><button class="btn btn-outline-danger btn-sm" name="action" value="delete">Remove</button></form></div></div>
    <details class="mt-2"><summary class="small" style="cursor:pointer">Edit</summary>
      <form method="post" class="mt-2"><?= csrf_field() ?><input type="hidden" name="action" value="update"><input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
        <div class="row g-2"><div class="col-sm-4"><label class="form-label small mb-1">Label</label><input class="form-control form-control-sm" name="label" maxlength="40" value="<?= e($a['label']) ?>" required></div>
          <div class="col-sm-8"><label class="form-label small mb-1">Address</label><input class="form-control form-control-sm" name="address" maxlength="255" value="<?= e($a['address']) ?>" required></div>
          <div class="col-12"><label class="form-label small mb-1">Landmark</label><input class="form-control form-control-sm" name="landmark" maxlength="160" value="<?= e($a['landmark']) ?>" placeholder="Near the blue gate"><?= $geo($a) ?></div></div>
        <button class="btn btn-primary btn-sm mt-2">Save changes</button></form></details>
  </div></div>
<?php endforeach; ?></div>
<?php if (count($list) < Addresses::MAX): ?>
<div class="card"><div class="card-body"><h2 class="h5 sp-display">Add an address</h2>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="add">
    <div class="row g-2"><div class="col-sm-4"><label class="form-label" for="nl">Label</label><input class="form-control" id="nl" name="label" maxlength="40" placeholder="Home, Office..." required></div>
      <div class="col-sm-8"><label class="form-label" for="na">Address</label><input class="form-control" id="na" name="address" maxlength="255" placeholder="Street, building, house number" required></div>
      <div class="col-12"><label class="form-label" for="nm">Landmark (optional)</label><input class="form-control" id="nm" name="landmark" maxlength="160" placeholder="Near the blue gate"><?= $geo() ?>
        <div class="form-text">Standing at the delivery spot now? Tap the pin button so the rider gets your exact location.</div></div>
      <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" name="is_default" id="nd" value="1" <?= $list ? '' : 'checked' ?>><label class="form-check-label" for="nd">Use as my default address</label></div></div></div>
    <button class="btn btn-primary mt-3">Save address</button></form></div></div>
<?php else: ?><p class="text-body-secondary">You have saved the maximum of <?= Addresses::MAX ?> addresses. Remove one to add another.</p><?php endif; ?>
</div></div>
<?php page_footer(['scripts' => ['addresses.js']]); ?>
