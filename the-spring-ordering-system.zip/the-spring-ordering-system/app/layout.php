<?php
declare(strict_types=1);

function unread_count(): int {
    $id = Auth::id();
    return $id ? (int)val('SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0', [$id]) : 0;
}
function cart_count(): int { return array_sum($_SESSION['cart'] ?? []); }

function page_header(string $title, array $o = []): void {
    $u = Auth::user();
    $admin = !empty($o['admin']);
    $active = $o['active'] ?? '';
    $name = Settings::get('restaurant_name');
    ?><!doctype html>
<html lang="en" data-bs-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?= e($title) ?> | <?= e($name) ?></title>
<meta name="theme-color" content="#1F2A12">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,800&family=Figtree:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?= e(url('assets/css/app.css')) ?>?v=6" rel="stylesheet">
<link rel="manifest" href="<?= e(url('manifest.php')) ?>">
<link rel="apple-touch-icon" href="<?= e(url('assets/icons/apple-touch-icon.png')) ?>">
<meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="<?= e(Settings::get('restaurant_name')) ?>">
<script>
(function(){var m=window.matchMedia('(prefers-color-scheme: dark)');function a(){document.documentElement.setAttribute('data-bs-theme',m.matches?'dark':'light')}a();m.addEventListener&&m.addEventListener('change',a)})();
window.SP={base:<?= json_encode(base_path()) ?>,csrf:<?= json_encode(csrf_token()) ?>,uid:<?= (int)Auth::id() ?>,role:<?= json_encode($u['role'] ?? 'guest') ?>,push:<?= json_encode($u && Push::enabled() ? ['key' => Push::publicKey()] : null) ?>};
</script>
</head>
<body class="<?= $admin ? 'is-admin' : 'is-site' ?>">
<?php if ($admin) { admin_nav($u, $active, $title); } else { site_nav($u, $active); } ?>
<main class="<?= $admin ? 'admin-main' : 'container site-main' ?>" id="main">
<?php foreach (flashes() as [$t, $m]) echo '<div class="alert alert-' . e($t) . ' alert-dismissible fade show" role="alert">' . e($m) . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>'; ?>
<?php
}

function site_nav(?array $u, string $active): void {
    $isCust = !$u || $u['role'] === 'customer';
    $link = fn(string $href, string $label, string $key, string $icon, int $n = 0) => '<li class="nav-item"><a class="nav-link' . ($active === $key ? ' active' : '') . '" href="' . e(url($href)) . '"><i class="bi bi-' . $icon . ' me-1"></i>' . $label . ($n ? ' <span class="badge rounded-pill bg-warning text-dark">' . $n . '</span>' : '') . '</a></li>';
    ?>
<header class="sp-top sticky-top"><nav class="navbar navbar-expand-md navbar-dark"><div class="container">
  <a class="navbar-brand sp-logo" href="<?= e(url('/')) ?>"><?= brand_logo() ?><?= e(Settings::get('restaurant_name')) ?></a>
  <div class="d-flex align-items-center gap-2 order-md-3">
    <?php if ($isCust): ?><a class="btn btn-sm sp-icon position-relative" href="<?= e(url('checkout.php')) ?>" aria-label="Your order"><i class="bi bi-bag"></i><span class="badge rounded-pill sp-dot cart-badge<?= cart_count() ? '' : ' d-none' ?>"><?= cart_count() ?></span></a><?php endif; ?>
    <?php if ($u): ?>
      <a class="btn btn-sm sp-icon position-relative" href="<?= e(url('notifications.php')) ?>" aria-label="Notifications"><i class="bi bi-bell"></i><span class="badge rounded-pill sp-dot bell-badge<?= unread_count() ? '' : ' d-none' ?>"><?= unread_count() ?></span></a>
      <div class="dropdown"><button class="btn btn-sm sp-icon fw-bold" data-bs-toggle="dropdown" aria-label="Account"><?= e(mb_substr($u['name'], 0, 1)) ?></button>
        <ul class="dropdown-menu dropdown-menu-end"><li class="dropdown-header"><?= e($u['name']) ?></li>
          <?php if (Auth::isStaff()): ?><li><a class="dropdown-item" href="<?= e(url(Auth::home($u))) ?>">Staff area</a></li><?php endif; ?>
          <li><a class="dropdown-item" href="<?= e(url('profile.php')) ?>">My profile</a></li>
          <?php if ($u['role'] === 'customer'): ?><li><a class="dropdown-item" href="<?= e(url('addresses.php')) ?>">Delivery addresses</a></li><?php endif; ?>
          <li><form method="post" action="<?= e(url('logout.php')) ?>"><?= csrf_field() ?><button class="dropdown-item">Sign out</button></form></li></ul></div>
    <?php else: ?><a class="btn btn-sm btn-lime" href="<?= e(url('login.php')) ?>">Sign in</a><?php endif; ?>
    <button class="navbar-toggler ms-1" type="button" data-bs-toggle="collapse" data-bs-target="#nav" aria-label="Menu"><span class="navbar-toggler-icon"></span></button>
  </div>
  <div class="collapse navbar-collapse" id="nav"><ul class="navbar-nav ms-md-3 me-auto">
    <?= $link('/', 'Menu', 'menu', 'cup-hot') ?>
    <?php if ($u && $u['role'] === 'customer') echo $link('orders.php', 'My orders', 'orders', 'receipt') . $link('reminders.php', 'Reminders', 'reminders', 'alarm') . $link('messages.php', 'Messages', 'messages', 'chat-left-text', Messages::customerUnread((int)$u['id'])) . (Loyalty::enabled() ? $link('loyalty.php', 'Rewards', 'rewards', 'star') : ''); ?>
  </ul></div>
</div></nav><div class="sp-stripe"></div></header>
<?php }

function admin_nav(?array $u, string $active, string $title): void {
    $items = [['index.php', 'Dashboard', 'dash', 'speedometer2', true], ['orders.php', 'Orders', 'orders', 'receipt', false], ['payments.php', 'Payments', 'payments', 'cash-coin', false],
              ['balances.php', 'Balances', 'balances', 'hourglass-split', false], ['menu.php', 'Menu and offers', 'menu', 'egg-fried', true], ['users.php', 'Team and customers', 'users', 'people', true],
              ['sms_log.php', 'SMS log', 'sms', 'chat-dots', true], ['messages.php', 'Messages', 'messages', 'chat-left-text', true], ['loyalty.php', 'Loyalty points', 'loyalty', 'star', true], ['audit.php', 'Audit trail', 'audit', 'journal-text', true], ['settings.php', 'Settings', 'settings', 'gear', true]];
    $msgUnread = Auth::isAdmin() ? Messages::adminUnread() : 0;
    $newOrders = (int)val("SELECT COUNT(*) FROM orders WHERE status='placed'");
    $nav = '';
    foreach ($items as [$f, $l, $k, $i, $adminOnly]) {
        if ($adminOnly && !Auth::isAdmin()) continue;
        $nav .= '<a class="side-link' . ($active === $k ? ' active' : '') . '" href="' . e(url('admin/' . $f)) . '"><i class="bi bi-' . $i . '"></i><span>' . $l . '</span>' . ($k === 'messages' && $msgUnread ? '<span class="badge text-bg-warning ms-auto">' . $msgUnread . '</span>' : '') . ($k === 'orders' && $newOrders ? '<span class="badge text-bg-warning ms-auto">' . $newOrders . '</span>' : '') . '</a>';
    }
    ?>
<header class="sp-top sticky-top admin-top"><div class="d-flex align-items-center gap-2 px-3 py-2">
  <button class="btn sp-icon d-lg-none" data-bs-toggle="offcanvas" data-bs-target="#side" aria-label="Menu"><i class="bi bi-list"></i></button>
  <a class="sp-logo" href="<?= e(url('admin/')) ?>"><?= brand_logo() ?><?= e(Settings::get('restaurant_name')) ?><small class="ms-2 opacity-75 d-none d-sm-inline">Staff</small></a>
  <span class="flex-grow-1"></span>
  <a class="btn btn-sm sp-icon" href="<?= e(url('/')) ?>" title="View customer site"><i class="bi bi-box-arrow-up-right"></i></a>
  <a class="btn btn-sm sp-icon position-relative" href="<?= e(url('notifications.php')) ?>" aria-label="Notifications"><i class="bi bi-bell"></i><span class="badge rounded-pill sp-dot bell-badge<?= unread_count() ? '' : ' d-none' ?>"><?= unread_count() ?></span></a>
  <div class="dropdown"><button class="btn btn-sm sp-icon fw-bold" data-bs-toggle="dropdown" aria-label="Account"><?= e(mb_substr($u['name'], 0, 1)) ?></button>
    <ul class="dropdown-menu dropdown-menu-end"><li class="dropdown-header"><?= e($u['name']) ?> (<?= e($u['role']) ?>)</li>
      <li><a class="dropdown-item" href="<?= e(url('profile.php')) ?>">My profile</a></li>
      <li><form method="post" action="<?= e(url('logout.php')) ?>"><?= csrf_field() ?><button class="dropdown-item">Sign out</button></form></li></ul></div>
</div><div class="sp-stripe"></div></header>
<div class="admin-wrap">
  <aside class="side d-none d-lg-flex flex-column"><?= $nav ?></aside>
  <div class="offcanvas offcanvas-start side-oc" tabindex="-1" id="side"><div class="offcanvas-header"><h5 class="offcanvas-title">Menu</h5><button class="btn-close" data-bs-dismiss="offcanvas"></button></div><div class="offcanvas-body d-flex flex-column"><?= $nav ?></div></div>
  <div class="admin-content">
    <h1 class="h3 mb-3 sp-display"><?= e($title) ?></h1>
<?php }

function page_footer(array $o = []): void {
    $admin = !empty($o['admin']);
    if ($admin) echo "  </div>\n</div>\n";
    echo "</main>\n";
    if (!$admin) echo '<footer class="container py-4 text-center text-body-secondary small site-foot"><div>' . e(Settings::get('restaurant_name')) . (Settings::get('restaurant_phone') ? ' &middot; ' . e(Settings::get('restaurant_phone')) : '') . '</div>'
        . '<nav class="mt-1" aria-label="Legal"><a href="' . e(url('privacy.php')) . '">Privacy Policy</a> &middot; <a href="' . e(url('terms.php')) . '">Terms of Service</a></nav></footer>';
    echo '<div class="toast-container position-fixed top-0 end-0 p-3 sp-toasts" id="toasts"></div>';
    echo '<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>';
    if (!empty($o['chart'])) echo '<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>';
    echo '<script src="' . e(url('assets/js/app.js')) . '?v=6"></script>';
    if (Auth::user() && Push::enabled()) echo '<script src="' . e(url('assets/js/push.js')) . '?v=6"></script>';
    foreach ((array)($o['scripts'] ?? []) as $s) echo '<script src="' . e(url('assets/js/' . $s)) . '?v=4"></script>';
    echo '</body></html>';
}

/** The uploaded logo when there is one, otherwise the built-in water-drop mark. */
function brand_logo(int $h = 32): string {
    $f = Settings::get('logo');
    if ($f !== '' && is_file(PUBLIC_PATH . '/uploads/' . basename($f))) return '<img src="' . e(url('uploads/' . basename($f))) . '" alt="" height="' . $h . '" class="me-2 brand-img" style="height:' . $h . 'px;width:auto;max-width:140px;object-fit:contain">';
    return logo_svg();
}
function logo_svg(): string {
    return '<svg viewBox="0 0 32 32" width="30" height="30" aria-hidden="true" class="me-2"><path d="M16 2c6 7 10 11 10 17a10 10 0 0 1-20 0c0-6 4-10 10-17z" fill="#F1AC18"/><path d="M11 20a5 5 0 0 0 5 5" fill="none" stroke="#1F2A12" stroke-width="2.4" stroke-linecap="round"/></svg>';
}

/** Vertical order tracker. */
function tracker(array $o, array $events): string {
    if ($o['status'] === 'cancelled') return '<div class="alert alert-danger mb-0">This order was cancelled. If you paid a deposit, the restaurant will contact you about the refund.</div>';
    $flow = Orders::flow($o);
    $ci = array_search($o['status'], $flow, true);
    $desc = ['placed' => 'We have your order and your deposit.', 'preparing' => 'The kitchen is cooking your order.',
             'ready' => $o['type'] === 'delivery' ? 'Your order is packed and waiting for our rider.' : 'Your food is ready. Enjoy your meal.',
             'dispatched' => 'Our rider is on the way to you.', 'completed' => ''];
    $h = '<ol class="track">';
    if ($o['status'] === 'awaiting_deposit') $ci = -1;
    foreach ($flow as $i => $s) {
        $cls = $i < $ci ? 'done' : ($i === $ci ? ($s === 'completed' ? 'done' : 'cur') : 'todo');
        $when = isset($events[$s]) ? fmt_dt($events[$s], 'D j M, g:i A') : 'Pending';
        $h .= '<li class="' . $cls . '"><span class="drop"><i class="bi bi-check-lg"></i></span><b>' . e(status_label($s, $o['type'])) . '</b><small class="d-block text-body-secondary">' . e($when) . ($cls === 'cur' && $desc[$s] ? '. ' . e($desc[$s]) : '') . '</small></li>';
    }
    return $h . '</ol>';
}

/**
 * M-Pesa STK push widget used for deposit and balance payments.
 * $choose = let the payer pick how much to pay (deposits: from the minimum up to the full total).
 * $msgUrl = link shown with failures so a customer can message the restaurant (customers only).
 */
function stk_widget(array $o, string $kind, string $phone, string $redirect, string $btn = '', bool $choose = false, string $msgUrl = ''): string {
    $total = (float)$o['total']; $owed = max(0, $total - (float)$o['amount_paid']);
    $min = ceil($kind === 'deposit' ? max(0, (float)$o['deposit_due'] - (float)$o['amount_paid']) : $owed); $max = ceil($owed);
    $choose = $choose && $kind === 'deposit' && $max > $min;
    $chips = [[$min, (int)$o['deposit_pct'] . '% (minimum)']];
    if ($choose) {
        foreach ([50, 75] as $pc) { $a = ceil($total * $pc / 100); if ($a > $min && $a < $max) $chips[] = [$a, $pc . '%']; }
        $chips[] = [$max, 'Pay in full'];
    }
    $pct = fn(float $a) => $total > 0 ? rtrim(rtrim(number_format($a / $total * 100, 1), '0'), '.') : '0';
    $sim = Mpesa::env() === 'simulate';
    ob_start(); ?>
<div class="stk" data-order="<?= (int)$o['id'] ?>" data-kind="<?= e($kind) ?>" data-redirect="<?= e($redirect) ?>" data-total="<?= e($total) ?>" data-min="<?= (int)$min ?>" data-max="<?= (int)$max ?>" data-later="<?= $o['type'] === 'delivery' ? 'on delivery' : 'after eating' ?>" data-msg="<?= e($msgUrl) ?>">
  <?php if ($choose): ?>
  <div class="stk-amounts mb-3">
    <div class="fw-semibold mb-2">How much would you like to pay now?</div>
    <div class="amount-chips">
      <?php foreach ($chips as $k => [$a, $l]): ?><button type="button" class="amount-chip<?= $k === 0 ? ' on' : '' ?>" data-amt="<?= (int)$a ?>"><span><?= e($l) ?></span><b><?= e(money($a)) ?></b></button><?php endforeach; ?>
    </div>
    <label class="form-label small mt-2 mb-1" for="stk-amt-<?= e($kind) ?>">Or enter another amount (<?= e(money($min)) ?> to <?= e(money($max)) ?>)</label>
    <div class="input-group"><span class="input-group-text">KES</span><input class="form-control stk-amount" id="stk-amt-<?= e($kind) ?>" type="number" inputmode="numeric" min="<?= (int)$min ?>" max="<?= (int)$max ?>" step="1" value="<?= (int)$min ?>"><span class="input-group-text stk-pct"><?= e($pct($min)) ?>%</span></div>
    <div class="form-text stk-summary"></div>
  </div>
  <?php endif; ?>
  <label class="form-label fw-semibold" for="stk-phone-<?= e($kind) ?>">M-Pesa phone number</label>
  <input class="form-control form-control-lg stk-phone" id="stk-phone-<?= e($kind) ?>" inputmode="tel" value="<?= e(local_phone($phone)) ?>" placeholder="0712 345 678">
  <button class="btn btn-primary btn-lg w-100 mt-3 stk-send"><i class="bi bi-phone me-1"></i><span class="stk-label"><?= e($btn ?: 'Pay ' . money($min) . ($choose ? ' (' . $pct($min) . '%)' : '') . ' with M-Pesa') ?></span></button>
  <div class="stk-status d-none mt-3" role="status" aria-live="polite"></div>
  <p class="form-text mt-2 mb-0">We send a payment prompt to this number. Enter your M-Pesa PIN on your phone to approve it.<?= $sim ? ' <strong>Simulation mode:</strong> no real money moves, and the payment succeeds automatically (a number ending in 0000 simulates a cancelled prompt).' : '' ?></p>
</div>
<?php return (string)ob_get_clean();
}
