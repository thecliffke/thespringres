<?php
declare(strict_types=1);

/* ---------- config / urls ---------- */
function cfg(string $k, $d = null) { $c = $GLOBALS['cfg'] ?? []; return array_key_exists($k, $c) ? $c[$k] : $d; }
function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function is_https(): bool {
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
}
function base_path(): string {
    static $b = null;
    if ($b !== null) return $b;
    $c = cfg('base_path');
    if ($c !== null) return $b = rtrim((string)$c, '/');
    $doc = !empty($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : false;
    $pub = realpath(PUBLIC_PATH);
    $b = ($doc && $pub && str_starts_with($pub, $doc)) ? str_replace('\\', '/', substr($pub, strlen($doc))) : '';
    return $b = rtrim($b, '/');
}
function url(string $p = ''): string { return base_path() . '/' . ltrim($p, '/'); }
function abs_url(string $p = ''): string {
    $a = cfg('app_url');
    if ($a) return rtrim((string)$a, '/') . '/' . ltrim($p, '/');
    return (is_https() ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . url($p);
}
function redirect(string $p): never {
    header('Location: ' . (preg_match('#^https?://#', $p) ? $p : url($p)));
    exit;
}
function json_out(array $d, int $code = 200): never {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($d, JSON_UNESCAPED_UNICODE);
    exit;
}

/* ---------- formatting ---------- */
function money($n): string { return 'KES ' . number_format((float)$n, 0); }
function fmt_dt(?string $s, string $f = 'D j M, g:i A'): string { return $s ? date($f, strtotime($s)) : ''; }
function norm_phone($p): ?string {
    $d = preg_replace('/\D/', '', (string)$p);
    if (strlen($d) === 10 && $d[0] === '0') $d = '254' . substr($d, 1);
    elseif (strlen($d) === 9 && ($d[0] === '7' || $d[0] === '1')) $d = '254' . $d;
    return preg_match('/^254[71]\d{8}$/', $d) ? $d : null;
}
function mask_phone(string $p): string { return strlen($p) > 8 ? substr($p, 0, 5) . '***' . substr($p, -3) : $p; }
function type_label(string $t): string { return $t === 'delivery' ? 'Delivery' : 'Dine in'; }
function status_label(string $s, string $type = 'dine_in'): string {
    if ($s === 'completed') return $type === 'delivery' ? 'Delivered' : 'Completed';
    return ['awaiting_deposit' => 'Awaiting deposit', 'placed' => 'Placed', 'preparing' => 'Preparing', 'ready' => 'Ready', 'dispatched' => 'On the way', 'cancelled' => 'Cancelled'][$s] ?? $s;
}
function status_badge(array $o): string {
    $cls = ['awaiting_deposit' => 'secondary', 'placed' => 'warning text-dark', 'preparing' => 'info text-dark', 'ready' => 'success',
            'dispatched' => 'primary', 'completed' => 'dark', 'cancelled' => 'danger'][$o['status']] ?? 'secondary';
    return '<span class="badge text-bg-' . explode(' ', $cls)[0] . '">' . e(status_label($o['status'], $o['type'])) . '</span>';
}

/* ---------- csrf + flash ---------- */
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(24));
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">'; }
function csrf_check(): void {
    $t = $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!is_string($t) || !hash_equals(csrf_token(), $t)) {
        http_response_code(419);
        if (str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'json') || str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/')) json_out(['ok' => false, 'message' => 'Session expired. Refresh the page and try again.'], 419);
        exit('Session expired. Go back, refresh the page and try again.');
    }
}
function flash(string $type, string $msg): void { $_SESSION['flash'][] = [$type, $msg]; }
function flashes(): array { $f = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $f; }
function is_post(): bool { return ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST'; }
function post(string $k, string $d = ''): string { return trim((string)($_POST[$k] ?? $d)); }
function get(string $k, string $d = ''): string { return trim((string)($_GET[$k] ?? $d)); }

/* ---------- http ---------- */
function http_request(string $method, string $url, array $headers = [], $body = null, int $timeout = 25): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers, CURLOPT_SSL_VERIFYPEER => true]);
    if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    $res = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $code, 'body' => is_string($res) ? $res : '', 'error' => $err];
}

/* ---------- pagination + csv ---------- */
function page_num(): int { return max(1, (int)($_GET['page'] ?? 1)); }
function pager(int $total, int $page, int $per): string {
    $pages = (int)ceil($total / $per);
    if ($pages <= 1) return '';
    $q = $_GET; $out = '<nav aria-label="Pages"><ul class="pagination pagination-sm flex-wrap mb-0">';
    $link = function (int $p, string $label, bool $active = false, bool $disabled = false) use ($q) {
        $q['page'] = $p;
        return '<li class="page-item' . ($active ? ' active' : '') . ($disabled ? ' disabled' : '') . '"><a class="page-link" href="?' . e(http_build_query($q)) . '">' . $label . '</a></li>';
    };
    $out .= $link(max(1, $page - 1), '&laquo;', false, $page <= 1);
    for ($i = max(1, $page - 2); $i <= min($pages, $page + 2); $i++) $out .= $link($i, (string)$i, $i === $page);
    $out .= $link(min($pages, $page + 1), '&raquo;', false, $page >= $pages);
    return $out . '</ul></nav>';
}
function csv_out(string $name, array $head, array $rows): never {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $name . '-' . date('Ymd-His') . '.csv"');
    $f = fopen('php://output', 'w');
    fwrite($f, "\xEF\xBB\xBF");
    fputcsv($f, $head);
    foreach ($rows as $r) fputcsv($f, $r);
    fclose($f);
    exit;
}

/** LIKE pattern for phone searches: 0712... and 254712... both match; text queries never match every row. */
function phone_term(string $q): string {
    $n = norm_phone($q);
    if ($n) return '%' . $n . '%';
    $d = preg_replace('/\D/', '', $q);
    if ($d !== '' && $d[0] === '0') $d = substr($d, 1);   // 0712... is stored as 254712...
    return strlen($d) >= 3 ? '%' . $d . '%' : '%no-phone-match%';
}

/** The visitor's address. Behind Cloudflare or a proxy set 'ip_header' in config (for example 'HTTP_CF_CONNECTING_IP'). */
function client_ip(): string {
    $h = cfg('ip_header');
    if ($h && !empty($_SERVER[$h])) { $ip = trim(explode(',', (string)$_SERVER[$h])[0]); if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip; }
    return (string)($_SERVER['REMOTE_ADDR'] ?? 'cli');
}

/** 254712345678 -> 0712 345 678 (how people write their number). */
function local_phone($p): string {
    $d = preg_replace('/\D/', '', (string)$p);
    if (strlen($d) === 12 && str_starts_with($d, '254')) $d = '0' . substr($d, 3);
    return strlen($d) === 10 ? substr($d, 0, 4) . ' ' . substr($d, 4, 3) . ' ' . substr($d, 7) : (string)$p;
}
