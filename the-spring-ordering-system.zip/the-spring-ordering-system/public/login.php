<?php
require __DIR__ . '/../app/bootstrap.php';
if (Auth::user()) redirect(Auth::home());
$err = '';
if (is_post()) {
    csrf_check();
    $err = Auth::attempt(post('email'), (string)($_POST['password'] ?? '')) ?? '';
    if (!$err) Auth::afterLogin();
}
page_header('Sign in');
?>
<div class="row justify-content-center"><div class="col-md-6 col-lg-5">
<div class="card shadow-sm"><div class="card-body p-4">
  <h1 class="h3 sp-display mb-1">Welcome back</h1><p class="text-body-secondary">Sign in to order, track and pay.</p>
  <?php if ($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
  <?php if (Passkey::enabled()): ?><button type="button" class="btn btn-primary w-100 btn-lg mb-2 d-none" data-passkey-login><i class="bi bi-fingerprint me-2"></i>Sign in with fingerprint</button><div class="small text-center d-none mb-2" data-passkey-msg role="status" aria-live="polite"></div><?php endif; ?>
  <?php if (Google::enabled()): ?><?= Google::button('signin') ?><p class="form-text text-center mt-2 mb-0">New here? Continuing with Google creates your account, and means you agree to our <a href="<?= e(url('terms.php')) ?>">Terms of Service</a> and <a href="<?= e(url('privacy.php')) ?>">Privacy Policy</a>.</p><?php endif; ?>
  <?php if (Google::enabled() || Passkey::enabled()): ?><div class="or-divider"><span>or sign in with email</span></div><?php endif; ?>
  <form method="post" novalidate><?= csrf_field() ?>
    <label class="form-label" for="email">Email</label><input class="form-control mb-3" id="email" type="email" name="email" value="<?= e(post('email')) ?>" required autocomplete="email" autofocus>
    <div class="d-flex justify-content-between"><label class="form-label" for="pw">Password</label><a class="small" href="<?= e(url('forgot_password.php')) ?>">Forgot password?</a></div><input class="form-control mb-3" id="pw" type="password" name="password" required autocomplete="current-password">
    <button class="btn btn-primary w-100 btn-lg">Sign in</button>
  </form>
  <p class="text-center mt-3 mb-0">New here? <a href="<?= e(url('register.php')) ?>">Create an account</a></p>
</div></div></div></div>
<?php page_footer(['scripts' => ['passkey.js']]); ?>
