(function(){
'use strict';
const SP=window.SP;
document.querySelectorAll('.stk').forEach(box=>{
  const btn=box.querySelector('.stk-send'),ph=box.querySelector('.stk-phone'),out=box.querySelector('.stk-status');
  const amt=box.querySelector('.stk-amount'),chips=box.querySelectorAll('.amount-chip'),label=box.querySelector('.stk-label'),sum=box.querySelector('.stk-summary'),pctEl=box.querySelector('.stk-pct');
  const total=+box.dataset.total,min=+box.dataset.min,max=+box.dataset.max,fmt=n=>'KES '+Math.round(n).toLocaleString('en-US');
  const pct=n=>total>0?(Math.round(n/total*1000)/10).toString().replace(/\.0$/,''):'0';
  let timer=null;
  function refresh(){
    if(!amt)return;
    let v=Math.round(+amt.value||0),bad=v<min||v>max;
    amt.classList.toggle('is-invalid',bad);
    chips.forEach(c=>c.classList.toggle('on',+c.dataset.amt===v));
    if(pctEl)pctEl.textContent=pct(v)+'%';
    if(sum)sum.innerHTML=bad?'<span class="text-danger">Enter an amount from '+fmt(min)+' to '+fmt(max)+'.</span>':(v>=max?'You are paying the whole order. Nothing is left to pay later.':'Balance of <b>'+fmt(total-v)+'</b> is paid '+box.dataset.later+'.');
    if(label)label.textContent=bad?'Choose an amount':'Pay '+fmt(v)+' ('+pct(v)+'%) with M-Pesa';
    btn.disabled=bad;
  }
  if(amt){chips.forEach(c=>c.addEventListener('click',()=>{amt.value=c.dataset.amt;refresh()}));amt.addEventListener('input',refresh);refresh()}
  const show=(html,cls)=>{out.className='stk-status mt-3 '+(cls||'');out.innerHTML=html};
  const fail=msg=>{clearInterval(timer);show('<div class="alert alert-danger mb-2"></div>');out.firstChild.textContent=msg;
    if(box.dataset.msg){const a=document.createElement('p');a.className='small mb-2';a.innerHTML='Paid but see an error? Do not pay again. <a href="'+box.dataset.msg+'">Message us your M-Pesa code</a> and we will confirm it.';out.appendChild(a)}
    btn.disabled=false;if(label)label.textContent='Try again';else btn.innerHTML='<i class="bi bi-arrow-repeat me-1"></i>Try again'};
  btn.addEventListener('click',async()=>{
    btn.disabled=true;
    show('<div class="text-center"><div class="stk-ping"><i class="bi bi-phone"></i></div><b>Sending request&hellip;</b></div>');
    const j=await SP.post('api/stk_push.php',{order_id:box.dataset.order,kind:box.dataset.kind,phone:ph.value,amount:amt?Math.round(+amt.value):''});
    if(!j.ok){fail(j.message||'Could not send the request.');return}
    show('<div class="text-center"><div class="stk-ping"><i class="bi bi-phone"></i></div><b>Check your phone</b><p class="text-body-secondary mb-0">Enter your M-Pesa PIN to approve the payment. This page updates by itself.</p></div>');
    const t0=Date.now();
    clearInterval(timer);
    timer=setInterval(async()=>{
      const s=await SP.get('api/stk_status.php?id='+j.request_id);
      if(!s||!s.status)return;
      if(s.status==='success'){
        clearInterval(timer);
        show('<div class="alert alert-success mb-0"><i class="bi bi-check-circle-fill me-1"></i><b>Payment received.</b> M-Pesa code '+(s.receipt?s.receipt:'will appear on your receipt')+'. Redirecting&hellip;</div>');
        setTimeout(()=>{location.href=box.dataset.redirect||location.href},1400);
      }else if(s.status!=='pending'){fail(s.message||'The payment was not completed.')}
      else if(Date.now()-t0>200000){fail('We did not get a response. If money left your account, contact the restaurant with your M-Pesa code.')}
    },3000);
  });
});
})();
