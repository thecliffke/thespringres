<?php
declare(strict_types=1);

/** Minimal mailer: SMTP (recommended) with PHP mail() as a fallback. Configure in Admin > Settings > Email. */
class Mailer {
    public static function configured(): bool { return Settings::has('smtp_host') || function_exists('mail'); }

    public static function send(string $to, string $subject, string $html, string $text = ''): array {
        $from = Settings::get('mail_from') ?: (Settings::get('smtp_user') && str_contains(Settings::get('smtp_user'), '@') ? Settings::get('smtp_user') : 'noreply@' . preg_replace('/^www\./', '', explode(':', $_SERVER['HTTP_HOST'] ?? 'localhost')[0]));
        $name = Settings::get('mail_from_name') ?: Settings::get('restaurant_name');
        $text = $text !== '' ? $text : trim(html_entity_decode(strip_tags(preg_replace('/<br\s*\/?>|<\/p>/i', "\n", $html))));
        $b = 'sp_' . bin2hex(random_bytes(8));
        $enc = fn(string $s) => preg_match('/[^\x20-\x7E]/', $s) ? '=?UTF-8?B?' . base64_encode($s) . '?=' : $s;
        $headers = ['Date: ' . date('r'), 'From: ' . $enc($name) . ' <' . $from . '>', 'To: <' . $to . '>', 'Subject: ' . $enc($subject), 'Message-ID: <' . bin2hex(random_bytes(10)) . '@' . (explode('@', $from)[1] ?? 'localhost') . '>',
            'MIME-Version: 1.0', 'Content-Type: multipart/alternative; boundary="' . $b . '"'];
        $body = "--$b\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($text)) .
                "--$b\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($html)) . "--$b--\r\n";
        if (Settings::has('smtp_host')) return self::smtp($from, $to, implode("\r\n", $headers), $body);
        $ok = @mail($to, $enc($subject), $body, implode("\r\n", array_slice($headers, 1)), '-f' . $from);
        return $ok ? ['ok' => true, 'message' => 'Sent with PHP mail().'] : ['ok' => false, 'message' => 'PHP mail() failed. Set up SMTP under Settings, Email.'];
    }

    private static function smtp(string $from, string $to, string $headers, string $body): array {
        $host = Settings::get('smtp_host'); $port = (int)Settings::get('smtp_port') ?: 587; $sec = Settings::get('smtp_secure');
        $fp = @stream_socket_client(($sec === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port, $en, $es, 15);
        if (!$fp) return ['ok' => false, 'message' => "Could not connect to $host:$port ($es)."];
        stream_set_timeout($fp, 20);
        $read = function () use ($fp) { $r = ''; while (($l = fgets($fp, 1024)) !== false) { $r .= $l; if (strlen($l) < 4 || $l[3] === ' ') break; } return $r; };
        $cmd = function (string $c, array $ok) use ($fp, $read) { if ($c !== '') fwrite($fp, $c . "\r\n"); $r = $read(); return in_array((int)substr($r, 0, 3), $ok, true) ? null : trim($r); };
        $ehlo = explode(':', $_SERVER['HTTP_HOST'] ?? 'localhost')[0];
        try {
            if ($e = $cmd('', [220])) throw new RuntimeException($e);
            if ($e = $cmd("EHLO $ehlo", [250])) throw new RuntimeException($e);
            if ($sec === 'tls') {
                if ($e = $cmd('STARTTLS', [220])) throw new RuntimeException($e);
                if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new RuntimeException('TLS handshake failed.');
                if ($e = $cmd("EHLO $ehlo", [250])) throw new RuntimeException($e);
            }
            if (Settings::get('smtp_user') !== '') {
                if ($e = $cmd('AUTH LOGIN', [334])) throw new RuntimeException($e);
                if ($e = $cmd(base64_encode(Settings::get('smtp_user')), [334])) throw new RuntimeException($e);
                if ($e = $cmd(base64_encode(Settings::get('smtp_pass')), [235])) throw new RuntimeException('Login failed: ' . $e);
            }
            if ($e = $cmd("MAIL FROM:<$from>", [250])) throw new RuntimeException($e);
            if ($e = $cmd("RCPT TO:<$to>", [250, 251])) throw new RuntimeException($e);
            if ($e = $cmd('DATA', [354])) throw new RuntimeException($e);
            fwrite($fp, preg_replace('/^\./m', '..', $headers . "\r\n\r\n" . $body) . "\r\n.\r\n");
            if ($e = $cmd('', [250])) throw new RuntimeException($e);
            $cmd('QUIT', [221, 250]); fclose($fp);
            return ['ok' => true, 'message' => 'Email sent.'];
        } catch (Throwable $e) { @fclose($fp); return ['ok' => false, 'message' => 'Email failed: ' . mb_substr($e->getMessage(), 0, 180)]; }
    }
}
