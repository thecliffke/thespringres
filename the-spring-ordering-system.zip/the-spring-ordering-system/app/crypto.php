<?php
declare(strict_types=1);

/** Encrypts saved API secrets (AES-256-GCM) using config 'app_key'. */
class Crypto {
    private static function key(): string { return hash('sha256', (string)cfg('app_key', 'change-me'), true); }
    public static function enc(string $plain): string {
        if ($plain === '') return '';
        $iv = random_bytes(12);
        $tag = '';
        $c = openssl_encrypt($plain, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag);
        return 'v1:' . base64_encode($iv . $tag . $c);
    }
    public static function dec(string $blob): string {
        if ($blob === '' || !str_starts_with($blob, 'v1:')) return $blob;
        $raw = base64_decode(substr($blob, 3), true);
        if ($raw === false || strlen($raw) < 29) return '';
        $p = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
        return $p === false ? '' : $p;
    }
}
