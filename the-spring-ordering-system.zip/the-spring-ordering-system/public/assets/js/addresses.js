/* "Pin my current location": fills the hidden lat/lng fields of the form it sits in. Used by checkout.php and addresses.php. */
(function () {
  'use strict';
  document.addEventListener('DOMContentLoaded', function () {
    var supported = 'geolocation' in navigator;
    document.querySelectorAll('[data-geo]').forEach(function (btn) {
      if (!supported) return;
      btn.classList.remove('d-none');
      var form = btn.closest('form'), box = btn.parentElement;
      var lat = form.querySelector('[name=lat]'), lng = form.querySelector('[name=lng]');
      var status = box.querySelector('[data-geo-status]'), clear = box.querySelector('[data-geo-clear]');
      function say(html, bad) { if (status) { status.innerHTML = html; status.classList.toggle('text-danger', !!bad); } }
      function changed() { form.dispatchEvent(new Event('pinchange')); }
      btn.addEventListener('click', function () {
        btn.disabled = true; say('Finding your location...');
        navigator.geolocation.getCurrentPosition(function (pos) {
          lat.value = pos.coords.latitude.toFixed(6); lng.value = pos.coords.longitude.toFixed(6);
          var acc = Math.round(pos.coords.accuracy || 0);
          say('<i class="bi bi-geo-alt-fill text-success me-1"></i>Map pin added' + (acc ? ' (within about ' + acc + ' m)' : ''));
          if (clear) clear.classList.remove('d-none'); btn.disabled = false; changed();
        }, function (err) {
          btn.disabled = false;
          say(err && err.code === 1 ? 'Location is blocked. Allow it in your browser settings, or just type the address and a landmark.' : 'We could not get your location. Type the address and a landmark instead.', true);
        }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 });
      });
      if (clear) clear.addEventListener('click', function () { lat.value = ''; lng.value = ''; say(''); clear.classList.add('d-none'); changed(); });
    });
  });
})();
