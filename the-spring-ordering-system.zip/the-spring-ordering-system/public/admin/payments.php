<?php
require __DIR__ . '/_guard.php';
$tab = in_array(get('tab'), ['requests', 'refunds'], true) ? get('tab') : 'payments';
$qv = get('q'); $from = get('from'); $to = get('to'); $per = 25; $pg = page_num();
$ph = $qv !== '' ? norm_phone($qv) : null;

if ($tab === 'payments') {
    $kind = in_array(get('kind'), ['deposit', 'balance'], true) ? get('kind') : '';
    $method = in_array(get('method'), ['mpesa', 'cash', 'mpesa_manual'], true) ? get('method') : '';
    $where = ['1=1']; $p = [];
    if ($qv !== '') {
        $c = 'p.receipt_no LIKE ? OR p.mpesa_receipt LIKE ? OR p.phone LIKE ? OR o.order_no LIKE ? OR o.customer_name LIKE ?';
        array_push($p, "%$qv%", "%$qv%", phone_term($qv), "%$qv%", "%$qv%");
        if ($ph) { $c .= ' OR p.phone = ?'; $p[] = $ph; }
        if (is_numeric(str_replace(',', '', $qv))) { $c .= ' OR p.amount = ?'; $p[] = (float)str_replace(',', '', $qv); }
        $where[] = "($c)";
    }
    if ($kind) { $where[] = 'p.kind=?'; $p[] = $kind; }
    if ($method) { $where[] = 'p.method=?'; $p[] = $method; }
    if ($from !== '') { $where[] = 'DATE(p.paid_at) >= ?'; $p[] = $from; }
    if ($to !== '') { $where[] = 'DATE(p.paid_at) <= ?'; $p[] = $to; }
    $W = implode(' AND ', $where);
    $base = "FROM payments p JOIN orders o ON o.id=p.order_id WHERE $W";
    if (get('export') === '1') {
        $r = rows("SELECT p.receipt_no,p.paid_at,o.order_no,o.customer_name,p.phone,p.kind,p.method,p.amount,p.pct_of_total,p.balance_after,p.mpesa_receipt,p.note $base ORDER BY p.id DESC", $p);
        Audit::log('export.payments', 'Exported ' . count($r) . ' payment(s) to CSV' . ($qv !== '' ? ' (search: ' . $qv . ')' : ''), 'export', null, ['rows' => count($r), 'search' => $qv, 'from' => $from, 'to' => $to]);
        csv_out('payments', ['Receipt', 'Paid at', 'Order', 'Customer', 'Phone', 'Type', 'Method', 'Amount', '% of order total', 'Balance after', 'M-Pesa code', 'Note'], array_map('array_values', $r));
    }
    $total = (int)val("SELECT COUNT(*) $base", $p); $sum = (float)val("SELECT COALESCE(SUM(p.amount),0) $base", $p);
    $list = rows("SELECT p.*, o.order_no, o.customer_name $base ORDER BY p.id DESC LIMIT $per OFFSET " . (($pg - 1) * $per), $p);
} elseif ($tab === 'refunds') {
    $st = in_array(get('status'), ['pending', 'success', 'failed'], true) ? get('status') : '';
    $where = ['1=1']; $p = [];
    if ($qv !== '') {
        $c = 'o.order_no LIKE ? OR o.customer_name LIKE ? OR f.reason LIKE ? OR f.original_receipt LIKE ? OR f.reversal_ref LIKE ? OR p.receipt_no LIKE ? OR o.phone LIKE ?';
        array_push($p, "%$qv%", "%$qv%", "%$qv%", "%$qv%", "%$qv%", "%$qv%", phone_term($qv));
        $where[] = "($c)";
    }
    if ($st) { $where[] = 'f.status=?'; $p[] = $st; }
    if ($from !== '') { $where[] = 'DATE(f.created_at) >= ?'; $p[] = $from; }
    if ($to !== '') { $where[] = 'DATE(f.created_at) <= ?'; $p[] = $to; }
    $W = implode(' AND ', $where);
    $base = "FROM refunds f JOIN orders o ON o.id=f.order_id JOIN payments p ON p.id=f.payment_id WHERE $W";
    $total = (int)val("SELECT COUNT(*) $base", $p); $sum = (float)val("SELECT COALESCE(SUM(f.amount),0) FROM refunds f JOIN orders o ON o.id=f.order_id JOIN payments p ON p.id=f.payment_id WHERE $W AND f.status='success'", $p);
    $list = rows("SELECT f.*, o.order_no, o.customer_name, o.phone, p.receipt_no $base ORDER BY f.id DESC LIMIT $per OFFSET " . (($pg - 1) * $per), $p);
} else {
    $st = in_array(get('status'), ['pending', 'success', 'failed', 'cancelled', 'timeout'], true) ? get('status') : '';
    $where = ['1=1']; $p = [];
    if ($qv !== '') {
        $c = 'r.phone LIKE ? OR r.mpesa_receipt LIKE ? OR r.checkout_request_id LIKE ? OR r.result_desc LIKE ? OR o.order_no LIKE ? OR o.customer_name LIKE ?';
        array_push($p, phone_term($qv), "%$qv%", "%$qv%", "%$qv%", "%$qv%", "%$qv%");
        if ($ph) { $c .= ' OR r.phone = ?'; $p[] = $ph; }
        $where[] = "($c)";
    }
    if ($st) { $where[] = 'r.status=?'; $p[] = $st; }
    if ($from !== '') { $where[] = 'DATE(r.created_at) >= ?'; $p[] = $from; }
    if ($to !== '') { $where[] = 'DATE(r.created_at) <= ?'; $p[] = $to; }
    $W = implode(' AND ', $where);
    $base = "FROM mpesa_requests r JOIN orders o ON o.id=r.order_id WHERE $W";
    $total = (int)val("SELECT COUNT(*) $base", $p); $sum = 0;
    $list = rows("SELECT r.*, o.order_no, o.customer_name $base ORDER BY r.id DESC LIMIT $per OFFSET " . (($pg - 1) * $per), $p);
}
page_header('Payments', ['admin' => true, 'active' => 'payments']);
?>
<ul class="nav nav-tabs mb-3"><li class="nav-item"><a class="nav-link <?= $tab === 'payments' ? 'active' : '' ?>" href="?tab=payments">Received payments</a></li>
<li class="nav-item"><a class="nav-link <?= $tab === 'requests' ? 'active' : '' ?>" href="?tab=requests">All M-Pesa requests</a></li>
<li class="nav-item"><a class="nav-link <?= $tab === 'refunds' ? 'active' : '' ?>" href="?tab=refunds">Refunds</a></li></ul>
<form class="row g-2 mb-3" method="get"><input type="hidden" name="tab" value="<?= e($tab) ?>">
  <div class="col-12 col-lg"><input class="form-control" type="search" name="q" value="<?= e($qv) ?>" placeholder="<?= $tab === 'payments' ? 'Search M-Pesa code, receipt no, phone, order no, customer or amount' : 'Search phone, M-Pesa code, order no, customer or failure reason' ?>" autofocus></div>
  <div class="col-6 col-lg-2"><?php if ($tab === 'payments'): ?><select class="form-select" name="kind"><option value="">All types</option><option value="deposit" <?= $kind === 'deposit' ? 'selected' : '' ?>>Deposits</option><option value="balance" <?= $kind === 'balance' ? 'selected' : '' ?>>Balances</option></select></div>
  <div class="col-6 col-lg-2"><select class="form-select" name="method" aria-label="Method"><option value="">Any method</option><option value="mpesa" <?= $method === 'mpesa' ? 'selected' : '' ?>>M-Pesa</option><option value="cash" <?= $method === 'cash' ? 'selected' : '' ?>>Cash</option><option value="mpesa_manual" <?= $method === 'mpesa_manual' ? 'selected' : '' ?>>Confirmed manually</option></select>
    <?php else: ?><select class="form-select" name="status"><option value="">Any status</option><?php foreach ($tab === 'refunds' ? ['pending', 'success', 'failed'] : ['pending', 'success', 'failed', 'cancelled', 'timeout'] as $s) echo '<option ' . ($st === $s ? 'selected' : '') . '>' . $s . '</option>'; ?></select><?php endif; ?></div>
  <div class="col-6 col-lg-auto"><input class="form-control" type="date" name="from" value="<?= e($from) ?>" title="From"></div>
  <div class="col-6 col-lg-auto"><input class="form-control" type="date" name="to" value="<?= e($to) ?>" title="To"></div>
  <div class="col-6 col-lg-auto d-flex gap-2"><button class="btn btn-primary flex-grow-1">Search</button><a class="btn btn-outline-secondary" href="?tab=<?= e($tab) ?>">Clear</a></div></form>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-2 gap-2"><div class="text-body-secondary"><?= $total ?> result<?= $total === 1 ? '' : 's' ?><?= $tab === 'payments' ? ', total <b class="text-body">' . money($sum) . '</b>' : ($tab === 'refunds' ? ', refunded <b class="text-body">' . money($sum) . '</b>' : '') ?></div>
  <?php if ($tab === 'payments'): ?><a class="btn btn-outline-primary btn-sm" href="?<?= e(http_build_query(array_merge($_GET, ['export' => 1]))) ?>"><i class="bi bi-download me-1"></i>Export CSV</a><?php endif; ?></div>
<div class="card"><div class="table-responsive"><table class="table align-middle mb-0">
<?php if ($tab === 'payments'): ?>
<thead><tr><th>Receipt</th><th>Paid</th><th>Order</th><th>Customer</th><th>Phone</th><th>Type</th><th>Method</th><th>M-Pesa code</th><th class="text-end">Paid</th><th></th></tr></thead><tbody>
<?php if (!$list) echo '<tr><td colspan="9" class="text-center text-body-secondary py-4">No payments found. Try the "All M-Pesa requests" tab to see attempts that did not complete.</td></tr>'; ?>
<?php foreach ($list as $r): ?><tr><td class="fw-semibold"><?= e($r['receipt_no']) ?></td><td class="text-nowrap"><?= e(fmt_dt($r['paid_at'], 'j M Y, g:i A')) ?></td><td><a href="order.php?id=<?= (int)$r['order_id'] ?>"><?= e($r['order_no']) ?></a></td><td><?= e($r['customer_name']) ?></td><td>+<?= e($r['phone']) ?></td>
 <td><span class="badge text-bg-<?= $r['kind'] === 'deposit' ? 'info' : 'success' ?>"><?= $r['kind'] === 'deposit' ? 'Deposit' : 'Balance' ?></span></td><td><?= $r['method'] === 'cash' ? '<span class="badge text-bg-success">Cash</span>' : ($r['method'] === 'mpesa_manual' ? '<span class="badge text-bg-warning">M-Pesa, manual</span>' : '<span class="badge text-bg-light border">M-Pesa</span>') ?></td><td><code><?= e($r['method'] === 'cash' ? '-' : ($r['mpesa_receipt'] ?: 'pending')) ?></code></td><td class="text-end fw-bold"><?= money($r['amount']) ?><?= $r['pct_of_total'] !== null ? '<div class="small fw-normal text-body-secondary">' . rtrim(rtrim(number_format((float)$r['pct_of_total'], 1), '0'), '.') . '% of order</div>' : '' ?><?= $r['reversed_amount'] > 0 ? '<div><span class="badge text-bg-danger">Refunded ' . money($r['reversed_amount']) . '</span></div>' : '' ?></td><td><a class="btn btn-outline-secondary btn-sm" href="../receipt.php?id=<?= (int)$r['id'] ?>">Receipt</a> <a class="btn btn-outline-secondary btn-sm" href="../order_receipt.php?order=<?= (int)$r['order_id'] ?>" title="Combined receipt for the whole order"><i class="bi bi-files"></i></a></td></tr><?php endforeach; ?>
<?php elseif ($tab === 'refunds'): ?>
<thead><tr><th>Requested</th><th>Order</th><th>Customer</th><th>Original payment</th><th>Reason</th><th class="text-end">Amount</th><th>Status</th><th>Reference</th></tr></thead><tbody>
<?php if (!$list) echo '<tr><td colspan="8" class="text-center text-body-secondary py-4">No refunds yet.</td></tr>'; ?>
<?php foreach ($list as $r): ?><tr><td class="text-nowrap"><?= e(fmt_dt($r['created_at'], 'j M Y, g:i A')) ?></td><td><a href="order.php?id=<?= (int)$r['order_id'] ?>"><?= e($r['order_no']) ?></a></td><td><?= e($r['customer_name']) ?><div class="small">+<?= e($r['phone']) ?></div></td><td><?= e($r['receipt_no']) ?><div class="small"><code><?= e($r['original_receipt'] ?: '-') ?></code></div></td><td class="small"><?= e($r['reason']) ?></td><td class="text-end fw-bold"><?= money($r['amount']) ?></td>
 <td><span class="badge text-bg-<?= ['success' => 'success', 'pending' => 'warning', 'failed' => 'danger'][$r['status']] ?>"><?= e($r['status']) ?></span><div class="small text-body-secondary"><?= e($r['method'] === 'manual' ? 'manual' : 'reversal') ?></div></td><td class="small"><code><?= e($r['reversal_ref'] ?: '-') ?></code><div class="text-body-secondary"><?= $r['status'] !== 'success' ? e($r['result_desc']) : '' ?></div></td></tr><?php endforeach; ?>
<?php else: ?>
<thead><tr><th>Requested</th><th>Order</th><th>Customer</th><th>Phone</th><th>Type</th><th class="text-end">Amount</th><th>Status</th><th>M-Pesa code</th><th>Detail</th><th></th></tr></thead><tbody>
<?php if (!$list) echo '<tr><td colspan="9" class="text-center text-body-secondary py-4">No requests found.</td></tr>'; ?>
<?php foreach ($list as $r): ?><tr><td class="text-nowrap"><?= e(fmt_dt($r['created_at'], 'j M Y, g:i A')) ?></td><td><a href="order.php?id=<?= (int)$r['order_id'] ?>"><?= e($r['order_no']) ?></a></td><td><?= e($r['customer_name']) ?></td><td>+<?= e($r['phone']) ?></td><td><?= $r['kind'] === 'deposit' ? 'Deposit' : 'Balance' ?></td><td class="text-end"><?= money($r['amount']) ?></td>
 <td><span class="badge text-bg-<?= ['success' => 'success', 'pending' => 'warning', 'failed' => 'danger', 'cancelled' => 'secondary', 'timeout' => 'secondary'][$r['status']] ?>"><?= e($r['status']) ?></span></td><td><code><?= e($r['mpesa_receipt'] ?: '-') ?></code></td><td class="small text-body-secondary"><?= e($r['status'] === 'success' ? $r['result_desc'] : Mpesa::describe($r['result_code'] !== null ? (int)$r['result_code'] : ($r['status'] === 'timeout' ? 1037 : null), (string)$r['result_desc'])) ?></td><td class="text-end text-nowrap"><?php if ($r['status'] !== 'success'): ?><a class="btn btn-outline-warning btn-sm" href="order.php?id=<?= (int)$r['order_id'] ?>#payments" title="Re-check with Safaricom or confirm manually">Resolve</a><?php endif; ?></td></tr><?php endforeach; ?>
<?php endif; ?></tbody></table></div></div>
<div class="mt-3"><?= pager($total, $pg, $per) ?></div>
<?php page_footer(['admin' => true]); ?>
