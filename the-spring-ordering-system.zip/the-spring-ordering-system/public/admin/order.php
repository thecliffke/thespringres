<?php
require __DIR__ . '/_guard.php';
$o = Orders::find((int)get('id'));
if (!$o) { flash('danger', 'Order not found.'); redirect('/admin/orders.php'); }
$id = (int)$o['id'];
Refunds::pollSimulated($id);
$o = Orders::find($id);
if (is_post()) {
    csrf_check();
    try {
        $a = post('action');
        if ($a === 'advance') { $n = Orders::next($o); if (!$n) throw new RuntimeException('Nothing to advance.'); Orders::setStatus($id, $n, (int)$ME['id']); flash('success', 'Status updated and the customer was notified.'); }
        elseif ($a === 'cancel') { Orders::setStatus($id, 'cancelled', (int)$ME['id']); flash('success', 'Order cancelled. Refund any deposit manually via M-Pesa.'); }
        elseif ($a === 'remind_deposit') { $r = Orders::remindDeposit($o); flash($r['ok'] ? 'success' : 'warning', $r['message']); }
        elseif ($a === 'cash') { $r = Orders::recordCash($id, (float)str_replace(',', '', post('amount')), (int)$ME['id'], post('note')); flash($r['ok'] ? 'success' : 'danger', $r['message']); }
        elseif ($a === 'confirm_mpesa') {
            if (!Auth::isAdmin()) throw new RuntimeException('Only an admin can confirm an M-Pesa payment manually.');
            $r = Mpesa::confirmManually($id, (int)post('request_id') ?: null, post('receipt'), (float)str_replace(',', '', post('amount')), post('phone'), (int)$ME['id'], post('note'));
            flash($r['ok'] ? 'success' : 'danger', $r['message']);
        }
        elseif ($a === 'recheck') {
            $rq = row('SELECT * FROM mpesa_requests WHERE id=? AND order_id=?', [(int)post('request_id'), $id]);
            if (!$rq) throw new RuntimeException('Request not found.');
            if (Mpesa::env() === 'simulate' || !Mpesa::configured()) flash('info', 'Re-checking needs the sandbox or production connection (Settings, M-Pesa).');
            else { try { $okr = Mpesa::reconcileRequest($rq); flash($okr ? 'success' : 'info', $okr ? 'Safaricom confirms this payment went through, and it has been recorded.' : 'Safaricom does not show a successful payment for this request (yet).'); } catch (Throwable $e) { flash('danger', 'Could not reach Safaricom: ' . $e->getMessage()); } }
        }
        elseif ($a === 'refund' || $a === 'refund_fail') {
            if (!Auth::isAdmin()) throw new RuntimeException('Only an admin can refund deposits.');
            if ($a === 'refund_fail') { Refunds::markFailed((int)post('refund_id')); flash('success', 'Marked as failed. You can try again.'); }
            else {
                $reason = post('reason') === 'Other' ? post('reason_other') : post('reason');
                $r = Refunds::request((int)post('payment_id'), (float)str_replace(',', '', post('amount')), $reason, isset($_POST['cancel_order']), (int)$ME['id'], post('method') === 'manual' ? 'manual' : 'api', post('manual_ref'));
                flash($r['ok'] ? 'success' : 'danger', $r['message']);
            }
        }
        elseif ($a === 'sms_balance') {
            $bal = Orders::balance($o); if ($bal < 1) throw new RuntimeException('There is no balance on this order.');
            $msg = Sms::render('sms_tpl_balance', ['name' => explode(' ', $o['customer_name'])[0], 'order' => $o['order_no'], 'restaurant' => Settings::get('restaurant_name'), 'balance' => money($bal), 'paid' => money($o['amount_paid']), 'paybill' => Settings::payNumber() ?: '(not set)', 'till' => Settings::payNumber() ?: '(not set)', 'pay_details' => Settings::payDetails($o['order_no'])]);
            $r = Sms::send($o['phone'], $msg, 'balance', (int)$o['customer_id']); Audit::log('order.balance_sms', 'Balance reminder SMS ' . ($r['ok'] ? 'sent' : 'failed') . ' for ' . $o['order_no'], 'order', $id); flash($r['ok'] ? 'success' : 'danger', $r['message']);
        }
    } catch (RuntimeException $e) { flash('danger', $e->getMessage()); }
    redirect('/admin/order.php?id=' . $id);
}
$items = Orders::items($id); $events = Orders::events($id); $bal = Orders::balance($o); $n = Orders::next($o);
$pays = rows('SELECT * FROM payments WHERE order_id=? ORDER BY id', [$id]);
$reqs = rows('SELECT * FROM mpesa_requests WHERE order_id=? ORDER BY id DESC', [$id]);
$refunds = Refunds::forOrder($id); $hasPending = (bool)array_filter($refunds, fn($r) => $r['status'] === 'pending');
$byName = $o['handled_by'] ? val('SELECT name FROM users WHERE id=?', [$o['handled_by']]) : null;
page_header('Order ' . $o['order_no'], ['admin' => true, 'active' => 'orders']);
?>
<div data-order-watch="<?= $id ?>" data-status="<?= e($o['status']) ?>" data-paid="<?= e($o['amount_paid']) ?>">
<div class="d-flex flex-wrap align-items-center gap-2 mb-3"><?= status_badge($o) ?><span class="badge text-bg-light border"><?= e(type_label($o['type'])) ?></span>
  <span class="text-body-secondary"><?= $o['asap'] ? 'As soon as possible' : e(fmt_dt($o['scheduled_at'], 'D j M Y, g:i A')) ?></span><span class="flex-grow-1"></span>
  <?php if ($n && $o['status'] !== 'awaiting_deposit'): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="advance"><button class="btn btn-primary"><?= e(Orders::nextLabel($o, $n)) ?></button></form><?php endif; ?>
  <?php if (in_array($o['status'], ['awaiting_deposit', 'placed', 'preparing'], true)): ?><form method="post" data-confirm="Cancel this order? Any deposit must be refunded manually."><?= csrf_field() ?><input type="hidden" name="action" value="cancel"><button class="btn btn-outline-danger">Cancel order</button></form><?php endif; ?></div>
<div class="row g-3">
 <div class="col-lg-7 vstack gap-3">
  <div class="card"><div class="card-body"><h2 class="h5 sp-display">Items</h2>
    <?php foreach ($items as $i) echo '<div class="d-flex justify-content-between py-1"><span><b>' . (int)$i['qty'] . '</b> x ' . e($i['name']) . '</span><span>' . money($i['qty'] * $i['unit_price']) . '</span></div>'; ?>
    <?php if ($o['delivery_fee'] > 0) echo '<div class="d-flex justify-content-between py-1"><span>Delivery fee</span><span>' . money($o['delivery_fee']) . '</span></div>'; ?>
    <?php if ($o['loyalty_discount'] > 0) echo '<div class="d-flex justify-content-between py-1 text-success"><span>Loyalty discount (' . number_format((int)$o['loyalty_points']) . ' points)</span><span>- ' . money($o['loyalty_discount']) . '</span></div>'; ?>
    <div class="d-flex justify-content-between fw-bold border-top mt-2 pt-2"><span>Total</span><span><?= money($o['total']) ?></span></div>
    <?php if ($o['notes']) echo '<div class="alert alert-warning mt-3 mb-0 py-2">Kitchen note: ' . e($o['notes']) . '</div>'; ?></div></div>
  <div class="card"><div class="card-body"><h2 class="h5 sp-display mb-3">Progress</h2><?= tracker($o, $events) ?><?php if ($byName) echo '<p class="small text-body-secondary mb-0">Last handled by ' . e($byName) . '</p>'; ?></div></div>
 </div>
 <div class="col-lg-5 vstack gap-3">
  <div class="card"><div class="card-body"><h2 class="h5 sp-display">Customer</h2><div class="fw-semibold"><?= e($o['customer_name']) ?></div><a href="tel:+<?= e($o['phone']) ?>">+<?= e($o['phone']) ?></a>
    <?php if ($o['type'] === 'delivery'): ?><div class="mt-2"><i class="bi bi-geo-alt me-1"></i><?= e($o['address']) ?><?= $o['landmark'] ? ', ' . e($o['landmark']) : '' ?><?php if ($o['lat'] !== null): ?><div class="mt-1"><a class="btn btn-outline-success btn-sm" target="_blank" rel="noopener" href="<?= e(Addresses::mapLink($o['lat'], $o['lng'])) ?>"><i class="bi bi-pin-map me-1"></i>Open the customer's pin in Maps</a></div><?php endif; ?></div><?php else: ?><div class="mt-2"><i class="bi bi-people me-1"></i>Table for <?= (int)$o['party_size'] ?></div><?php endif; ?>
    <?php if (Auth::isAdmin()): $th = rows('SELECT id, subject, admin_unread FROM message_threads WHERE order_id=? ORDER BY last_message_at DESC', [$id]); foreach ($th as $x) echo '<div class="mt-2"><a href="thread.php?id=' . (int)$x['id'] . '"><i class="bi bi-chat-dots me-1"></i>' . e($x['subject']) . ($x['admin_unread'] ? ' <span class="badge text-bg-warning">' . (int)$x['admin_unread'] . ' new</span>' : '') . '</a></div>'; ?>
      <details class="mt-2"><summary class="small text-body-secondary" style="cursor:pointer">Message the customer</summary>
        <form method="post" action="messages.php" class="mt-2"><?= csrf_field() ?><input type="hidden" name="action" value="start"><input type="hidden" name="customer_id" value="<?= (int)$o['customer_id'] ?>"><input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
          <input class="form-control form-control-sm mb-1" name="subject" placeholder="Subject" value="About order <?= e($o['order_no']) ?>" maxlength="160">
          <textarea class="form-control form-control-sm" name="body" rows="3" required maxlength="2000" placeholder="Your message"></textarea><button class="btn btn-primary btn-sm mt-2">Send</button></form></details>
    <?php endif; ?></div></div>
  <div class="card" id="pay"><div class="card-body"><h2 class="h5 sp-display">Payment</h2>
    <div class="d-flex justify-content-between"><span>Total</span><span><?= money($o['total']) ?></span></div>
    <div class="d-flex justify-content-between"><span>Paid (<?= (int)$o['deposit_pct'] ?>% deposit = <?= money($o['deposit_due']) ?>)</span><span><?= money($o['amount_paid']) ?></span></div>
    <div class="d-flex justify-content-between fw-bold fs-5 border-top mt-2 pt-2"><span>Balance</span><span class="<?= $bal > 0 && $o['status'] !== 'cancelled' ? 'text-danger' : 'text-success' ?>"><?= money($o['status'] === 'cancelled' ? 0 : $bal) ?></span></div>
    <?php if ($bal >= 1 && !in_array($o['status'], ['awaiting_deposit', 'cancelled'], true)): ?>
      <hr><h3 class="h6">Request balance by M-Pesa</h3><?= stk_widget($o, 'balance', $o['phone'], url('admin/order.php?id=' . $id), 'Send STK push for ' . money($bal)) ?>
      <form method="post" class="mt-2"><?= csrf_field() ?><input type="hidden" name="action" value="sms_balance"><button class="btn btn-outline-secondary btn-sm"><i class="bi bi-chat-dots me-1"></i>Send balance SMS reminder</button></form>
    <?php elseif ($o['status'] === 'awaiting_deposit'): ?><hr><h3 class="h6">Deposit not paid yet</h3><form method="post" class="mb-3"><?= csrf_field() ?><input type="hidden" name="action" value="remind_deposit"><button class="btn btn-outline-primary btn-sm"><i class="bi bi-chat-dots me-1"></i>Send SMS reminder to pay the deposit</button></form><?= stk_widget($o, 'deposit', $o['phone'], url('admin/order.php?id=' . $id), 'Send deposit STK push') ?><?php endif; ?>
  </div></div>
  <?php if (Auth::isAdmin()): $elig = array_filter(rows("SELECT * FROM payments WHERE order_id=? AND kind='deposit' ORDER BY id", [$id]), fn($p) => Refunds::remaining($p) >= 1); ?>
  <div class="card" id="refund"><div class="card-body"><h2 class="h5 sp-display">Refund deposit</h2>
    <p class="small text-body-secondary">Use this when the customer did not come, or the delivery was not done. The deposit goes back to the customer's M-Pesa<?= Mpesa::env() === 'simulate' ? ' (simulated in this mode)' : ' by M-Pesa reversal; your M-Pesa account must hold enough balance' ?>.</p>
    <?php foreach ($elig as $p): $rem = Refunds::remaining($p); ?>
    <form method="post" data-confirm="Refund this deposit to the customer? This moves real money and cannot be undone."><?= csrf_field() ?><input type="hidden" name="action" value="refund"><input type="hidden" name="payment_id" value="<?= (int)$p['id'] ?>">
      <div class="small mb-2"><b><?= e($p['receipt_no']) ?></b>, paid <?= money($p['amount']) ?> (<?= e($p['mpesa_receipt'] ?: 'code pending') ?>), refundable <?= money($rem) ?></div>
      <div class="row g-2"><div class="col-5"><label class="form-label small mb-1">Amount (KES)</label><input class="form-control form-control-sm" type="number" min="1" max="<?= (int)$rem ?>" name="amount" value="<?= (int)$rem ?>" required></div>
      <div class="col-7"><label class="form-label small mb-1">Reason</label><select class="form-select form-select-sm" name="reason" onchange="this.form.reason_other.classList.toggle('d-none',this.value!=='Other')"><option>Customer did not come to eat</option><option>Delivery was not completed</option><option>Order cancelled by the restaurant</option><option>Order cancelled by the customer</option><option>Other</option></select></div>
      <div class="col-12"><input class="form-control form-control-sm d-none" name="reason_other" placeholder="Describe the reason"></div></div>
      <div class="form-check mt-2"><input class="form-check-input" type="checkbox" name="cancel_order" id="co<?= (int)$p['id'] ?>" <?= in_array($o['status'], ['completed', 'cancelled'], true) ? '' : 'checked' ?>><label class="form-check-label small" for="co<?= (int)$p['id'] ?>">Also cancel this order</label></div>
      <?php $isCash = $p['method'] === 'cash'; ?><div class="mt-2"><?php if (!$isCash): ?><div class="form-check"><input class="form-check-input" type="radio" name="method" value="api" id="ma<?= (int)$p['id'] ?>" checked onchange="this.form.manual_ref.classList.add('d-none')"><label class="form-check-label small" for="ma<?= (int)$p['id'] ?>">Reverse automatically through M-Pesa</label></div><?php endif; ?>
      <div class="form-check"><input class="form-check-input" type="radio" name="method" value="manual" id="mm<?= (int)$p['id'] ?>" <?= $isCash ? 'checked' : '' ?> onchange="this.form.manual_ref.classList.remove('d-none')"><label class="form-check-label small" for="mm<?= (int)$p['id'] ?>">I already refunded it (record only)</label></div>
      <input class="form-control form-control-sm <?= $isCash ? '' : 'd-none' ?> mt-1" name="manual_ref" placeholder="<?= $isCash ? 'How the cash was returned, e.g. Handed back by Wanjiru' : 'M-Pesa reference of the refund' ?>"></div>
      <button class="btn btn-danger btn-sm mt-3">Refund <?= money($rem) ?></button>
    </form><hr>
    <?php endforeach; if (!$elig) echo '<p class="small text-body-secondary mb-2">No refundable deposit on this order.</p>'; ?>
    <?php if ($refunds): ?><h3 class="h6">Refund history</h3><?php foreach ($refunds as $rf): ?>
      <div class="small py-1 border-top"><div class="d-flex justify-content-between"><span><b><?= money($rf['amount']) ?></b> <?= e($rf['receipt_no']) ?>, <?= e($rf['method'] === 'manual' ? 'manual' : 'M-Pesa reversal') ?></span><span class="badge text-bg-<?= ['success' => 'success', 'pending' => 'warning', 'failed' => 'danger'][$rf['status']] ?>"><?= e($rf['status']) ?></span></div>
      <div class="text-body-secondary"><?= e(fmt_dt($rf['created_at'], 'j M, g:i A')) ?>, <?= e($rf['reason']) ?><?= $rf['reversal_ref'] ? ', ref ' . e($rf['reversal_ref']) : '' ?><?= $rf['status'] !== 'success' && $rf['result_desc'] ? '. ' . e($rf['result_desc']) : '' ?></div>
      <?php if ($rf['status'] === 'pending'): ?><form method="post" class="mt-1"><?= csrf_field() ?><input type="hidden" name="action" value="refund_fail"><input type="hidden" name="refund_id" value="<?= (int)$rf['id'] ?>"><button class="btn btn-outline-secondary btn-sm py-0">Stop waiting and mark failed</button></form><?php endif; ?></div>
    <?php endforeach; endif; ?>
  </div></div>
  <?php endif; ?>
  <div class="card" id="payments"><div class="card-body"><h2 class="h5 sp-display">Payments</h2>
    <?php if (!$pays) echo '<p class="text-body-secondary mb-0">No payments yet.</p>'; else echo '<a class="btn btn-outline-primary btn-sm mb-2" href="../order_receipt.php?order=' . (int)$o['id'] . '"><i class="bi bi-files me-1"></i>Combined receipt (all payments)</a>'; foreach ($pays as $p): ?>
    <div class="d-flex justify-content-between align-items-center py-1 small"><span><b><?= e($p['receipt_no']) ?></b> <?= $p['kind'] === 'deposit' ? 'deposit' : 'balance' ?>, <?= $p['pct_of_total'] !== null ? rtrim(rtrim(number_format((float)$p['pct_of_total'], 1), '0'), '.') . '% of total, ' : '' ?><?= $p['method'] === 'cash' ? '<span class="badge text-bg-success">Cash</span>' : e($p['mpesa_receipt'] ?: 'code pending') . ($p['method'] === 'mpesa_manual' ? ' <span class="badge text-bg-warning">confirmed manually</span>' : '') ?><br><span class="text-body-secondary"><?= e(fmt_dt($p['paid_at'])) ?></span></span>
    <span class="text-end"><b><?= money($p['amount']) ?></b><?= $p['reversed_amount'] > 0 ? '<br><span class="badge text-bg-danger">Refunded ' . money($p['reversed_amount']) . '</span>' : '' ?><br><a href="../receipt.php?id=<?= (int)$p['id'] ?>">Receipt</a></span></div><?php endforeach; ?>
    <?php if ($reqs): ?><hr><h3 class="h6">M-Pesa requests</h3><?php foreach ($reqs as $r): $stc = ['success' => 'success', 'pending' => 'warning', 'failed' => 'danger', 'cancelled' => 'secondary', 'timeout' => 'secondary'][$r['status']]; ?>
      <div class="small py-1 border-top"><div class="d-flex justify-content-between"><span><?= e(fmt_dt($r['created_at'], 'j M g:i A')) ?>, <b><?= money($r['amount']) ?></b> (<?= e($r['kind']) ?>)</span><span class="badge text-bg-<?= $stc ?>"><?= e($r['status']) ?></span></div>
      <?php if ($r['status'] !== 'success'): ?><div class="text-body-secondary"><?= e(Mpesa::describe($r['result_code'] !== null ? (int)$r['result_code'] : ($r['status'] === 'timeout' ? 1037 : null), (string)$r['result_desc'])) ?></div>
        <?php if ($r['status'] !== 'cancelled' || true): ?><div class="d-flex flex-wrap gap-1 mt-1">
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="recheck"><input type="hidden" name="request_id" value="<?= (int)$r['id'] ?>"><button class="btn btn-outline-secondary btn-sm py-0">Re-check with Safaricom</button></form>
          <?php if (Auth::isAdmin()): ?><details class="w-100"><summary class="btn btn-outline-warning btn-sm py-0 d-inline-block">Confirm manually</summary>
            <form method="post" class="border rounded-3 p-2 mt-1" data-confirm="Record this payment? Check the code against the M-Pesa statement first."><?= csrf_field() ?><input type="hidden" name="action" value="confirm_mpesa"><input type="hidden" name="request_id" value="<?= (int)$r['id'] ?>">
              <div class="form-text mb-1">Only if the money really arrived (see the M-Pesa statement or the customer's SMS) but the app did not capture it.</div>
              <input class="form-control form-control-sm mb-1" name="receipt" placeholder="M-Pesa code, e.g. QJK7ABCD12" maxlength="12" required style="text-transform:uppercase">
              <div class="row g-1"><div class="col-6"><input class="form-control form-control-sm" type="number" name="amount" value="<?= (int)$r['amount'] ?>" min="1" required aria-label="Amount paid"></div><div class="col-6"><input class="form-control form-control-sm" name="phone" value="<?= e($r['phone']) ?>" aria-label="Phone that paid"></div></div>
              <input class="form-control form-control-sm mt-1" name="note" placeholder="Note (optional)"><button class="btn btn-warning btn-sm mt-2">Record payment</button></form></details><?php endif; ?></div><?php endif; ?>
      <?php endif; ?></div>
    <?php endforeach; endif; ?>
    <?php if ($bal >= 1 && $o['status'] !== 'cancelled'): ?><hr>
      <h3 class="h6">Record a cash payment</h3>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="cash">
        <div class="form-text mb-1"><?= $o['status'] === 'awaiting_deposit' ? 'Counts as the deposit (at least ' . money(max(0, (float)$o['deposit_due'] - (float)$o['amount_paid'])) . ') and places the order.' : 'Counts against the balance. Enter the amount to put against the bill; give change separately.' ?></div>
        <div class="input-group input-group-sm mb-1"><span class="input-group-text">KES</span><input class="form-control" type="number" name="amount" min="1" max="<?= (int)ceil($bal) ?>" value="<?= (int)ceil($o['status'] === 'awaiting_deposit' ? max(0, (float)$o['deposit_due'] - (float)$o['amount_paid']) : $bal) ?>" required aria-label="Cash received"></div>
        <input class="form-control form-control-sm mb-2" name="note" placeholder="Note (optional)" maxlength="120">
        <button class="btn btn-success btn-sm" onclick="return confirm('Record this cash payment?')"><i class="bi bi-cash-coin me-1"></i>Record cash received</button></form>
    <?php endif; ?>
    <?php if (Auth::isAdmin() && $o['status'] !== 'cancelled' && $bal >= 1): ?><details class="mt-3"><summary class="small text-body-secondary" style="cursor:pointer">Customer paid by M-Pesa but nothing shows? Confirm manually</summary>
      <form method="post" class="border rounded-3 p-2 mt-1" data-confirm="Record this payment? Check the code against the M-Pesa statement first."><?= csrf_field() ?><input type="hidden" name="action" value="confirm_mpesa">
        <div class="form-text mb-1">Use this only when the M-Pesa statement shows the money was received. Each M-Pesa code can be recorded once.</div>
        <input class="form-control form-control-sm mb-1" name="receipt" placeholder="M-Pesa code, e.g. QJK7ABCD12" maxlength="12" required style="text-transform:uppercase">
        <div class="row g-1"><div class="col-6"><input class="form-control form-control-sm" type="number" name="amount" min="1" max="<?= (int)ceil($bal) ?>" placeholder="Amount paid" required></div><div class="col-6"><input class="form-control form-control-sm" name="phone" value="<?= e($o['phone']) ?>" aria-label="Phone that paid"></div></div>
        <input class="form-control form-control-sm mt-1" name="note" placeholder="Note (optional)"><button class="btn btn-warning btn-sm mt-2">Record payment</button></form></details><?php endif; ?>
  </div></div>
 </div>
</div></div>
<?php if ($hasPending): ?><script>setTimeout(function(){location.reload()},8000)</script><?php endif; ?>
<?php page_footer(['admin' => true, 'scripts' => ['stk.js']]); ?>
