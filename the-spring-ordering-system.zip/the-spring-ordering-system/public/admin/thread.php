<?php
define('ADMIN_ONLY', true);
require __DIR__ . '/_guard.php';
$t = Messages::thread((int)get('id'));
if (!$t) { flash('danger', 'Conversation not found.'); redirect('/admin/messages.php'); }
if (is_post()) {
    csrf_check();
    $a = post('action');
    if ($a === 'reply') { $r = Messages::reply($t, $ME, post('body')); if (!$r['ok']) flash('danger', $r['message']); }
    elseif ($a === 'close') { Messages::setStatus((int)$t['id'], 'closed'); flash('success', 'Conversation closed. A reply from the customer opens it again.'); }
    elseif ($a === 'reopen') { Messages::setStatus((int)$t['id'], 'open'); flash('success', 'Conversation reopened.'); }
    redirect('/admin/thread.php?id=' . $t['id'] . ($a === 'reply' ? '#end' : ''));
}
Messages::markRead((int)$t['id'], true);
$msgs = Messages::after((int)$t['id'], 0); $last = $msgs ? (int)end($msgs)['id'] : 0;
$order = $t['order_id'] ? Orders::find((int)$t['order_id']) : null;
page_header('Conversation', ['admin' => true, 'active' => 'messages']);
?>
<a href="messages.php" class="small">&larr; All messages</a>
<div class="row g-3 mt-0">
 <div class="col-lg-8">
  <div class="card"><div class="card-body">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3"><h2 class="h5 sp-display mb-0"><?= e($t['subject']) ?></h2><?= $t['status'] === 'closed' ? '<span class="badge text-bg-secondary">Closed</span>' : '<span class="badge text-bg-success">Open</span>' ?></div>
    <div class="chat" id="chat" data-thread="<?= (int)$t['id'] ?>" data-last="<?= $last ?>" data-me="admin" data-api="<?= e(url('api/messages.php')) ?>">
      <?php foreach ($msgs as $m): $mine = $m['sender_role'] === 'admin'; ?>
        <div class="bubble-row <?= $mine ? 'mine' : 'theirs' ?>" data-id="<?= (int)$m['id'] ?>"><div class="bubble"><div class="who"><?= e($mine ? ((int)$m['sender_id'] === (int)$ME['id'] ? 'You' : Messages::senderName($m, $t)) : $t['customer_name']) ?></div><div class="txt"><?= e($m['body']) ?></div><div class="when"><?= e(fmt_dt($m['created_at'], 'j M, g:i A')) ?></div></div></div>
      <?php endforeach; ?>
    </div><div id="end"></div>
    <form method="post" class="mt-3"><?= csrf_field() ?><input type="hidden" name="action" value="reply">
      <textarea class="form-control" name="body" rows="3" maxlength="<?= Messages::MAX_LEN ?>" required placeholder="Write a reply to <?= e(explode(' ', $t['customer_name'])[0]) ?>" aria-label="Reply"></textarea>
      <div class="d-flex flex-wrap gap-2 mt-2"><button class="btn btn-primary"><i class="bi bi-send me-1"></i>Send reply</button></div></form>
  </div></div>
 </div>
 <div class="col-lg-4 vstack gap-3">
  <div class="card"><div class="card-body"><h2 class="h6">Customer</h2><div class="fw-semibold"><?= e($t['customer_name']) ?></div><?= $t['customer_phone'] !== '' ? '<a href="tel:+' . e($t['customer_phone']) . '">+' . e($t['customer_phone']) . '</a>' : '<span class="small text-body-secondary">No phone number yet</span>' ?><br><span class="small text-body-secondary"><?= e($t['customer_email']) ?></span></div></div>
  <?php if ($order): ?><div class="card"><div class="card-body"><h2 class="h6">About order <?= e($order['order_no']) ?></h2><div><?= status_badge($order) ?> <span class="small"><?= money($order['total']) ?>, paid <?= money($order['amount_paid']) ?></span></div><a class="btn btn-outline-primary btn-sm mt-2" href="order.php?id=<?= (int)$order['id'] ?>">Open order</a></div></div><?php endif; ?>
  <div class="card"><div class="card-body"><h2 class="h6">Conversation</h2>
    <form method="post"><?= csrf_field() ?><?php if ($t['status'] === 'closed'): ?><input type="hidden" name="action" value="reopen"><button class="btn btn-outline-primary btn-sm">Reopen</button><?php else: ?><input type="hidden" name="action" value="close"><button class="btn btn-outline-secondary btn-sm">Close conversation</button><?php endif; ?></form>
    <p class="form-text mb-0 mt-2">Started <?= e(fmt_dt($t['created_at'], 'j M Y, g:i A')) ?>. New messages appear here by themselves.</p></div></div>
 </div>
</div>
<?php page_footer(['admin' => true, 'scripts' => ['thread.js']]); ?>
