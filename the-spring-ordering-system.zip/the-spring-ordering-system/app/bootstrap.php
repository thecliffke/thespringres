<?php
declare(strict_types=1);

define('ROOT', dirname(__DIR__));
define('PUBLIC_PATH', ROOT . '/public');
$cfgFile = ROOT . '/config/config.php';
if (!is_file($cfgFile)) {
    http_response_code(500);
    exit('Missing config/config.php. Copy config/config.sample.php to config/config.php, edit it, then open /install.php.');
}
$GLOBALS['cfg'] = require $cfgFile;

require ROOT . '/app/helpers.php';
date_default_timezone_set((string)cfg('timezone', 'Africa/Nairobi'));
error_reporting(E_ALL);
ini_set('display_errors', cfg('debug') ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', ROOT . '/storage/logs/app.log');

foreach (['db', 'crypto', 'settings', 'auth', 'Notify', 'Sms', 'Orders', 'Mpesa', 'Reminders', 'Migrate', 'Mailer', 'Refunds', 'Push', 'Audit', 'Messages', 'Google', 'Passkey', 'Loyalty', 'Addresses'] as $f) require ROOT . '/app/' . $f . '.php';

Migrate::run();

if (!defined('NO_SESSION') && session_status() !== PHP_SESSION_ACTIVE) {
    session_name('thespring');
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => is_https()]);
    session_start();
}
if (!defined('NO_SESSION')) {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
}
require ROOT . '/app/layout.php';
