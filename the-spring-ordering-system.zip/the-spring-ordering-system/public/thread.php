<?php
require __DIR__ . '/../app/bootstrap.php';
$u = Auth::require('customer');
$t = Messages::thread((int)get('id'));
if (!$t || (int)$t['customer_id'] !== (int)$u['id']) { flash('danger', 'Conversation not found.'); redirect('/messages.php'); }
if (is_post()) {
    csrf_check();
    $r = Messages::reply($t, $u, post('body'));
    if (!$r['ok']) flash('danger', $r['message']);
    redirect('/thread.php?id=' . $t['id'] . '#end');
}
Messages::markRead((int)$t['id'], false);
$msgs = Messages::after((int)$t['id'], 0);
$last = $msgs ? (int)end($msgs)['id'] : 0;
page_header($t['subject'], ['active' => 'messages']);
?>
<a href="<?= e(url('messages.php')) ?>" class="small">&larr; Messages</a>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-1 mb-3"><h1 class="h4 sp-display mb-0"><?= e($t['subject']) ?></h1>
  <div><?php if ($t['order_no']): ?><a class="badge text-bg-light border text-decoration-none" href="<?= e(url('order.php?id=' . $t['order_id'])) ?>"><?= e($t['order_no']) ?></a> <?php endif; ?><?= $t['status'] === 'closed' ? '<span class="badge text-bg-secondary">Closed</span>' : '<span class="badge text-bg-success">Open</span>' ?></div></div>
<div class="card"><div class="card-body">
  <div class="chat" id="chat" data-thread="<?= (int)$t['id'] ?>" data-last="<?= $last ?>" data-me="customer" data-api="<?= e(url('api/messages.php')) ?>">
    <?php foreach ($msgs as $m): $mine = $m['sender_role'] === 'customer'; ?>
      <div class="bubble-row <?= $mine ? 'mine' : 'theirs' ?>" data-id="<?= (int)$m['id'] ?>"><div class="bubble"><div class="who"><?= e($mine ? 'You' : Messages::senderName($m, $t)) ?></div><div class="txt"><?= e($m['body']) ?></div><div class="when"><?= e(fmt_dt($m['created_at'], 'j M, g:i A')) ?></div></div></div>
    <?php endforeach; ?>
  </div><div id="end"></div>
  <form method="post" class="mt-3"><?= csrf_field() ?>
    <?php if ($t['status'] === 'closed'): ?><div class="form-text mb-1">This conversation was closed. Sending a reply opens it again.</div><?php endif; ?>
    <textarea class="form-control" name="body" rows="3" maxlength="<?= Messages::MAX_LEN ?>" required placeholder="Write a reply" aria-label="Your reply"></textarea>
    <button class="btn btn-primary mt-2"><i class="bi bi-send me-1"></i>Send</button></form>
</div></div>
<?php page_footer(['scripts' => ['thread.js']]); ?>
